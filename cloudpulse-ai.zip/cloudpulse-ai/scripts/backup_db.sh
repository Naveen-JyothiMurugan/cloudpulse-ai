#!/usr/bin/env bash
# Logical backup / restore for the docker compose database. UNTESTED against Docker here; pg_dump/pg_restore
# semantics are standard. Usage: scripts/backup_db.sh backup [file] | restore <file>
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; . ./.env; set +a; }
U=${POSTGRES_USER:-cloudpulse}; D=${POSTGRES_DB:-cloudpulse}
case "${1:-}" in
  backup)
    out=${2:-backups/cloudpulse-$(date -u +%Y%m%dT%H%M%SZ).dump}
    mkdir -p "$(dirname "$out")"
    docker compose exec -T db pg_dump -U "$U" -d "$D" -Fc > "$out"
    echo "wrote $out ($(wc -c < "$out") bytes)" ;;
  restore)
    f=${2:?usage: restore <file>}
    read -r -p "This REPLACES data in database '$D'. Type 'yes' to continue: " a; [ "$a" = yes ] || exit 1
    docker compose exec -T db pg_restore -U "$U" -d "$D" --clean --if-exists --no-owner < "$f"
    echo "restored $f" ;;
  *) echo "usage: $0 backup [file] | restore <file>"; exit 2 ;;
esac
