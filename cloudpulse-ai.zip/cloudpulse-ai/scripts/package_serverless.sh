#!/usr/bin/env bash
# Build deployable zips for the AWS Lambda and Azure Function adapters into dist/ (no network needed).
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
for target in aws_lambda azure_function; do
  work="$(mktemp -d)"
  cp services/serverless/forwarder.py "$work/"
  cp -r services/serverless/$target/. "$work/"
  (cd "$work" && python3 -m zipfile -c "$OLDPWD/dist/${target}.zip" .)
  rm -rf "$work"
  echo "built dist/${target}.zip"
done
