#!/usr/bin/env bash
# Controlled LOCAL failure simulation (docker compose only). Never point this at shared or production systems.
# Scenario: stop PostgreSQL -> /ready must fail with 503 and no stack trace -> restart -> /ready recovers.
# UNTESTED in the build sandbox (no Docker daemon). Requires the stack from `make up`.
set -euo pipefail
cd "$(dirname "$0")/.."
API=${CLOUDPULSE_API:-http://127.0.0.1:8000/api/v1}
code() { curl -s -o /dev/null -w '%{http_code}' "$API/$1" || echo 000; }
fail() { echo "FAIL: $*"; docker compose start db >/dev/null 2>&1 || true; exit 1; }

[ "$(code ready)" = 200 ] || fail "stack is not ready before the experiment"
echo "1. baseline: /ready=200, /health=$(code health)"
docker compose stop db >/dev/null
sleep 3
r=$(code ready); h=$(code health)
echo "2. db stopped: /ready=$r (expect 503), /health=$h (expect 200: liveness must not depend on the DB)"
[ "$r" = 503 ] || fail "readiness did not report the outage"
[ "$h" = 200 ] || fail "liveness should stay up"
body=$(curl -s "$API/ready")
echo "$body" | grep -qiE 'traceback|psycopg|password' && fail "error body leaks internals: $body"
echo "   error body is sanitised: $body"
docker compose start db >/dev/null
for i in $(seq 1 30); do [ "$(code ready)" = 200 ] && { echo "3. recovered after ${i}s: /ready=200"; echo "PASS"; exit 0; }; sleep 1; done
fail "API did not recover within 30s of the database returning"
