#!/usr/bin/env python3
"""Generate the deterministic SYNTHETIC cost CSV and event JSON used for demos and tests.

All values are fabricated. They are NOT real cloud bills. The generator is seeded, so
running it twice produces byte-identical files. Known injected anomalies are listed in
data/sample/GROUND_TRUTH.json so detector tests can check them.

Usage: python scripts/generate_sample_data.py [--out data/sample] [--seed 20250101]
"""

from __future__ import annotations

import argparse
import csv
import json
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import numpy as np

START = date(2025, 1, 1)
DAYS = 120  # 2025-01-01 .. 2025-04-30

# (provider, account, service, region, base daily cost, usage unit, usage per currency unit)
SERIES = [
    ("aws", "111122223333", "EC2", "us-east-1", 220.0, "Hrs", 0.1),
    ("aws", "111122223333", "EC2", "eu-west-1", 90.0, "Hrs", 0.1),
    ("aws", "111122223333", "S3", "us-east-1", 38.0, "GB-Mo", 40.0),
    ("aws", "111122223333", "Lambda", "us-east-1", 24.0, "GB-Seconds", 60000.0),
    ("aws", "111122223333", "RDS", "us-east-1", 130.0, "Hrs", 0.2),
    ("aws", "111122223333", "CloudWatch", "us-east-1", 15.0, "GB", 2.0),
    ("azure", "sub-demo-0001", "Virtual Machines", "eastus", 170.0, "Hrs", 0.12),
    ("azure", "sub-demo-0001", "Virtual Machines", "westeurope", 70.0, "Hrs", 0.12),
    ("azure", "sub-demo-0001", "Blob Storage", "eastus", 28.0, "GB-Mo", 45.0),
    ("azure", "sub-demo-0001", "Functions", "eastus", 12.0, "Executions", 500000.0),
    ("azure", "sub-demo-0001", "Cosmos DB", "eastus", 60.0, "RU", 9000.0),
]
WEEKDAY_FACTOR = [1.06, 1.08, 1.07, 1.05, 1.03, 0.86, 0.84]  # Mon..Sun
SPIKES = [  # (provider, service, date, multiplier, note)
    ("aws", "EC2", date(2025, 2, 14), 3.2, "Runaway autoscaling group"),
    ("aws", "Lambda", date(2025, 3, 5), 5.0, "Recursive function invocation loop"),
    ("azure", "Cosmos DB", date(2025, 3, 20), 2.6, "Unplanned bulk import"),
    ("aws", "S3", date(2025, 4, 10), 2.2, "Large replication job"),
]


def generate(seed: int):
    rng = np.random.default_rng(seed)
    spike_map = {(p, s, d): m for p, s, d, m, _ in SPIKES}
    rows = []
    for offset in range(DAYS):
        d = START + timedelta(days=offset)
        for provider, acct, service, region, base, unit, per in SERIES:
            trend = 1 + 0.0009 * offset  # slow organic growth
            noise = rng.normal(1.0, 0.035)
            cost = base * trend * WEEKDAY_FACTOR[d.weekday()] * noise
            cost *= spike_map.get((provider, service, d), 1.0) if region in ("us-east-1", "eastus") else 1.0
            cost = round(max(cost, 0.01), 2)
            rows.append(
                [
                    d.isoformat(),
                    provider,
                    acct,
                    service,
                    region,
                    round(cost * per, 3),
                    unit,
                    f"{cost:.2f}",
                    "USD",
                    "synthetic",
                ]
            )
    return rows


def generate_events(seed: int):
    rng = np.random.default_rng(seed + 1)
    events = []
    n = 0
    for p, svc, d, _m, note in SPIKES:
        pair = [
            ("warning", "scaling" if svc == "EC2" else "throttle", f"{svc}: usage above normal ({note})"),
            ("error", "error_rate", f"{svc}: elevated errors during spike window"),
        ]
        for k, (sev, etype, msg) in enumerate(pair):
            n += 1
            ts = datetime(d.year, d.month, d.day, 8 + 3 * k, 15, tzinfo=UTC)
            events.append(
                {
                    "event_id": f"synthetic-evt-{n:04d}",
                    "provider": p,
                    "service": svc,
                    "environment": "demo",
                    "severity": sev,
                    "event_type": etype,
                    "timestamp": ts.isoformat().replace("+00:00", "Z"),
                    "message": msg,
                    "correlation_id": f"synthetic-corr-{d.isoformat()}-{svc.lower().replace(' ', '')}",
                    "metadata": {"synthetic": True},
                    "is_synthetic": True,
                }
            )
    for _ in range(30):  # background noise events
        day = START + timedelta(days=int(rng.integers(0, DAYS)))
        p, _, svc, region, *_ = SERIES[int(rng.integers(0, len(SERIES)))]
        n += 1
        events.append(
            {
                "event_id": f"synthetic-evt-{n:04d}",
                "provider": p,
                "service": svc,
                "environment": "demo",
                "severity": ["info", "info", "warning"][int(rng.integers(0, 3))],
                "event_type": "health_check",
                "timestamp": datetime(day.year, day.month, day.day, int(rng.integers(0, 24)), 0, tzinfo=UTC)
                .isoformat()
                .replace("+00:00", "Z"),
                "message": f"{svc} periodic health check in {region}",
                "correlation_id": None,
                "metadata": {"region": region, "synthetic": True},
                "is_synthetic": True,
            }
        )
    return events


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/sample")
    ap.add_argument("--seed", type=int, default=20250101)
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = generate(args.seed)
    with open(out / "synthetic_costs.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(
            [
                "usage_date",
                "provider",
                "account_identifier",
                "service_name",
                "region",
                "usage_quantity",
                "usage_unit",
                "cost_amount",
                "currency",
                "source_type",
            ]
        )
        w.writerows(rows)
    (out / "synthetic_events.json").write_text(json.dumps(generate_events(args.seed), indent=2) + "\n")
    truth = {
        "note": "Synthetic data; injected anomalies for testing the detector.",
        "seed": args.seed,
        "injected_anomalies": [
            {"provider": p, "service": s, "date": d.isoformat(), "multiplier": m, "story": note}
            for p, s, d, m, note in SPIKES
        ],
    }
    (out / "GROUND_TRUTH.json").write_text(json.dumps(truth, indent=2) + "\n")
    print(f"wrote {len(rows)} cost rows and events to {out}")


if __name__ == "__main__":
    main()
