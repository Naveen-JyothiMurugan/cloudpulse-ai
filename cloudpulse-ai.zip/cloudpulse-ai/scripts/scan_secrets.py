#!/usr/bin/env python3
"""Lightweight tracked-file secret scan (stdlib). Not a substitute for gitleaks/trufflehog, but it runs anywhere.

Exits 1 when a likely secret is found in a file that git tracks (or, outside a git repo, any non-ignored file).
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATTERNS = {
    "AWS access key id": re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"),
    "private key block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "Anthropic/OpenAI style key": re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{24,}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    "Azure storage key": re.compile(r"AccountKey=[A-Za-z0-9+/=]{40,}"),
    "hard-coded password assignment": re.compile(r"(?i)\b(password|secret|token)\s*[:=]\s*['\"][^'\"\s$<{]{10,}['\"]"),
}
ALLOW_PATHS = ("tests/", "docs/", ".env.example", "scripts/scan_secrets.py")
SKIP_SUFFIXES = {".png", ".jpg", ".pdf", ".zip", ".lock", ".json"}


def files() -> list[Path]:
    try:
        out = subprocess.run(
            ["git", "ls-files", "-co", "--exclude-standard"], cwd=ROOT, capture_output=True, text=True, check=True
        )
        return [ROOT / p for p in out.stdout.splitlines()]
    except (subprocess.CalledProcessError, FileNotFoundError):
        return [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts and "node_modules" not in p.parts]


def main() -> int:
    hits = []
    for p in files():
        rel = p.relative_to(ROOT).as_posix()
        if p.suffix in SKIP_SUFFIXES or not p.is_file() or rel.startswith(ALLOW_PATHS) or rel == ".env":
            continue
        try:
            text = p.read_text(errors="ignore")
        except OSError:
            continue
        for name, rx in PATTERNS.items():
            for m in rx.finditer(text):
                hits.append(f"{rel}:{text.count(chr(10), 0, m.start()) + 1}: possible {name}")
    if (ROOT / ".env").exists():
        ignored = subprocess.run(["git", "check-ignore", "-q", ".env"], cwd=ROOT).returncode == 0
        if not ignored:
            hits.append(".env exists but is not git-ignored")
    for h in hits:
        print(h)
    print(f"secret scan: {len(hits)} finding(s)")
    return 1 if hits else 0


if __name__ == "__main__":
    sys.exit(main())
