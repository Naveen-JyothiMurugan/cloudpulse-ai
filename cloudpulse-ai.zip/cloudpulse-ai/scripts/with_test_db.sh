#!/usr/bin/env bash
# Run a command against a throwaway local PostgreSQL cluster (no Docker needed).
#   scripts/with_test_db.sh python3 -m unittest discover -s tests/integration
# Exports CLOUDPULSE_TEST_DSN for the child command, then stops and deletes the cluster.
# Needs the PostgreSQL server binaries (initdb, pg_ctl) installed; works as root (drops to the
# `postgres` user) or as a normal user.
set -euo pipefail

PORT="${CLOUDPULSE_TEST_PG_PORT:-5433}"
BIN="${PG_BIN:-}"
if [ -z "$BIN" ]; then
  if command -v initdb >/dev/null 2>&1; then BIN="$(dirname "$(command -v initdb)")"
  else BIN="$(dirname "$(ls /usr/lib/postgresql/*/bin/initdb 2>/dev/null | sort -V | tail -1)")"; fi
fi
[ -x "$BIN/initdb" ] || { echo "PostgreSQL server binaries not found; set PG_BIN" >&2; exit 2; }

DIR="$(mktemp -d)"
as_pg() { if [ "$(id -u)" = 0 ]; then su postgres -c "$1"; else bash -c "$1"; fi; }
[ "$(id -u)" = 0 ] && chown postgres "$DIR" && chmod 755 "$(dirname "$DIR")" 2>/dev/null || true

cleanup() { as_pg "$BIN/pg_ctl -D '$DIR/data' -m immediate stop >/dev/null 2>&1" || true; rm -rf "$DIR"; }
trap cleanup EXIT

as_pg "$BIN/initdb -D '$DIR/data' -A trust -U postgres >/dev/null"
as_pg "$BIN/pg_ctl -D '$DIR/data' -o '-p $PORT -k $DIR -c listen_addresses=127.0.0.1' -l '$DIR/pg.log' -w start >/dev/null"
psql "postgresql://postgres@127.0.0.1:$PORT/postgres" -qtAc "CREATE DATABASE cloudpulse_test" >/dev/null

export CLOUDPULSE_TEST_DSN="postgresql://postgres@127.0.0.1:$PORT/cloudpulse_test"
export TMPDIR="$DIR"
chmod 777 "$DIR" 2>/dev/null || true
"$@"
