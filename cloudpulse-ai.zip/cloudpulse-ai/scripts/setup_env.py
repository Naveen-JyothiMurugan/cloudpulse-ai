#!/usr/bin/env python3
"""Create .env from .env.example with freshly generated random secrets (stdlib only).

Refuses to overwrite an existing .env unless --force is given. The generated admin password is stored in
.env (git-ignored) for local development only and is NOT printed to the terminal.
"""

from __future__ import annotations

import argparse
import secrets
import string
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def strong_password(n: int = 20) -> str:
    alphabet = string.ascii_letters + string.digits
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(n))
        if any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw):
            return pw


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    target, template = ROOT / ".env", ROOT / ".env.example"
    if target.exists() and not a.force:
        print(".env already exists; leaving it untouched (use --force to regenerate).")
        return 0
    values = {
        "POSTGRES_PASSWORD": secrets.token_urlsafe(24),
        "SECRET_KEY": secrets.token_urlsafe(48),
        "CLOUDPULSE_ADMIN_PASSWORD": strong_password(),
        "GRAFANA_ADMIN_PASSWORD": strong_password(),
    }
    out = []
    for line in template.read_text().splitlines():
        key = line.split("=", 1)[0].strip()
        if key in values and "__GENERATE__" in line:
            line = f"{key}={values[key]}"
        out.append(line)
    if any("=__GENERATE__" in ln for ln in out):
        sys.exit("internal error: a __GENERATE__ placeholder has no generator; .env was not written")
    target.write_text("\n".join(out) + "\n")
    target.chmod(0o600)
    print(f"wrote {target.relative_to(ROOT)} with generated secrets (mode 600).")
    print(
        "Admin email is CLOUDPULSE_ADMIN_EMAIL; the generated admin password is in .env under CLOUDPULSE_ADMIN_PASSWORD."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
