#!/usr/bin/env python3
"""Send synthetic operational events to a running CloudPulse API (stdlib only).

Auth: either a bearer ingest token (INGEST_API_TOKEN configured on the server) or an admin login.
  CLOUDPULSE_INGEST_TOKEN=... python scripts/send_test_events.py --count 5
  CLOUDPULSE_ADMIN_EMAIL=... CLOUDPULSE_ADMIN_PASSWORD=... python scripts/send_test_events.py --file data/sample/synthetic_events.json
Events are labelled is_synthetic=true. Re-running is safe: duplicates are reported, not re-inserted.
"""

from __future__ import annotations

import argparse
import http.cookiejar
import json
import os
import urllib.error
import urllib.request
from datetime import UTC, datetime

SAMPLE_PAYLOAD = {
    "event_id": "evt-1001",
    "provider": "aws",
    "service": "Lambda",
    "environment": "demo",
    "severity": "warning",
    "event_type": "throttle",
    "timestamp": "2025-03-02T10:15:00Z",
    "message": "Concurrent execution limit reached",
    "correlation_id": "req-77",
    "metadata": {"region": "us-east-1"},
    "is_synthetic": True,
}


def build_events(count: int, prefix: str):
    now = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
    sev = ["info", "warning", "error", "critical"]
    return [
        {
            **SAMPLE_PAYLOAD,
            "event_id": f"{prefix}-{now}-{i:03d}",
            "severity": sev[i % 4],
            "timestamp": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "message": f"Generated test event {i}",
            "correlation_id": f"corr-{now}-{i // 3}",
        }
        for i in range(count)
    ]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=os.environ.get("CLOUDPULSE_API", "http://localhost:8000/api/v1"))
    ap.add_argument("--count", type=int, default=5)
    ap.add_argument("--file", help="JSON file containing a list of events")
    ap.add_argument("--prefix", default="gen")
    a = ap.parse_args()
    events = json.load(open(a.file)) if a.file else build_events(a.count, a.prefix)
    headers = {"Content-Type": "application/json"}
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    token = os.environ.get("CLOUDPULSE_INGEST_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    else:
        email, pw = os.environ.get("CLOUDPULSE_ADMIN_EMAIL"), os.environ.get("CLOUDPULSE_ADMIN_PASSWORD")
        if not (email and pw):
            raise SystemExit("Set CLOUDPULSE_INGEST_TOKEN, or CLOUDPULSE_ADMIN_EMAIL and CLOUDPULSE_ADMIN_PASSWORD.")
        req = urllib.request.Request(
            a.url + "/auth/login", json.dumps({"email": email, "password": pw}).encode(), headers
        )
        csrf = json.load(opener.open(req))["csrf_token"]
        headers["X-CSRF-Token"] = csrf
    for i in range(0, len(events), 500):
        req = urllib.request.Request(a.url + "/events", json.dumps({"events": events[i : i + 500]}).encode(), headers)
        try:
            out = json.load(opener.open(req))
        except urllib.error.HTTPError as e:
            print("request failed:", e.code, e.read().decode()[:500])
            return 1
        print({k: out[k] for k in ("created", "duplicates", "rejected")})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
