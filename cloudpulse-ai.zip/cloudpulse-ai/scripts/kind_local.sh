#!/usr/bin/env bash
# Local Kubernetes workflow with kind + Helm (no paid cluster). UNTESTED in the build sandbox (no Docker daemon).
# Usage: scripts/kind_local.sh up | down
set -euo pipefail
cd "$(dirname "$0")/.."
CLUSTER=cloudpulse
case "${1:-}" in
  up)
    command -v kind >/dev/null && command -v kubectl >/dev/null && command -v helm >/dev/null || { echo "need kind, kubectl, helm"; exit 1; }
    [ -f .env ] || python3 scripts/setup_env.py
    set -a; . ./.env; set +a
    kind get clusters | grep -qx "$CLUSTER" || kind create cluster --name "$CLUSTER"
    docker build -t cloudpulse-api:local -f apps/api/Dockerfile .
    docker build -t cloudpulse-web:local -f apps/web/Dockerfile .
    kind load docker-image cloudpulse-api:local cloudpulse-web:local --name "$CLUSTER"
    kubectl create namespace cloudpulse --dry-run=client -o yaml | kubectl apply -f -
    # In-cluster dev PostgreSQL (NOT for production): one pod, emptyDir storage.
    kubectl -n cloudpulse apply -f infra/kubernetes/dev-postgres.yaml
    kubectl -n cloudpulse create secret generic cloudpulse-secrets \
      --from-literal=DATABASE_URL="postgresql+psycopg://cloudpulse:${POSTGRES_PASSWORD}@postgres:5432/cloudpulse" \
      --from-literal=SECRET_KEY="${SECRET_KEY}" --dry-run=client -o yaml | kubectl apply -f -
    kubectl -n cloudpulse create secret generic postgres-auth --from-literal=POSTGRES_PASSWORD="${POSTGRES_PASSWORD}" \
      --dry-run=client -o yaml | kubectl apply -f -
    kubectl -n cloudpulse rollout status deploy/postgres --timeout=120s
    helm upgrade --install cloudpulse infra/helm/cloudpulse -n cloudpulse \
      --set image.api.repository=cloudpulse-api --set image.api.tag=local --set image.api.pullPolicy=Never \
      --set image.web.repository=cloudpulse-web --set image.web.tag=local --set image.web.pullPolicy=Never \
      --set config.appEnv=development --set config.cookieSecure=false --set networkPolicy.enabled=false --wait --timeout 5m
    echo "Run:  kubectl -n cloudpulse port-forward svc/cloudpulse-web 8080:80   then open http://localhost:8080"
    ;;
  down) kind delete cluster --name "$CLUSTER" ;;
  *) echo "usage: $0 up|down"; exit 2 ;;
esac
