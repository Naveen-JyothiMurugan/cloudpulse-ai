# Threat model

Method: lightweight STRIDE per trust boundary. Likelihood/impact are the author's judgement for a portfolio deployment, not measured.

## Assets
Cost and event data (may reveal infrastructure layout and spend); user credentials and sessions; ingest bearer token; optional cloud role/identity; optional LLM API key; audit log integrity; availability of the dashboard.

## Trust boundaries
1. Browser ⇄ web/API (untrusted client). 2. API ⇄ PostgreSQL (trusted network, credentials in env). 3. Serverless forwarders ⇄ API (bearer token over HTTPS). 4. API ⇄ cloud providers (IAM role/managed identity, read-only). 5. API ⇄ LLM provider (data leaves the system). 6. Uploaded files and event messages (untrusted content).

```mermaid
flowchart LR
  B[Browser<br/>untrusted] -- TB1 --> W[Web/API]
  U[CSV uploads / event text<br/>untrusted] -- TB6 --> W
  F[Lambda / Function] -- TB3 --> W
  W -- TB2 --> D[(PostgreSQL)]
  W -- TB4 --> C[Cloud APIs]
  W -- TB5 --> L[LLM provider]
```

## Threats and mitigations

| # | Threat (STRIDE) | Boundary | Mitigation | Residual risk |
|---|---|---|---|---|
| T1 | Credential stuffing / brute force (S) | 1 | Rate limits, lockout, generic errors, scrypt | Medium: per-replica limiter; no MFA |
| T2 | Session theft via XSS (S/I) | 1 | HttpOnly cookie, React escaping (no `dangerouslySetInnerHTML`), event text rendered as text; **no UI CSP yet** | Medium |
| T3 | CSRF on state changes (T) | 1 | SameSite=Lax + double-submit token on non-safe methods | Low |
| T4 | Privilege escalation by read-only user (E) | 1 | Server-side `require_admin`; role read from DB each request | Low (untested over HTTP) |
| T5 | SQL injection (T/I) | 1,6 | Bind params, allow-listed identifiers | Low |
| T6 | Malicious CSV (formula injection, huge file, malformed) (T/D) | 6 | Size/row limits, strict parsing, formula neutralisation on export | Low |
| T7 | Stored XSS / log injection through event messages (T) | 6 | Length limits, text-only rendering, structured JSON logs | Low |
| T8 | Prompt injection via event text to the LLM (T/I) | 5,6 | Aggregates only, redaction, strict output schema, no tools, AI text separated | Low–Medium: LLM may still produce misleading prose |
| T9 | Secret/PII exfiltration to LLM (I) | 5 | Redaction, no raw secrets stored, feature off by default | Low |
| T10 | Stolen ingest token used to inject fake data (S/T) | 3 | ≥ 24 chars, constant-time compare, scope limited to two endpoints, audit entry, stored in Secrets Manager/Key Vault | Medium: data poisoning possible until rotated |
| T11 | Over-permissive cloud role (E) | 4 | Least-privilege policies in Terraform; adapters read-only; disabled by default | Low–Medium |
| T12 | Tampering with audit trail (R) | 2 | Append-only trigger | Medium: DB superuser can drop the trigger |
| T13 | DoS by heavy queries/uploads (D) | 1 | Page-size cap, statement timeout 20 s, upload limits, rate limits | Medium |
| T14 | Supply-chain compromise (T) | build | Pinned versions, audits, Trivy; actions pinned by tag (SHA pinning recommended) | Medium |
| T15 | Synthetic data mistaken for real billing (I) | UI | `is_synthetic` constraint, origin banner, report header, exports include flag | Low |
| T16 | Secrets committed to Git (I) | build | `.gitignore`, secret scan, `.env.example` placeholders | Low |

## Out of scope
Physical security, cloud account compromise, malicious cluster admins, denial of service at network level, compliance regimes (SOC 2, PCI, GDPR processing agreements).
