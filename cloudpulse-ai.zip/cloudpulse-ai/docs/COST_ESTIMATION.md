# Cost estimation

**These are order-of-magnitude estimates from the author's recollection of public on-demand list prices (US regions, early-2020s pricing pages), not quotes and not checked against live pricing during this build (the sandbox could not reach vendor sites).** Verify every line on the official pages before deploying: AWS Pricing Calculator <https://calculator.aws/>, Azure Pricing Calculator <https://azure.microsoft.com/pricing/calculator/>. Taxes, data transfer, support plans and free-tier eligibility are excluded. Nothing here promises that hosting is free.

## Local development
Docker Compose on your own machine: **$0** in cloud charges. Synthetic data; no AI key needed.

## Optional AWS (Terraform) — assumptions
Region us-east-1 · 730 h/month · 1 GB of CSV exports/month · < 1M Lambda invocations · < 1 GB logs · one environment.

| Component | Default? | Rough monthly cost | Notes |
|---|---|---|---|
| S3 raw bucket (≤ 5 GB, versioned, lifecycle expiry) | yes | cents | storage + requests |
| DynamoDB on-demand events table | yes | cents at demo volumes | PITR adds a small per-GB charge |
| Secrets Manager (2 secrets) | yes | ≈ $0.40 per secret per month → ~$0.80 | plus API calls |
| SNS topic + e-mail | yes | ≈ $0 | |
| CloudWatch logs (30-day retention) | yes | ≈ $0.50 per GB ingested | demo volume is tiny |
| CloudWatch alarms (2) | with Lambda | ≈ $0.10 each | |
| Ingestion Lambda + SQS DLQ | only if `api_url` set | ≈ $0 within free tier | arm64, 256 MB |
| EC2 `t4g.small` app host + 30 GB gp3 | **opt-in** | ≈ $12–15 + ≈ $2.5 storage | public IPv4 addresses are also charged per hour (≈ $3.6/month) if you assign one |
| RDS PostgreSQL `db.t4g.micro` + 20 GB | **opt-in** | ≈ $12–16 + ≈ $2.5 storage + backup storage beyond free allocation | single-AZ |
| Cost Explorer API requests | only when syncing | small per-request charge (check current price) | a sync issues a handful of requests |
| NAT Gateway / load balancer | **not created** | each ≈ $16+/month plus data | avoided on purpose |

Typical totals: **defaults only ≈ $1–3/month**; with app host ≈ $15–20; with app host + RDS ≈ $30–40. A managed Kubernetes control plane (EKS/AKS/GKE) is **not** required and not created; if you choose one, add its fee and node costs.

## Optional Azure
Not provisioned by this repo. An Azure Function on a Consumption plan plus a storage account is typically cents at demo volumes; Cosmos DB provisioned throughput is not free — use serverless/free-tier options only after checking current terms.

## Optional LLM
Off by default. Cost is per token on the provider you choose; each anomaly explanation sends a short redacted prompt (a few hundred tokens). Estimate = anomalies × tokens × provider price.

## How to avoid surprises
Set AWS Budgets alerts before applying; keep `enable_app_host`/`enable_rds` false until needed; `terraform destroy` when done (see DEPLOYMENT_GUIDE for the bucket/RDS teardown caveats); check the Billing console the next day.
