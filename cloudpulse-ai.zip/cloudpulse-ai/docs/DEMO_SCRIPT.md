# Demo script (10 minutes, no cloud account needed)

Prerequisite: `make setup && make up && make seed`, sign in at <http://localhost:3000>. Everything on screen is **synthetic** and labelled so.

1. **Overview (1 min).** Point out the violet "Synthetic demo data … not real cloud bills" banner. Totals, change vs previous period (+2.93 % for Apr 2025 vs the prior 30 days), provider/service/region charts, data freshness and last ingestion run. Change the date range → every number re-queries the API.
2. **Cost analytics (2 min).** Switch daily/monthly and group by service. Use filters/search on the table, page through, export CSV (filters respected) and the period report (states data origin). Show the 14-day forecast chart: measured vs forecast are separate series; read the backtest line (MAE 20.11 vs naive 74.41, 120 points, 3 origins) and the caveat that this is computed on synthetic data only.
3. **Ingestion (1 min).** Upload `data/sample/synthetic_costs.csv` again → "0 inserted, 1320 duplicates". Upload a CSV with a bad `cost_amount` → partial run with line/field error messages. Open run history.
4. **Anomalies (2 min).** Click *Run detection* (admin): 4 anomalies (2 critical, 2 high) matching `data/sample/GROUND_TRUTH.json`. Expand EC2 on 2025‑02‑14: observed 898.70 vs expected 343.83, score 32.28 vs threshold 3.5. Run again → 0 new, 4 suppressed. Mention it is deterministic and that the ground truth was written by the author, so this shows the mechanics, not real-world accuracy.
5. **Recommendations (1 min).** Measured evidence vs next steps, impact stated as a labelled extrapolation, confidence note, "human review required". Explain the optional LLM and its fallback.
6. **Events & alerts (2 min).** Search events; send one with `python scripts/send_test_events.py --count 3` (needs bearer token or admin login). Open an alert: linked anomaly, related events (±1 day), acknowledge → add a note → resolve. Create an incident from unresolved alerts; walk its status transitions.
7. **Integrations (30 s).** Demo is the only enabled provider; AWS/Azure cards list missing server-side configuration and say no secrets are entered in the browser.
8. **Persistence (30 s).** `docker compose restart api` → reload: data and states persist. Optionally run `bash scripts/chaos_local.sh`.

Read-only walkthrough: create `viewer@example.com` with `--role readonly`; buttons for mutations are hidden and the API returns 403.
