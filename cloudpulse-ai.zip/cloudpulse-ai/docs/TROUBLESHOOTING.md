# Troubleshooting

Items reflect the code's behaviour; the stack itself has not been run end to end by the author, so expect to discover additional cases.

| Symptom | Likely cause | Fix |
|---|---|---|
| `make up` fails: `run \`make setup\` to create .env` | `.env` missing | `make setup` |
| API container exits immediately, log says `ConfigError` | production safety checks: dev/short `SECRET_KEY`, `COOKIE_SECURE=false`, `CORS_ORIGINS=*`, `INGEST_API_TOKEN` < 24 chars | fix the variable named in the message; locally use `APP_ENV=development` |
| `/api/v1/ready` → 503 `Database schema is not migrated` | migrations did not run | `make migrate`; check `RUN_MIGRATIONS=1` |
| `/api/v1/ready` → 503 `Database is not reachable` | DB down or wrong `DATABASE_URL` | `docker compose ps`, `docker compose logs db`; password changed after volume creation → `make reset` (deletes data) |
| Login always returns 401 | wrong credentials, or locked out (5 failures → 15 min) | recreate with `python -m app.cli create-user`; wait for lockout to expire; lockout counters live in the `users` table |
| Login works but pages show "session expired" | cookie `Secure` over plain HTTP | set `COOKIE_SECURE=false` for local HTTP only |
| `403 csrf_failed` on POST | missing `X-CSRF-Token` (curl/scripts) | take `csrf_token` from login / `/auth/me` and send it; bearer-token ingestion needs no CSRF |
| `429 rate_limited` | login/upload/event limits | wait for `Retry-After`; tune `LOGIN_RATE_LIMIT`, `UPLOAD_RATE_LIMIT` |
| Dashboard says "No cost data" | nothing loaded | Integrations → Load demo data, or `make seed`, or upload a CSV |
| Dashboard empty for "last 30 days" | data is old | the default window anchors to the latest stored date; choose dates explicitly |
| CSV upload 422 `invalid_csv` | missing/misspelled columns, bad numbers/dates | read `errors` (line, field, message); required header: `usage_date,provider,account_identifier,service_name,region,usage_quantity,usage_unit,cost_amount,currency,source_type` |
| Re-upload "does nothing" | idempotency | by design: identical natural keys are skipped (corrected amounts are also skipped) |
| Detection finds nothing | fewer than `min_history_days` (7) per series, thresholds too strict | lower `z_threshold`/`min_pct_change` via request `config`; see `warnings` in the response |
| Forecast `insufficient_data` | < 28 daily points | load more history |
| Port already in use | 3000/8000/5432/9090/3001 | stop the other process or edit ports in `docker-compose.yml` |
| `web` cannot reach API | `API_INTERNAL_URL` wrong | Compose: `http://api:8000`; dev: `http://localhost:8000` |
| Integration shows `not_configured` | cloud settings missing | see "missing configuration" on the card; set env vars server-side |
| Sync returns 502 `provider_error` | credentials/permissions/Cost Explorer not enabled | check API logs for the exception *type*; verify IAM/RBAC; Cost Explorer needs enabling and up to ~24 h |
| Pods CrashLoop with `ConfigError` | Helm values: `appEnv=production` needs `cookieSecure: "true"` and a real `SECRET_KEY` secret | fix values / secret |
| `terraform validate` complains about the Lambda zip | `lambda_zip_path` default points at `dist/aws_lambda.zip` | `bash scripts/package_serverless.sh` |

## API down
Check `docker compose logs api`, `/api/v1/health` (process) vs `/api/v1/ready` (database + schema). Alert `ApiDown` fires after 2 min of failed scrapes.

## Database
Backup/restore: `scripts/backup_db.sh backup` / `restore <file>`. Connection errors in logs: the API's DB pool has a 20 s statement timeout and reconnects automatically on the next request. Recovery after a DB outage requires no API restart (verify with `scripts/chaos_local.sh`).

## Retry and timeout policies
Serverless forwarders: 3 attempts on network errors/429/5xx with 2–8 s backoff, no retry on other 4xx, 20 s per request; Lambda failures go to the DLQ and raise an alarm. LLM calls: 10 s timeout, no retry, immediate rule-based fallback. Cloud adapters: 30 s HTTP timeout, no retry (the operator re-runs the sync).

## Log retention
Application logs are JSON on stdout (retention is the platform's job). Terraform sets CloudWatch retention to 30 days by default.

## Alert thresholds (Prometheus)
`ApiDown` 2 min · `DatabaseUnreachable` 1 min · 5xx ratio > 5 % for 5 min · p95 latency > 1.5 s for 10 min · any failed ingestion run in 1 h · > 5 LLM fallbacks in 1 h. These are starting points, not tuned values.

## Service dependencies
web → api → PostgreSQL; optional: api → LLM provider, api → AWS/Azure APIs; forwarders → api. The UI and API keep working with only PostgreSQL.
