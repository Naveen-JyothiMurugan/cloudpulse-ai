# Contributing

1. `make setup && make up && make seed` (or the Docker-free route: `make test`).
2. Branch from `main`; keep PRs small. Do not commit `.env`, tfvars, dumps or credentials (`python3 scripts/scan_secrets.py` must report 0 findings).
3. Python: `ruff check` + `ruff format` (config in `pyproject.toml`); add unit tests for analytics/ingestion changes and DB tests (`make test-db`) for SQL changes. Never concatenate user input into SQL; use bind parameters and allow-listed identifiers.
4. Schema changes: add a new Alembic revision with explicit SQL; update `schema.sql` only through a migration strategy agreed in the PR; regenerate `docs/DATA_DICTIONARY.md` with `scripts/with_test_db.sh python3 scripts/gen_data_dictionary.py`.
5. Frontend: every data view needs loading, error and empty states; use text rendering for any provider/event data; add a Vitest test. Run `npm run lint && npm run typecheck && npm test`.
6. Docs must not claim a feature works unless it was run; mark status as verified / written / planned.
7. Commit messages: imperative summary + reason. Reviewers check security-sensitive paths (`core/security.py`, `deps.py`, `listing.py`, `gitops/`, `infra/terraform`).
