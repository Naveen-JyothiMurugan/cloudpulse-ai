# Architecture

Status legend: **[verified]** executed in the build sandbox · **[written]** implemented but never executed · **[planned]** not implemented.

## 1. System context

```mermaid
flowchart TB
  user([Analyst / admin]) --> web
  subgraph Local["Docker Compose / Kubernetes"]
    web["web: Next.js 14<br/>(proxies /api/v1)"] --> api["api: FastAPI"]
    api --> pg[(PostgreSQL 16)]
    api --> analytics["analytics package<br/>(pandas, NumPy, scikit-learn)"]
    api --> ingestion["ingestion package<br/>(CSV + event validation)"]
    prom[Prometheus] -- scrape /api/v1/metrics --> api
    graf[Grafana] --> prom
  end
  subgraph AWS["AWS (optional)"]
    s3[(S3 cost-exports/)] --> lambda[Lambda forwarder]
    eb[EventBridge / CloudWatch alarms] --> lambda
    ce[Cost Explorer]
  end
  subgraph Azure["Azure (optional)"]
    blob[(Blob cost-exports)] --> func[Azure Function forwarder]
    acm[Cost Management]
  end
  lambda -- "HTTPS + Bearer INGEST_API_TOKEN" --> api
  func -- "HTTPS + Bearer INGEST_API_TOKEN" --> api
  api -. "read-only, disabled by default" .-> ce
  api -. "read-only, disabled by default" .-> acm
  api -. "redacted prompt, optional" .-> llm[LLM provider]
```

## 2. Component responsibilities

| Component | Responsibility | State |
|---|---|---|
| `apps/web` | UI, forms, charts, loading/empty/error states; holds only the in-memory CSRF token | [written] (syntax-parsed) |
| `apps/api/app/routers` | HTTP layer, auth dependencies, audit calls, error mapping | [written] |
| `apps/api/app/services` | SQL (SQLAlchemy Core `text()` + bind params): ingest, detect, dashboard, alerts | [verified] on PostgreSQL 16 via psql shim |
| `apps/api/app/core` | config, scrypt + session tokens, rate limiter, query helpers, logging, errors, metrics | [verified] (stdlib helpers) |
| `services/analytics` | Anomaly detection, forecasting, recommendation rules, LLM validation/redaction | [verified] |
| `services/ingestion` | CSV schema validation, normalisation, hashing, event validation | [verified] |
| `services/serverless` | Stdlib forwarders used by the Lambda and Azure Function | [verified] with fakes |
| `apps/api/app/adapters` | `demo` (mock), `aws`, `azure` provider adapters; status + read-only connection test | demo [written]; aws/azure [written, never run against a cloud] |
| PostgreSQL | System of record; constraints enforce idempotency | [verified] |

The analytics and ingestion packages deliberately have no web/database imports, so they run and test anywhere.

## 3. Data ingestion sequence

```mermaid
sequenceDiagram
  autonumber
  participant U as User / Lambda / Function
  participant A as FastAPI
  participant V as ingestion.parse_cost_csv
  participant D as PostgreSQL
  U->>A: POST /ingestion/costs (multipart .csv)
  A->>A: authn (cookie+CSRF or bearer), rate limit, size/type check
  A->>D: INSERT ingestion_runs (status=running)
  A->>V: parse + validate (columns, types, currency, dates)
  V-->>A: valid rows (with row_hash) + row errors (max 200 kept)
  A->>D: INSERT cost_records ... ON CONFLICT (row_hash) DO NOTHING
  A->>D: UPDATE ingestion_runs (inserted / duplicate / rejected, status, errors)
  A->>D: INSERT audit_events
  A-->>U: 201 {run_id, status, counts}
```

Statuses: `succeeded` (no rejects), `partial` (some rows rejected), `failed` (nothing accepted → HTTP 422). Re-uploading the same file inserts 0 rows [verified].

## 4. Authentication flow

```mermaid
sequenceDiagram
  participant B as Browser
  participant W as Next.js (proxy)
  participant A as FastAPI
  participant D as PostgreSQL
  B->>W: POST /api/v1/auth/login {email,password}
  W->>A: forward
  A->>A: rate limit (IP, IP+email)
  A->>D: SELECT user + role
  A->>A: scrypt verify (dummy hash if unknown: equal timing)
  alt valid and not locked
    A-->>B: 200 + Set-Cookie cp_session (HttpOnly, SameSite=Lax, Secure in prod) + csrf_token
  else invalid
    A->>D: failed_login_count++, lock after 5, audit
    A-->>B: 401 generic "Invalid email or password."
  end
  B->>A: GET /auth/me (cookie) -> user, csrf_token
  B->>A: POST/PUT/PATCH/DELETE with X-CSRF-Token (double-submit from the signed session)
  A->>D: re-read role on every request (token never carries authority)
  Note over B,A: Expired/invalid cookie -> 401 -> UI redirects to /login?expired=1
```

Service-to-service ingestion uses `Authorization: Bearer $INGEST_API_TOKEN` (constant-time compared); it only unlocks the two ingestion endpoints.

## 5. Anomaly detection flow

```mermaid
flowchart TD
  A["POST /anomalies/run (admin)"] --> B["Load daily cost per provider+service - regions summed, dominant currency only"]
  B --> C{">= min_history_days?"}
  C -- no --> W["warning: skipped series"]
  C -- yes --> D["Rolling median + MAD over window_days<br/>robust z-score, scale floor for flat series"]
  D --> E{"z >= threshold AND abs change >= min_abs AND pct change >= min_pct?"}
  E -- no --> N["not anomalous"]
  E -- yes --> F["Classify severity, build explanation + signals"]
  F --> G["fingerprint = hash of provider/service/date/method"]
  G --> H["INSERT anomalies ... ON CONFLICT (fingerprint) DO NOTHING"]
  H --> I["create alert + recommendation once per new anomaly"]
  I --> J["link operational events: same provider+service within ±1 day"]
```

Re-running changes nothing: 4 detected / 0 new / 4 suppressed on the second run [verified]. Optional `isolation_forest` method (`random_state=42`) is also deterministic [verified].

## 6. CI/CD and GitOps

```mermaid
flowchart LR
  dev[Developer PR] --> ci[GitHub Actions CI<br/>lint, tests, build, audit, scan]
  ci --> merge[merge to main]
  merge --> img[Build + scan images<br/>push to GHCR if PUBLISH_IMAGES=true]
  img --> pr[PR bumps image tag in gitops/environments/dev/values.yaml]
  pr --> git[(Git = desired state)]
  git --> argo[Argo CD]
  argo -- auto-sync --> dev_ns[cloudpulse-dev]
  git -- tag vX.Y.Z + manual Sync --> argo
  argo -- reviewed manual sync --> prod_ns[cloudpulse-prod]
```

[written]; no workflow has run on GitHub and Argo CD was never installed.

## 7. Request path and observability

One middleware assigns `X-Request-ID`, records Prometheus metrics, writes a structured JSON log line, and adds security headers. Errors use one envelope: `{"error": {"code","message","details","request_id"}}`; unexpected exceptions return a generic 500 (details only in logs).

## 8. Key design decisions

See [DECISIONS.md](DECISIONS.md). Deviations from the original brief: Redis omitted; scrypt instead of Argon2/bcrypt; SQLAlchemy Core instead of ORM; services as importable packages instead of separate processes.
