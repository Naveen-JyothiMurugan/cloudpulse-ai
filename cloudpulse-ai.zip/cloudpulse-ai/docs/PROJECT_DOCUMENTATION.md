# CloudPulse AI — Intelligent Cloud Operations and Cost Optimization Platform
## Project report

| | |
|---|---|
| Version | 0.1.0 (portfolio build) |
| Type | Individual portfolio project — full-stack cloud engineering |
| Repository | monorepo `cloudpulse-ai` |
| Status | Code complete for the scoped features; **partially verified** (see §23) |

**Reading guide.** Every capability is tagged **[verified]** (executed in the build sandbox), **[written]** (implemented, never executed), **[optional]** (off by default), or **[planned]**. If a statement has no tag it is a description of design intent.

---

## 1. Title page
CloudPulse AI — Intelligent Cloud Operations and Cost Optimization Platform. Author: the repository owner. Built with AI-assisted engineering (Claude); all code, tests and claims in this report are subject to the verification status in §23.

## 2. Executive summary
CloudPulse AI ingests cloud cost records (CSV or provider APIs) and operational events, stores them in PostgreSQL, and presents cost dashboards, deterministic anomaly detection, a baseline forecast with a measured backtest, rule-based recommendations (with an optional, schema-validated LLM explanation), and an alert/incident workflow. It runs entirely locally with a clearly labelled synthetic dataset, needs no cloud account or AI key, and ships with containers, Helm/Argo CD, Terraform (AWS), CI workflows, observability and a documented security baseline.

What was actually demonstrated: the analytics, ingestion, security helpers, serverless forwarders and the complete SQL layer (123 automated tests passing, 43 of them against a real PostgreSQL 16). On the synthetic dataset the detector finds the four injected spikes and nothing else; the forecast beats a naive benchmark (MAE 20.11 vs 74.41). What was **not** demonstrated: the HTTP API, the frontend, containers, Kubernetes/Terraform, CI and real cloud calls — they were written but could not be run because the build environment had no package registry access and no Docker daemon (§23, §26).

## 3. Problem statement
Teams running on AWS/Azure get cost data and operational signals in separate places. Spend spikes (a runaway autoscaler, a recursive function) are noticed on the invoice, weeks later, and nobody can easily connect the spike to the incident that caused it. Commercial FinOps tools solve this but are expensive and opaque; a learning project that implements the full path — ingest, store, detect, explain, triage — shows how it works end to end.

## 4. Motivation and objectives
Motivation: demonstrate cloud engineering (AWS/Azure integration, serverless, IaC, GitOps), backend and frontend development, applied statistics/ML, security and operations in one coherent system.

Objectives: (1) ingest cost and event data reliably and idempotently; (2) show trustworthy dashboards derived only from stored data; (3) detect cost anomalies reproducibly with explanations; (4) forecast near-term spend with an honest evaluation; (5) turn findings into traceable recommendations; (6) manage alerts/incidents with persistence; (7) be runnable for free; (8) be deployable with reviewable automation; (9) document truthfully.

## 5. Scope and exclusions
In scope: single-tenant app; two roles; CSV and API-based cost ingestion; event ingestion; daily-granularity analytics; one currency at a time; AWS (Terraform) and Azure (documented) optional paths.
Out of scope / not built: multi-tenancy, SSO/MFA, password reset e-mail, budgets and notifications to Slack/e-mail, resource-level (tagging) cost allocation, commitment/rightsizing optimisation, FX conversion, real-time streaming, an Azure Terraform stack, Redis, a mobile app, compliance certification.

## 6. Intended users and use cases
* **FinOps analyst:** reviews trends, filters by provider/service/region, exports CSV, reads the period report.
* **Platform/SRE engineer:** investigates an anomaly, correlates events (±1 day, same provider/service), acknowledges, annotates, resolves, opens an incident.
* **Engineering manager / recruiter (demo):** explores the whole workflow with synthetic data in minutes.
* **Read-only stakeholder:** sees everything, changes nothing.

## 7. Functional requirements and status

| ID | Requirement | Status |
|---|---|---|
| F1 | Login/logout, hashed passwords, RBAC (admin/read-only), no public registration | helpers [verified], HTTP flow [written] |
| F2 | Integrations page: providers, status, test, last sync, missing config, instructions, demo mode | service logic [verified] (sync), API/UI [written] |
| F3 | Cost CSV ingestion with validation, normalisation, dedup, run tracking, pagination | [verified] |
| F4 | Event ingestion, dedup, search/filter | [verified] |
| F5 | Dashboard (totals, change vs previous period, trends, breakdowns, events, alerts, anomalies, freshness, ingestion health) | queries [verified]; UI [written] |
| F6 | Configurable anomaly detection, severity, explanations, storage, dedup, tests | [verified] |
| F7 | Forecast with horizon, minimum data, backtest, MAE, warnings, chart | engine [verified]; chart [written] |
| F8 | Recommendations (rules default, optional LLM, schema validation, fallback) | rules [verified]; LLM client [optional, untested] |
| F9 | Alerts and incidents: filter, detail, ack, resolve, notes, history, persistence | service [verified]; UI [written] |
| F10 | Search/filter/pagination on all lists with validated params and stable sorting | [verified] |
| F11 | CSV exports + period report respecting filters and auth | formatting/query [verified]; routes [written] |
| F12 | Versioned REST API with OpenAPI | [written] |

## 8. Non-functional requirements and status

| Quality | Target | Status |
|---|---|---|
| Reproducibility | same input → same anomalies/fingerprints | [verified] |
| Idempotency | repeated ingestion/detection creates no duplicates | [verified] |
| Security | OWASP-style baseline (see §19) | partly [verified], partly [written] |
| Observability | request IDs, JSON logs, Prometheus metrics, health/readiness | [written] |
| Portability | `docker compose up` on a laptop | [written] |
| Cost | $0 locally; opt-in cloud components | design; see COST_ESTIMATION |
| Performance | no target set or measured; indexes exist on filter columns; 20 s statement timeout | not measured |
| Accessibility | labelled controls, roles, live regions, skip link | not audited |
| Maintainability | framework-free core, lint-clean, documented decisions | [verified] (lint) |

## 9. Feasibility and design trade-offs
Why each major technology was chosen, and alternatives:

| Choice | Why | Alternatives / trade-off |
|---|---|---|
| FastAPI + Pydantic | typed request validation, automatic OpenAPI, async-capable | Django REST (more batteries, heavier), Flask (less structure) |
| PostgreSQL | constraints for idempotency, `jsonb_to_recordset` bulk loads, full-text search, strong consistency | DynamoDB/Cosmos (used only for the optional event store design), SQLite (no concurrency) |
| SQLAlchemy Core `text()` | explicit, reviewable aggregation SQL | ORM (convenience, less control for analytics) |
| Alembic | standard migration tool | Flyway, hand-rolled SQL |
| pandas / scikit-learn | familiar, testable analytics; IsolationForest available | polars (faster), statsmodels/Prophet (richer forecasting) |
| Next.js + Tailwind + Recharts | quick, responsive UI; same-origin proxy | Vite SPA, Streamlit |
| Docker Compose | free local path | Tilt/Skaffold |
| Helm + Argo CD | declarative, reviewable GitOps | Kustomize, Flux |
| Terraform | provider-neutral IaC | CDK, Pulumi, Bicep (Azure) |
| GitHub Actions | native to the repo | GitLab CI, Jenkins |
| Rules-first AI | works offline, auditable | LLM-only (cost, hallucination risk) |
Full ADR list: [DECISIONS.md](DECISIONS.md).

Feasibility risks: unverified integration of untested layers (mitigated by lint/compile/unit coverage of the core and by CI that will exercise the rest); cloud adapters need real accounts to validate; the forecast and detector were evaluated only on author-generated synthetic data.

## 10. System architecture
See [ARCHITECTURE.md](ARCHITECTURE.md) (system context, ingestion sequence, authentication, anomaly flow, CI/CD/GitOps diagrams in Mermaid) and the ER diagram in [DATABASE_DESIGN.md](DATABASE_DESIGN.md). In short: browser → Next.js (same-origin proxy) → FastAPI → PostgreSQL, with importable analytics/ingestion packages, optional cloud adapters, serverless forwarders posting to the API with a bearer token, and Prometheus/Grafana for metrics.

## 11. Component responsibilities
`apps/web` (UI, in-memory CSRF token) · `apps/api/app/routers` (HTTP, authz, audit, error mapping) · `apps/api/app/services` (SQL and orchestration) · `apps/api/app/core` (config, security, rate limiting, query helpers, logging, metrics, errors) · `services/analytics` (detect, forecast, recommend) · `services/ingestion` (validation) · `services/serverless` (forwarders) · `apps/api/app/adapters` (demo/AWS/Azure) · `infra/*`, `gitops/*`, `monitoring/*` (delivery and ops).

## 12. Data flow
1. Source: CSV upload, provider sync, or serverless forwarder. 2. Validation and normalisation (`parse_cost_csv`): required columns, types, ISO dates, uppercase currency, canonical service names (e.g. "Amazon Elastic Compute Cloud" → EC2), lower-case regions, source tagging. 3. Natural-key hash → `INSERT … ON CONFLICT DO NOTHING`. 4. Run record with counts and first 200 row errors. 5. Aggregation queries for the dashboard. 6. On demand: detection → anomalies → alerts + recommendations + event links. 7. Forecast → `forecast_runs`. 8. Exports/reports read the same filtered queries.

## 13. Database design
16 tables (users, roles, cloud_integrations, ingestion_runs, cost_records, operational_events, anomalies, forecast_runs, recommendations, alerts, alert_events, incidents, incident_alerts, incident_events, investigation_notes, audit_events) with PKs, FKs, UNIQUE keys for idempotency, CHECK constraints, indexes, a generated `tsvector` with GIN, an append-only audit trigger and a retention function. See [DATABASE_DESIGN.md](DATABASE_DESIGN.md) and the generated [DATA_DICTIONARY.md](DATA_DICTIONARY.md). Retention: events purge function (manual schedule), S3 lifecycle for raw files; costs/alerts kept indefinitely until a policy is defined.

## 14. API design
Versioned under `/api/v1`, consistent error envelope, page/page_size pagination (max 200), allow-listed sort fields with `id` tie-break, ISO dates, role-based access, CSRF for cookie sessions, bearer token for ingestion. Details and real example payloads: [API_REFERENCE.md](API_REFERENCE.md). OpenAPI is generated by FastAPI at `/api/v1/docs` **[written]**.

## 15. Data ingestion pipeline
**CSV schema** (header row required; names are matched exactly after trimming whitespace; extra columns are ignored): `usage_date` (ISO date), `provider` (`aws|azure|other`), `account_identifier`, `service_name`, `region`, `usage_quantity` (number ≥ 0, optional), `usage_unit`, `cost_amount` (number; negative credits allowed), `currency` (ISO-4217 code, upper-cased), `source_type` (`synthetic|aws_cost_explorer|azure_cost_management|manual_csv`). Limits: 5 MB, 100,000 rows, 200 row errors reported. Sample: `data/sample/synthetic_costs.csv`.

Outcomes: `succeeded`, `partial` (some rows rejected, rest loaded), `failed` (file-level error or nothing loadable; HTTP 422 with details). Every upload creates an `ingestion_runs` row with SHA-256 of the file, counts and errors, even if loading fails. Duplicates: same natural key (date, provider, account, service, region, unit, currency, source) is skipped. **Known limitation:** the amount is not part of the key, so corrected amounts are ignored; an upsert mode is future work. A user can label an upload with a provider `source_type`; the origin banner would then say "provider". Uploads are admin-only, but treat that label as operator-asserted.

Events: schema `event_id, provider, service, environment, severity (info|warning|error|critical), event_type, timestamp (ISO, tz-aware or UTC), message (≤ 2000 chars), correlation_id, metadata (object)`; ≤ 500 per request; duplicates by (`provider`, `event_id`). Serverless path: S3/Blob object → Lambda/Function → `POST /ingestion/costs` with bearer token; retries, DLQ, size/extension checks. Sample payload: `data/sample/sample_event.json`; generator: `scripts/send_test_events.py`.

Synthetic dataset: `scripts/generate_sample_data.py`, seed 20250101: 9 provider/service series (11 service/region combinations) over 120 days with weekly seasonality, mild trend and noise, plus four injected spikes (EC2 ×3.2 on 2025‑02‑14, Lambda ×5.0 on 03‑05, Cosmos DB ×2.6 on 03‑20, S3 ×2.2 on 04‑10) and 38 events (8 narrating the four spikes, 30 background noise). It is labelled synthetic in the data (`source_type=synthetic`, `is_synthetic=true`), in the API, the UI and exports.

## 16. Machine-learning methodology
**Default: robust z-score.** Per (provider, service) daily total — all regions summed — over the dominant currency (so `region` is empty on stored anomalies): for each day with ≥ `min_history_days` (7) prior days, take the median and MAD of the trailing `window_days` (14) days; `scale = max(1.4826·MAD, 5 %·|median|, ε)` (the floor stops flat series from producing huge scores); `z = (value − median)/scale`. A day is flagged only if `z ≥ z_threshold` (3.5) **and** the absolute change ≥ `min_abs_change` (5.0) **and** the percentage change ≥ `min_pct_change` (20 %); decreases are ignored unless `flag_decreases`. Rationale: median/MAD resist earlier spikes in the window; the extra guards suppress statistically significant but financially trivial blips. Reference for the modified z-score idea: Iglewicz & Hoaglin, *How to Detect and Handle Outliers* (1993).

**Severity:** `critical` if z ≥ 3× threshold and (impact ≥ 500 or ≥ 300 %); `high` if z ≥ 2× threshold and (impact ≥ 100 or ≥ 100 %); `medium` if z ≥ 1.25× threshold or impact ≥ 100; else `low`. The money cut-offs are in the series' currency units and are heuristics.

**Optional: IsolationForest** (scikit-learn, 200 trees, `random_state=42`, `contamination` configurable) per series on three features — log cost, deviation from the trailing median, day of week — with the same minimum-change guards applied afterwards; deterministic but less explainable.

**Explanations and storage.** Each anomaly stores observed/expected value, deviation, percentage, score, severity, method, direction, a `signals` JSON (median, MAD, scale used, window points, threshold…), the configuration, and a sentence such as: *"AWS EC2 cost on 2025-02-14 was 898.70 versus an expected 343.83 (+161.4%). Method robust_zscore: score 32.28 against threshold 3.5, baseline window 14 days."* **Deduplication:** `fingerprint` = hash of provider/service/date/method; re-running yields `suppressed_duplicates`. Because the method is part of the fingerprint, running IsolationForest after the robust detector creates separate anomalies (and alerts) for the same day. Detection is a function of the stored data and config only — no randomness, nothing runs on page refresh.

**Evaluation [verified, synthetic only].** On the bundled dataset the detector flags exactly the 4 injected anomalies and no others (precision/recall 1.0 on this data, which the author designed — this demonstrates mechanics, not accuracy). **Limitations and tuning:** seasonal events (month-end, sales days), planned launches, backfilled data, new services with < 7 days of history and slowly ramping runaway costs can cause false positives/negatives; shorter windows react faster but forget seasonality; raise `z_threshold`/`min_pct_change` to reduce noise, lower to increase sensitivity; there is no feedback loop yet to learn from resolved-as-false-positive alerts.

## 17. Forecasting methodology and evaluation
**Method** `seasonal_naive_mean`: total daily cost (dominant currency) is reindexed to a complete daily calendar (missing days = 0); each future day = mean of the same weekday over the last `seasons` (4) weeks, falling back to a moving average where weekly history is missing. Horizon 1–90 days (default 14). Reference: seasonal naive methods in Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3rd ed.), <https://otexts.com/fpp3/>.

**Minimum data:** < 28 points → `insufficient_data`, no forecast, explicit warning. 28–41 points → forecast without backtest (warning "not backtested"). ≥ 42 → rolling-origin backtest at up to 3 origins (`n − h`, `n − 2h`, `n − 3h`), reporting MAE of the model, MAE of a last-value naive benchmark, MAE as % of mean daily level, whether the model beats the benchmark, and origins used. The reported band is ± the 80th percentile of absolute backtest errors — a heuristic, not a calibrated confidence interval.

**Result [verified, synthetic only]:** 120 points, 14-day horizon, 3 origins: MAE 20.11 vs naive 74.41 (2.14 % of mean level); 14-day forecast total 13,215.76 USD. The data have clean weekly seasonality by construction, so real data will almost certainly score worse. No savings or accuracy are promised. The forecast ignores anomalies (it forecasts the stored total, spikes included), growth trends beyond the 4-week average, holidays and planned changes.

## 18. AI recommendation design
Pipeline: anomaly → `build_recommendation` (deterministic rules) → stored once per anomaly (UNIQUE `anomaly_id`). Fields: summary, **evidence** (list of measured facts copied from the anomaly), potential impact (explicitly "simple extrapolation, not a prediction"), confidence note (what the method cannot tell), ordered next steps (different for increases and decreases), provider/service, timestamp, `requires_human_review` (true for high/critical or decreases), `source` (`rules` or `rules+llm`).

Optional LLM layer (**[optional]**, off unless `LLM_PROVIDER` and `LLM_API_KEY` are set server-side): the prompt contains only measured aggregates (secrets pattern-redacted); the response must be JSON with exactly `explanation` (non-empty string, bounded) and `caveats` (≤ 5 short strings); anything else → discarded, rule text kept, fallback metric incremented. The LLM cannot execute actions; its text goes to `ai_explanation_json` and the UI shows it under "AI-generated explanation (not a measured fact)". Provider data and event messages are treated as untrusted data in the prompt. The HTTP client for the provider was **not** exercised against a real service.

## 19. Security and threat model
Controls, evidence and gaps: [SECURITY.md](SECURITY.md). Assets, trust boundaries, STRIDE table and residual risks: [THREAT_MODEL.md](THREAT_MODEL.md). Highlights: scrypt hashing; signed expiring HttpOnly cookie; CSRF double-submit; server-side RBAC with DB-read role; lockout + rate limits; allow-listed query building and bind parameters; upload limits; append-only audit; sanitised errors; startup validation of unsafe production config; non-root, read-only containers; least-privilege Terraform IAM. The system is **not** claimed to be secure — no independent review or penetration test was performed, and the HTTP layer was never run.

## 20. CI/CD and GitOps workflow
Workflows (`.github/workflows`): **ci.yml** (ruff lint/format; unit + Postgres-service integration tests; API e2e against a live uvicorn; web lint/typecheck/test/build; Terraform fmt/validate; Helm lint/template; Compose config), **security.yml** (pip-audit, npm audit, secret scan, Trivy IaC scan, weekly schedule), **images.yml** (build API/web images, Trivy scan, optional GHCR push when `PUBLISH_IMAGES=true`, using `GITHUB_TOKEN`; no stored cloud secrets). Default permissions are `contents: read`; `packages: write` only on the image job. Actions are pinned to major/minor tags — pinning to commit SHAs is recommended before production use. **None of these workflows has ever run.** GitOps: [GITOPS_GUIDE.md](GITOPS_GUIDE.md).

## 21. Infrastructure deployment
Terraform (AWS) under `infra/terraform`: storage (S3 + DynamoDB), secrets containers, ingestion Lambda + DLQ + least-privilege role, monitoring (SNS, alarms, log group), optional app host (EC2 + SSM, IMDSv2, encrypted gp3) and optional RDS (encrypted, managed password, deletion protection). All tagged, cost-conscious, `terraform apply` never executed by the author, not even `validate`. Helm chart `infra/helm/cloudpulse` (probes, resource limits, non-root, read-only rootfs, NetworkPolicies, PreSync migration Job, optional HPA/Ingress). Azure: documented alternative. Guide: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md); costs: [COST_ESTIMATION.md](COST_ESTIMATION.md).

## 22. Observability and reliability
Structured JSON logs with request IDs (`X-Request-ID` propagated/generated); Prometheus metrics: `cloudpulse_http_requests_total`, `cloudpulse_http_request_duration_seconds`, `cloudpulse_ingestion_runs_total`, `cloudpulse_ingestion_rows_total`, `cloudpulse_anomalies_detected_total`, `cloudpulse_detection_runs_total`, `cloudpulse_detection_duration_seconds`, `cloudpulse_db_up`, `cloudpulse_llm_fallbacks_total`; `/health` (liveness, no dependencies) and `/ready` (DB + schema). Prometheus config, alert rules and a Grafana dashboard are provided (`make monitoring`) — **[written, never run]**. Failure scenarios, retry/timeout policy, backup/restore, alert thresholds and dependencies: [TROUBLESHOOTING.md](TROUBLESHOOTING.md). A controlled local failure simulation (`scripts/chaos_local.sh`, stop the DB and observe `/ready` → 503, recovery) is provided and **not run**.

## 23. Testing strategy and actual results
Strategy: [TEST_PLAN.md](TEST_PLAN.md). Actual results (final run): **80 unit tests OK, 43 database/service tests OK on PostgreSQL 16.15 (via psql shim), ruff clean, secret scan clean, configs parse, scripts syntax-check** — details, caveats and the explicit list of what was *not* executed: [TEST_RESULTS.md](TEST_RESULTS.md). In particular the HTTP layer, frontend tests, containers, IaC and CI were not run, so the brief's completion criteria on "frontend and backend run locally", "authentication tested over HTTP", "restart persistence" and "CI workflows" remain **open** until executed.

## 24. Setup and execution guide
Quick start, no-Docker test commands, configuration and admin bootstrap: [README.md](../README.md). Deployment paths: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md). Reproduce the verified results: `make test-unit` and `make test-db` (needs PostgreSQL 16 server binaries on the PATH or in `/usr/lib/postgresql/16/bin`; `scripts/with_test_db.sh` starts a throw-away cluster on port 5433 and removes it).

## 25. Sample demonstrations
Walkthrough: [DEMO_SCRIPT.md](DEMO_SCRIPT.md). Real captured outputs (dashboard summary, detection, forecast, recommendation, ingestion counts) are embedded in [API_REFERENCE.md](API_REFERENCE.md).

## 26. Known limitations
1. HTTP API, frontend, containers, IaC, CI: written but unexecuted (§23). Expect first-run fixes.
2. In-process rate limiter → one API replica.
3. Corrected amounts in re-uploads are ignored (no upsert).
4. `source_type` on uploads is operator-asserted.
5. Single-currency analytics; no FX conversion.
6. Stateless sessions cannot be revoked before expiry; no MFA/password reset.
7. No CSP/HSTS on the UI by default.
8. Detector and forecast evaluated only on synthetic data; false positives on seasonal spend are expected on real data.
9. AWS/Azure adapters (including pagination of Azure results, Cost Explorer grouping by service only) never tested against real accounts; Azure query response paging (`nextLink`) is not followed.
10. Retention policies are manual (purge function, no scheduler installed); costs/alerts unbounded.
11. Terraform has no remote state backend or Azure stack; Lambda code is packaged by a script, not built in CI.
12. Accessibility and performance unmeasured.

## 27. Cost considerations
Local use is free. Optional AWS defaults are roughly a few dollars per month; the EC2 host and RDS are opt-in and each add roughly $15–20 per month (estimates, not verified against live pricing). See [COST_ESTIMATION.md](COST_ESTIMATION.md) for assumptions and teardown. Hosting is not promised to be free.

## 28. Future improvements
Run and fix the untested layers first (`make up`, `make test-web`, CI); add upsert/correction mode for cost rows; Redis-backed rate limiting and token revocation; Argon2id; CSP for the UI; budgets and notification channels; tag-based cost allocation; richer forecasting (ETS/Prophet) with trend and holiday handling; a feedback loop to tune thresholds from resolved alerts; background scheduler for sync/detect/purge; Azure Terraform; OpenTelemetry tracing; SHA-pinned Actions and signed images (cosign); contract tests for the cloud adapters with recorded responses; accessibility audit.

## 29. Conclusion
The project delivers a coherent, documented cloud-cost intelligence platform whose analytical core and data layer are tested and reproducible, and whose delivery tooling is complete in source form. Its honest status is "feature-complete, partially verified": the next step for anyone adopting it is to run the stack and CI, fix what breaks, and then validate the cloud adapters against a real (budget-limited) account.

## 30. References and official documentation
The links point to vendor or project documentation; they were not re-fetched during this build, so check them if one has moved.

* FastAPI — <https://fastapi.tiangolo.com/> · Pydantic — <https://docs.pydantic.dev/>
* PostgreSQL 16 — <https://www.postgresql.org/docs/16/> (text search, `INSERT … ON CONFLICT`, JSON functions)
* SQLAlchemy — <https://docs.sqlalchemy.org/> · Alembic — <https://alembic.sqlalchemy.org/>
* pandas — <https://pandas.pydata.org/docs/> · scikit-learn IsolationForest — <https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.IsolationForest.html>
* Python `hashlib.scrypt` — <https://docs.python.org/3/library/hashlib.html>
* Next.js — <https://nextjs.org/docs> · Tailwind CSS — <https://tailwindcss.com/docs> · Recharts — <https://recharts.org/> · Vitest — <https://vitest.dev/> · Playwright — <https://playwright.dev/>
* Docker — <https://docs.docker.com/> · Docker Compose — <https://docs.docker.com/compose/>
* Kubernetes — <https://kubernetes.io/docs/> · Helm — <https://helm.sh/docs/> · kind — <https://kind.sigs.k8s.io/> · Argo CD — <https://argo-cd.readthedocs.io/>
* Terraform AWS provider — <https://registry.terraform.io/providers/hashicorp/aws/latest/docs>
* AWS Cost Explorer API — <https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/Welcome.html> · AWS Lambda — <https://docs.aws.amazon.com/lambda/> · Amazon S3 event notifications — <https://docs.aws.amazon.com/AmazonS3/latest/userguide/EventNotifications.html>
* Azure Cost Management Query API — <https://learn.microsoft.com/rest/api/cost-management/query/usage> · Azure Functions — <https://learn.microsoft.com/azure/azure-functions/>
* OWASP Password Storage Cheat Sheet — <https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html> · OWASP CSRF Prevention Cheat Sheet — <https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html>
* Prometheus — <https://prometheus.io/docs/> · Grafana — <https://grafana.com/docs/>
* Hyndman & Athanasopoulos, *Forecasting: Principles and Practice*, 3rd ed. — <https://otexts.com/fpp3/>
* Iglewicz & Hoaglin, *How to Detect and Handle Outliers*, ASQC Quality Press, 1993 (book; no link).
