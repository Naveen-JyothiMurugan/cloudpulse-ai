# API reference

Base path `/api/v1`. The authoritative, always-current contract is the generated OpenAPI document at `/api/v1/docs` (Swagger UI) and `/api/v1/openapi.json`. This file explains conventions and gives examples. **The HTTP layer has not been executed in the build sandbox**; the response bodies below that come from the service layer (dashboard summary, detection, forecast, recommendation) are real outputs captured from the sample dataset on PostgreSQL 16; other examples show the shape defined in code.

## Conventions

* **Auth:** `cp_session` HttpOnly cookie from `POST /auth/login`. State-changing requests (POST/PUT/PATCH/DELETE) also need header `X-CSRF-Token` (value returned by login and `/auth/me`). Ingestion endpoints additionally accept `Authorization: Bearer <INGEST_API_TOKEN>` (no CSRF needed). Roles: `admin` (everything) and `readonly` (all GET endpoints and exports; no mutations).
* **Errors** (all non-2xx): `{"error": {"code": "validation_error", "message": "...", "details": [...], "request_id": "..."}}`.

| Status | Codes | Meaning |
|---|---|---|
| 400 | `invalid_file` | wrong extension / content type |
| 401 | `not_authenticated`, `invalid_credentials`, `session_expired` | missing/expired session, bad credentials (generic message) |
| 403 | `forbidden`, `csrf_failed` | role too low, CSRF token missing/invalid |
| 404 | `not_found` | unknown resource or provider |
| 409 | `conflict`, `not_configured`, `not_enabled` | invalid state transition; enabling an unconfigured provider |
| 413 | `file_too_large`, `too_many_events` | > 5 MB CSV; > 500 events per request |
| 422 | `validation_error`, `invalid_csv` | bad query/body; CSV rejected entirely |
| 429 | `rate_limited` | with `Retry-After` header |
| 502 | `provider_error` | cloud provider call failed (no provider detail returned) |
| 500/503 | `internal_error`, `not_ready` | generic message only; detail in server logs |

* **Pagination:** `?page=1&page_size=25` (max 200). Response: `{"items": [...], "total": 1320, "page": 1, "page_size": 25, "pages": 53}`.
* **Sorting:** `sort_by` (allow-listed per endpoint) and `sort_dir=asc|desc`; ties are broken by `id` so pages are stable.
* **Dates:** `date_from`, `date_to` as `YYYY-MM-DD` (inclusive); `date_from > date_to` → 422.
* **Search:** `q` (substring, LIKE wildcards escaped; event search also uses full-text).
* **Rate limits** (in-process, per replica): login 5 per 5 min per IP+email (and 20 per IP); uploads 10/min; events 60/min.

## Endpoints

| Method & path | Role | Purpose |
|---|---|---|
| `POST /auth/login` · `POST /auth/logout` · `GET /auth/me` | public · any · any | session management |
| `GET /health` · `GET /ready` · `GET /metrics` | public | liveness · DB+schema readiness · Prometheus |
| `GET /integrations` | any | providers, status, missing config, setup steps |
| `PUT /integrations/{provider}` | admin | enable/disable (`409 not_configured` if config missing; demo cannot be disabled) |
| `POST /integrations/{provider}/test` | admin | read-only connection test |
| `POST /integrations/{provider}/sync` | admin | pull cost data (body `{date_from?, date_to?}`, default last 30 days) from an *enabled* AWS/Azure provider through the same validation/dedup as uploads; `409 not_enabled`, `502 provider_error` (sanitised) |
| `POST /integrations/demo/load` | admin | load bundled SYNTHETIC dataset (idempotent) |
| `POST /ingestion/costs` | admin or bearer | upload cost CSV (multipart field `file`) |
| `GET /ingestion/runs` · `GET /ingestion/runs/{id}` | any | run history and row errors |
| `GET /costs` | any | paginated cost records (filters: date range, provider, service, region, source_type, synthetic, q) |
| `GET /costs/summary` | any | totals, previous-period comparison, breakdowns, data origin, freshness |
| `GET /costs/timeseries` | any | `granularity=day|month`, `group_by=none|provider|service|region` |
| `GET /dashboard` | any | everything the overview page needs |
| `POST /events` | admin or bearer | one event or `{"events":[...]}` (≤ 500) |
| `GET /events` · `GET /events/{id}` | any | search/filter (severity, provider, service, environment, event_type, correlation_id, q, dates) |
| `POST /anomalies/run` | admin | run detection (body: optional `config`, `date_from`, `date_to`) |
| `GET /anomalies` · `GET /anomalies/{id}` | any | list/detail (with recommendation and alert) |
| `POST /forecasts/run` | admin | body `{"horizon_days": 14}` (1–90) |
| `GET /forecasts/latest` · `GET /forecasts` | any | latest run with history/forecast/evaluation · run history |
| `GET /recommendations` · `GET /recommendations/{id}` | any | filters: provider, service, requires_review, source, q, dates |
| `GET /alerts` · `GET /alerts/{id}` | any | filters: severity, status (`open|acknowledged|resolved|unresolved`), provider, service, q, dates |
| `POST /alerts/{id}/acknowledge` · `/resolve` · `/notes` | admin | lifecycle + investigation note (≤ 4000 chars) |
| `GET /incidents` · `POST /incidents` · `GET/PATCH /incidents/{id}` · `POST /incidents/{id}/notes` | any / admin | incident history and management |
| `GET /exports/{costs,cost-summary,anomalies,events,alerts,forecasts}.csv` · `GET /exports/report.md` | any | exports honour the same filters as the list endpoints |

Alert transitions: `open → acknowledged → resolved`; re-acknowledging is a no-op; acknowledging a resolved alert → 409. Incident transitions: `open ⇄ investigating`, either → `resolved`/`closed`; `closed` is terminal.

CSV exports neutralise spreadsheet-formula injection (cells starting with `= + - @` are prefixed) and are capped at 50,000 rows.

## Examples

### Sign in
```http
POST /api/v1/auth/login
{"email": "admin@example.com", "password": "…"}

200 OK   Set-Cookie: cp_session=…; HttpOnly; SameSite=Lax; Path=/
{"id": 1, "email": "admin@example.com", "role": "admin", "csrf_token": "…"}
```
Failure: `401 {"error": {"code": "invalid_credentials", "message": "Invalid email or password.", …}}` — identical for unknown user, wrong password and locked account.

### Upload cost CSV
```bash
curl -b cookies.txt -H "X-CSRF-Token: $CSRF" -F "file=@data/sample/synthetic_costs.csv;type=text/csv" \
     http://localhost:8000/api/v1/ingestion/costs
```
Real service output for the bundled file (first load, then repeated load):
```json
{"run_id": 1, "status": "succeeded", "rows_total": 1320, "rows_inserted": 1320, "rows_duplicate": 0, "rows_rejected": 0,
 "errors_truncated": false, "file_sha256": "b773233e…8086e7"}
```
Second upload of the same file: `rows_inserted: 0, rows_duplicate: 1320`.

CSV columns: `usage_date, provider, account_identifier, service_name, region, usage_quantity, usage_unit, cost_amount, currency, source_type` (see the sample file). Rejected rows are reported as `{"line", "field", "message"}` (max 200 kept).

### Cost summary (real output, sample data, abbreviated)
```json
GET /api/v1/costs/summary
{"has_data": true, "currency": "USD",
 "period": {"from": "2025-04-01", "to": "2025-04-30", "days": 30},
 "previous_period": {"from": "2025-03-02", "to": "2025-03-31"},
 "total_cost": 28359.89, "previous_period_total": 27552.72, "change_amount": 807.17, "change_percent": 2.93,
 "by_provider": [{"name": "aws", "cost": 17124.09}, {"name": "azure", "cost": 11235.8}],
 "by_service": [{"name": "EC2", "cost": 10233.56}, {"name": "Virtual Machines", "cost": 7939.71}, "…"],
 "data_origin": "synthetic", "source_types": ["synthetic"]}
```
With no dates the window is the 30 days ending at the latest stored usage date (demo data is from 2025, so "today" would be empty).

### Run anomaly detection (real output)
```json
POST /api/v1/anomalies/run   {}
{"status": "ok", "detected": 4, "new": 4, "suppressed_duplicates": 0, "alerts_created": 4,
 "recommendations_created": 4, "by_severity": {"critical": 2, "high": 2}, "warnings": [],
 "config": {"method": "robust_zscore", "window_days": 14, "min_history_days": 7, "z_threshold": 3.5,
            "min_abs_change": 5.0, "min_pct_change": 20.0, "flat_series_floor_pct": 5.0,
            "contamination": 0.03, "random_state": 42, "flag_decreases": false}}
```
Second run: `detected: 4, new: 0, suppressed_duplicates: 4`. Unknown or out-of-range config values → 422.

### Anomaly explanation (real output)
`"AWS EC2 cost on 2025-02-14 was 898.70 versus an expected 343.83 (+161.4%). Method robust_zscore: score 32.28 against threshold 3.5, baseline window 14 days."`

### Forecast (real output, abbreviated)
```json
POST /api/v1/forecasts/run   {"horizon_days": 14}
{"id": 1, "status": "ok", "data_points": 120, "currency": "USD", "is_synthetic": true, "forecast_total": 13215.76,
 "forecast": [{"date": "2025-05-01", "value": 995.3, "lower": 969.85, "upper": 1020.75}, "…"],
 "evaluation": {"metric": "MAE", "mae": 20.11, "naive_last_value_mae": 74.41, "relative_to_mean_level_pct": 2.14,
                "beats_naive_benchmark": true, "origins_used": 3, "horizon_days": 14,
                "note": "Computed on the supplied dataset only; not a guarantee of future accuracy."},
 "warnings": []}
```
Fewer than 28 daily points → `status: "insufficient_data"` with a warning and no forecast; fewer than 42 → forecast without backtest.

### Recommendation (real output, first finding)
```json
{"summary": "EC2 spend on AWS rose to 898.70 on 2025-02-14, +161.4% versus the expected 343.83.",
 "potential_impact": "Observed deviation of +554.87 for the day; sustained for a month this could be roughly +16,646.10 (simple extrapolation, not a prediction).",
 "confidence_note": "Based on a statistical baseline only; it shows the value is unusual, not why. The baseline used 14 prior days. Seasonal or one-off business events can cause false positives.",
 "requires_human_review": true,
 "next_steps": ["Open the EC2 cost breakdown for 2025-02-14 and compare regions and accounts.", "…"],
 "source": "rules"}
```
Over the API the fields are `evidence_json`, `next_steps_json`, `ai_explanation_json` (null unless an LLM is configured; always labelled AI-generated).

### Ingest an event
```bash
curl -X POST http://localhost:8000/api/v1/events -H "Authorization: Bearer $INGEST_API_TOKEN" \
  -H "Content-Type: application/json" -d @data/sample/sample_event.json
```
```json
{
  "event_id": "evt-1001",
  "provider": "aws",
  "service": "Lambda",
  "environment": "demo",
  "severity": "warning",
  "event_type": "throttle",
  "timestamp": "2025-03-02T10:15:00Z",
  "message": "Concurrent execution limit reached",
  "correlation_id": "req-77",
  "metadata": {
    "region": "us-east-1"
  },
  "is_synthetic": true
}
```
Response `201 {"created": 1, "duplicates": 0, "rejected": 0, "results": [...]}`; resending → `duplicates: 1`. Severities: `info|warning|error|critical`. `scripts/send_test_events.py` generates test events.

### Resolve an alert
```http
POST /api/v1/alerts/3/acknowledge   (X-CSRF-Token required)
POST /api/v1/alerts/3/notes         {"body": "Confirmed planned migration, ticket OPS-123."}
POST /api/v1/alerts/3/resolve
```
Each call returns the full alert detail (anomaly, recommendation, related events, notes, incidents).
