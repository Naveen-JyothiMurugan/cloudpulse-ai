# Database design

PostgreSQL 16. The schema is a single SQL file, `apps/api/db/schema.sql`, applied by Alembic migration `0001_initial_schema` and by the integration tests, so tested SQL = deployed SQL. Column-level detail is in [DATA_DICTIONARY.md](DATA_DICTIONARY.md) (generated from the live catalog).

## Entity relationships (generated from real foreign keys)

```mermaid
erDiagram
    alerts ||--o{ alert_events : "alert_id"
    operational_events ||--o{ alert_events : "event_id"
    users ||--o{ alerts : "acknowledged_by"
    anomalies ||--o{ alerts : "anomaly_id"
    users ||--o{ alerts : "resolved_by"
    users ||--o{ audit_events : "actor_id"
    users ||--o{ cloud_integrations : "updated_by"
    ingestion_runs ||--o{ cost_records : "ingestion_run_id"
    users ||--o{ forecast_runs : "created_by"
    alerts ||--o{ incident_alerts : "alert_id"
    incidents ||--o{ incident_alerts : "incident_id"
    operational_events ||--o{ incident_events : "event_id"
    incidents ||--o{ incident_events : "incident_id"
    users ||--o{ incidents : "created_by"
    users ||--o{ incidents : "owner_id"
    users ||--o{ ingestion_runs : "user_id"
    alerts ||--o{ investigation_notes : "alert_id"
    users ||--o{ investigation_notes : "author_id"
    incidents ||--o{ investigation_notes : "incident_id"
    anomalies ||--o{ recommendations : "anomaly_id"
    roles ||--o{ users : "role_id"
```

## Design notes

| Concern | Decision |
|---|---|
| Idempotent cost ingestion | `cost_records.row_hash` (SHA-256 over the natural key: date, provider, account, service, region, usage unit, currency, source type — not the amounts) is UNIQUE; inserts use `ON CONFLICT DO NOTHING`. Re-upload → 0 inserted [tested]. **Consequence:** a re-upload that corrects the *amount* of an existing key is ignored as a duplicate (no update path yet; see known limitations). |
| Event dedup | UNIQUE (`provider`, `external_event_id`). |
| Anomaly / alert dedup | UNIQUE `fingerprint` on `anomalies` and `alerts`; one recommendation per anomaly (UNIQUE `anomaly_id`). |
| Synthetic vs real | `is_synthetic` plus `source_type`; a CHECK constraint forces them to agree (a "synthetic" source cannot be marked real, and vice versa) [tested]. |
| Currency | 3-letter uppercase CHECK; analytics use the dominant currency only (no FX conversion) and warn when others exist. |
| Search | `operational_events.search_vector` is a generated `tsvector` with a GIN index; filters also use B-tree indexes on date/severity/provider. |
| Secrets | None stored. `cloud_integrations` holds only enabled flag, status, timestamps. Password hashes (scrypt) live in `users`. |
| Audit | `audit_events` is append-only: a trigger rejects UPDATE/DELETE [tested]. |
| Referential integrity | Foreign keys everywhere; join tables cascade from alerts/incidents; user references use `ON DELETE SET NULL` where history must survive; anomalies→alerts uses SET NULL, anomalies→recommendations CASCADE. |
| Roles | `roles` table (`admin`, `readonly`); role is re-read from the database on each request. |

## Retention and deletion

* `purge_old_events(days)` deletes operational events older than N days (any severity, including events linked to alerts or incidents; the link rows cascade) [tested: removes old rows, keeps recent rows]. Schedule it yourself, e.g. `SELECT purge_old_events(180);` from a Kubernetes CronJob. No schedule is installed by default.
* Cost records, anomalies and alerts have no automatic expiry; define a policy before using real billing data.
* Raw S3 exports expire via the lifecycle rule in Terraform (`raw_data_retention_days`).
* Deleting a user: deactivate (`is_active=false`) rather than delete, to keep audit history readable.
* `make reset` / `python -m app.cli reset-dev-data --yes` clears business data in development only and refuses when `APP_ENV=production`.

## Backup and restore

`scripts/backup_db.sh backup|restore` wraps `pg_dump -Fc` / `pg_restore --clean` for the Compose database [written, not run against Docker]. Managed deployments should use the platform's automated backups (RDS: 7-day retention configured in Terraform, point-in-time recovery available).
