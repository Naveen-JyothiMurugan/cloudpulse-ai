# Test plan

| Layer | What | Where | How to run | Needs |
|---|---|---|---|---|
| Unit – analytics | detector (normal/anomalous/flat/short/spike-in-window series), severity, determinism, fingerprints, IsolationForest, forecast (insufficient/backtest/warnings), recommendation rules, LLM schema validation + redaction + fallback | `tests/unit/test_analytics.py` | `make test-unit` | pandas, NumPy, scikit-learn |
| Unit – ingestion | CSV columns/types/dates/currency/normalisation, row hash, duplicate rows, limits, CSV injection, event validation | `tests/unit/test_ingestion.py` | `make test-unit` | stdlib |
| Unit – core | scrypt, session tokens (tamper/expiry), CSRF, rate limiter, query helpers, config validation | `tests/unit/test_core.py` | `make test-unit` | stdlib |
| Unit – serverless | multipart, retries, 4xx no-retry, https enforcement, S3/EventBridge handlers | `tests/unit/test_serverless.py` | `make test-unit` | stdlib |
| DB – schema | constraints, uniqueness, append-only audit, cascades, retention function | `tests/integration/test_schema_postgres.py` | `make test-db` | PostgreSQL 16 binaries |
| DB – services | ingestion idempotency, detection + suppression, alert linking, forecast persistence, lifecycle, dashboard-vs-raw-SQL, listings/filters, injection inertness, provider sync | `tests/integration/test_services_db.py` | `make test-db` | PostgreSQL 16 binaries |
| API workflow (E2E) | 12-step scenario: start, authenticate (reject wrong password), upload CSV (+re-upload), run history, summary/timeseries/dashboard, detection (+re-run), forecast, recommendation, event ingest (+duplicate), ack/note/resolve, exports, **persistence across API restart** | `tests/e2e/api_workflow.py` | `make up && make seed && make test-e2e` (`--restart-cmd "docker compose restart api"`) | running stack |
| Frontend unit/component | API client (CSRF, error mapping, network failure), formatters, chart pivot, StateView (loading/error/401/empty), origin banner, pager, date filter, login validation + flow, dashboard rendering/filtering/error/empty | `apps/web/src/__tests__` | `make test-web` | npm packages |
| Browser E2E | sign-in, dashboard banner, alert acknowledge, sign-out | `apps/web/e2e/workflow.spec.ts` | `npx playwright test` with `E2E_EMAIL/E2E_PASSWORD` | running stack, Playwright browsers |
| Failure simulation | stop DB → `/ready` 503 sanitised, `/health` 200, recovery | `scripts/chaos_local.sh` | `bash scripts/chaos_local.sh` | Compose stack |
| Static | ruff lint/format, secret scan, YAML/shell syntax, Makefile dry-run | CI + local | `make lint`, `python3 scripts/scan_secrets.py` | ruff |

Deterministic fixtures: `data/sample/*` generated with seed 20250101 (`scripts/generate_sample_data.py`); ground truth lists the four injected anomalies. Tests rely on these files and on small inline datasets.

Not covered by any automated test: real AWS/Azure calls, the LLM HTTP client, browser rendering/visual correctness, load/performance, accessibility audits (the markup uses labels, roles and live regions but was never checked with a tool), Terraform/Helm rendering.
