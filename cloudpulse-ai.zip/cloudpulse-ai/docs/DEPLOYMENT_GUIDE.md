# Deployment guide

Three separate paths. Only **A** can be exercised without cloud spend. **Nothing in B or C has been run by the author** (no Docker daemon, Terraform, Helm or cluster in the build sandbox). Treat every command as a starting point and review it.

## A. Local development (Docker Compose) — free

```bash
make setup && make up && make seed      # see README
make monitoring                          # optional Prometheus (9090) + Grafana (3001, admin password = GRAFANA_ADMIN_PASSWORD from .env)
make down                                # stop; `make reset` also deletes the database volume
```
Ports bind to 127.0.0.1 only. The API runs migrations on start (`RUN_MIGRATIONS=1`).

### Local Kubernetes (kind) — free
```bash
scripts/kind_local.sh up      # builds images, creates kind cluster, dev Postgres, installs the Helm chart
kubectl -n cloudpulse port-forward svc/cloudpulse-web 8080:80   # http://localhost:8080
scripts/kind_local.sh down
```
Uses `config.appEnv=development` and `cookieSecure=false` for plain HTTP. kind's default CNI does not enforce NetworkPolicy, so the script disables it; use Calico/Cilium to test the policies. Create the admin: `kubectl -n cloudpulse exec deploy/cloudpulse-api -- env CLOUDPULSE_ADMIN_PASSWORD='…' python -m app.cli create-admin --email you@example.com`.

## B. Optional AWS deployment (Terraform) — costs money

1. Read [COST_ESTIMATION.md](COST_ESTIMATION.md). Decide which optional components you want (`enable_app_host`, `enable_rds`).
2. `bash scripts/package_serverless.sh` → `dist/aws_lambda.zip`.
3. `cd infra/terraform && cp envs/dev.tfvars.example envs/dev.tfvars` and edit.
4. `terraform init && terraform validate && terraform plan -var-file=envs/dev.tfvars -out=tfplan` — **review the plan line by line**. Configure a remote state backend before collaborating.
5. `terraform apply tfplan` only after explicit authorisation of the target account.
6. Put secret values outside Terraform: `aws secretsmanager put-secret-value --secret-id <ingest_token_secret_arn> --secret-string "$(openssl rand -base64 36)"`, and use the same value as `INGEST_API_TOKEN` on the API.
7. Upload a CSV to `s3://<raw bucket>/cost-exports/` to trigger the Lambda (it forwards to `api_url`).
8. **Teardown:** `terraform destroy -var-file=envs/dev.tfvars`. The raw bucket is versioned and `force_destroy=false`: empty it first. RDS has deletion protection and a final snapshot — disable protection first and delete the snapshot yourself if you do not want it.

Defaults create: S3 bucket (encrypted, versioned, TLS-only, public access blocked, lifecycle expiry), DynamoDB on-demand events table, two Secrets Manager secret containers, SNS alarm topic, CloudWatch log group, and — only when `api_url` is set — the ingestion Lambda with a DLQ and alarms. The app host is a single SSM-managed EC2 instance with no inbound rules (use SSM port forwarding or add your own load balancer/TLS). Azure is **not** provisioned by Terraform here; the Azure Function code is in `services/serverless/azure_function` and is deployed with Azure Functions Core Tools or your own IaC (`az functionapp deployment source config-zip` with `dist/azure_function.zip`) — documented, untested.

## C. Production (guidance, not a turnkey setup)

* Run the API and web as containers (Kubernetes via Helm + Argo CD, or any container platform) behind HTTPS; set `APP_ENV=production`, `COOKIE_SECURE=true`, a random 32+ char `SECRET_KEY`, explicit `CORS_ORIGINS`.
* Use a managed PostgreSQL with automated backups and test restores (`scripts/backup_db.sh` is for Compose).
* Scale the web tier freely; keep **one API replica** until the in-process rate limiter is replaced with a shared store.
* Schedule `SELECT purge_old_events(<days>)` and monitor alerts in [monitoring/alert-rules.yml](../monitoring/alert-rules.yml).
* Change management through GitOps: [GITOPS_GUIDE.md](GITOPS_GUIDE.md).

## Optional cloud integrations

The app never accepts cloud credentials in the browser. Configure on the server, then use **Integrations → Test connection → Enable → Sync**.

### AWS
Set `AWS_REGION` (and optionally `AWS_ROLE_ARN`, `AWS_S3_BUCKET`, `AWS_DYNAMODB_TABLE`); give the API an IAM role (instance profile, task role, IRSA) or local SSO credentials. Enable Cost Explorer in the Billing console (it may take up to 24 h to populate). Install `boto3` in the image (it is optional and commented in `requirements.txt`). Least-privilege policy for the cost reader:
```json
{ "Version": "2012-10-17", "Statement": [
  {"Effect": "Allow", "Action": ["ce:GetCostAndUsage"], "Resource": "*"},
  {"Effect": "Allow", "Action": ["sts:GetCallerIdentity"], "Resource": "*"},
  {"Effect": "Allow", "Action": ["cloudwatch:GetMetricData", "cloudwatch:ListMetrics"], "Resource": "*"} ] }
```
(Cost Explorer API requests are billed by AWS per request — confirm current pricing; the sync makes a handful per run.)

### Azure
Set `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID` (and `AZURE_CLIENT_ID` for a user-assigned managed identity). Grant the identity **Cost Management Reader** and **Reader** at subscription scope; install `azure-identity` in the image. The adapter calls the Cost Management Query API with a managed-identity token.

### Testing the adapters
`test_connection` is read-only (STS `GetCallerIdentity` / a token + subscription read). There are no automated tests that call real clouds; unit tests use fakes for the sync path only. Treat the first real sync as an integration test and compare totals against the cloud console.
