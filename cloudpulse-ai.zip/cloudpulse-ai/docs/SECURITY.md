# Security

This is a portfolio-grade baseline. The controls below exist in code; that does **not** make the system "secure". Items marked **[not executed]** are in code paths that were never run end to end (the FastAPI layer could not be started in the build sandbox).

| Control | Implementation | Evidence |
|---|---|---|
| Password hashing | `hashlib.scrypt` (N=2^15, r=8, p=1, 16-byte salt), format `scrypt$N$r$p$salt$hash`, constant-time compare; dummy-hash verification for unknown users to equalise timing | unit tests (hash/verify/tamper) |
| Password policy | ≥ 12 chars, mixed character classes, enforced in `create_user` (CLI) | DB test |
| Sessions | HMAC-SHA256 signed, expiring token in `cp_session` (HttpOnly, SameSite=Lax, `Secure` required in production); stateless, role re-read from DB on each request, deactivated users lose access immediately | unit tests (tamper/expiry); cookie behaviour **[not executed]** |
| CSRF | Double-submit token derived inside the signed session; required on every non-safe method for cookie auth | token logic unit-tested; middleware **[not executed]** |
| Authorization | `current_user` / `require_admin` dependencies on every router; read-only users get GET only | **[not executed]** |
| Brute force | per-IP and per-IP+email sliding-window limits; account lockout after 5 failures for 15 min; generic failure message | limiter unit-tested; flow **[not executed]** |
| Input validation | Pydantic bodies; allow-listed sort/filter fields; `page_size ≤ 200`; CSV: 5 MB, 100k rows, required columns, types, ISO dates, uppercase ISO currency; event schema validation | unit + DB tests |
| SQL injection | only bind parameters; identifiers come from allow-lists; LIKE wildcards escaped | `test_sql_injection_attempts_are_inert`, `test_like_wildcards_are_escaped` |
| File upload | extension + content-type allow-list, size capped while reading, parsed as text CSV only (never executed or stored on disk), CSV formula neutralisation on export | unit tests |
| Security headers | `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`, restrictive CSP on the JSON API, `Cache-Control: no-store`; Next.js sets nosniff/frame/referrer/permissions headers (no CSP on the UI yet) | **[not executed]** |
| CORS | explicit allow-list from `CORS_ORIGINS`; `*` rejected in production | config tests |
| Secrets | env vars only; `.env` git-ignored and generated with random values; startup validation refuses unsafe production config; `scripts/scan_secrets.py` in CI; Terraform creates secret *containers* only | config unit tests; scan run (0 findings) |
| Audit log | `audit_events` rows for login success/failure, ingestion, detection, alert/incident changes, integration changes; append-only trigger | DB test (UPDATE/DELETE rejected) |
| Containers | non-root uid 10001, read-only root filesystem, `cap_drop: ALL`, `no-new-privileges`, healthchecks, multi-stage builds | **[not built]** |
| Kubernetes | pod `runAsNonRoot`, seccomp `RuntimeDefault`, no privilege escalation, default-deny NetworkPolicy + explicit allows | **[not rendered or applied]** |
| Supply chain | pinned core versions, `pip-audit`, `npm audit`, Trivy (images + IaC), minimal workflow permissions | **[workflows never run]** |
| Cloud permissions | Lambda role: `s3:GetObject` on `cost-exports/*`, one secret, own logs, own DLQ. Cost Explorer read has no resource scoping (AWS limitation). | Terraform **[never validated]** |

## LLM safety

LLM use is optional and off unless `LLM_PROVIDER` and `LLM_API_KEY` are set on the server. Prompts contain only aggregate measurements; strings are passed through `redact()` (key/token patterns) first. Provider data and event text are treated as untrusted. The response must be strict JSON with exactly the allowed keys, bounded length; anything else is discarded and the rule-based text is kept (and a fallback metric increments). The model cannot call tools or run commands. AI text is stored in a separate column and rendered under a "not a measured fact" label. **The HTTP client for the provider is untested against the real service.**

## Known gaps

* In-process rate limiting is per replica (see DECISIONS).
* No CSP on the Next.js UI; no HSTS (terminate TLS at a proxy that adds it).
* Session tokens cannot be revoked server-side before expiry (60 min default); deactivating the user blocks them.
* No MFA, no password reset flow, no email.
* Audit log is not shipped to an external immutable store.
* A re-upload cannot correct amounts (see DATABASE_DESIGN).
* No penetration test or independent review has been done.

## Reporting

Open a private security advisory on the repository once it is published.
