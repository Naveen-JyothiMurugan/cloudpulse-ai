# GitOps guide (Argo CD)

**Status:** manifests are written and YAML-parsed only. Argo CD and a cluster were not available; nothing here has been reconciled.

## Layout
```
infra/helm/cloudpulse/            chart (templates, defaults)
gitops/environments/dev|prod/     per-environment Helm values (image tags, hostnames, replicas)
gitops/argocd/project.yaml        AppProject: allowed repo, namespaces, namespaced resources only
gitops/argocd/application-dev.yaml   auto-sync from `main`, prune + self-heal
gitops/argocd/application-prod.yaml  pinned to a release tag, NO automated sync
```

## Flow
1. PR → CI (lint, tests, build, scan). Merge to `main` builds and scans images (publishing to GHCR only when repo variable `PUBLISH_IMAGES=true`).
2. A PR changes the image tag in `gitops/environments/dev/values.yaml` (manual or by an image-updater tool you add). After review/merge Argo CD syncs **dev** automatically.
3. Promotion: tag a release `vX.Y.Z`, update `gitops/environments/prod/values.yaml` and `targetRevision` in `application-prod.yaml` through a reviewed PR. In Argo CD review the diff and press **Sync** — production never auto-deploys.
4. Migrations run as an Argo `PreSync` hook Job (`alembic upgrade head`) before the new pods start. Migrations are additive in this project; destructive changes need a two-step release.

## Secrets
Not in Git. Create `cloudpulse-secrets` (keys `DATABASE_URL`, `SECRET_KEY`, optional `INGEST_API_TOKEN`, `LLM_API_KEY`) via External Secrets Operator, Sealed Secrets, or `kubectl create secret` for experiments.

## Install (local experiment)
```bash
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml   # review before applying
# edit OWNER/REPO in gitops/argocd/*.yaml, push to your repo, then:
kubectl apply -f gitops/argocd/project.yaml -f gitops/argocd/application-dev.yaml
```

## Reconciliation, drift and rollback
* `selfHeal: true` (dev) reverts manual `kubectl` edits; `prune: true` removes resources deleted from Git. Prod only reports drift (OutOfSync) until someone syncs.
* **Rollback = revert the Git commit** (or set `targetRevision`/image tag to the previous release) and sync. `argocd app rollback` works for emergencies but leaves Git ahead of the cluster, so follow it with a revert commit.
* Database rollback is separate: restore from backup; there are no automatic down-migrations.

## Safety rules
Namespaced resources only (AppProject); no plaintext secrets; prod pinned to tags; reviewers required on `gitops/` paths (configure CODEOWNERS and branch protection in your repo).
