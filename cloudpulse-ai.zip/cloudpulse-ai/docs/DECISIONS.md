# Architecture decision records

Format: context → decision → consequences. Deviations from the original brief are marked **DEVIATION**.

**D1 – Framework-free analytics/ingestion packages.** Context: the build sandbox had no PyPI access, and business logic should be testable without a web stack. Decision: `services/analytics` and `services/ingestion` depend only on pandas/NumPy/scikit-learn (analytics) or the standard library (ingestion) and are imported by the API. Consequence: 80 unit tests run anywhere; no separate microservice processes. **DEVIATION** from the `services/*` as deployable services layout in the brief.

**D2 – SQLAlchemy Core with `text()` and bind parameters, no ORM.** Context: queries are aggregation-heavy (dashboards, `jsonb_to_recordset` bulk inserts, `ON CONFLICT`). Decision: explicit SQL in `app/services`. Consequence: SQL is reviewable and was executed against real PostgreSQL 16; no autogenerate migrations, hence D3. Alternative: ORM models (more boilerplate for this workload).

**D3 – One `schema.sql`, applied by Alembic migration 0001 and by tests.** Consequence: tested schema = deployed schema. Future changes add new migration files with explicit SQL. Rollback is not automatic.

**D4 – scrypt via `hashlib` instead of Argon2/bcrypt.** Context: "established secure library". scrypt is a recognised memory-hard KDF in the standard library, has no extra native dependency, and let the hashing be unit-tested offline. Trade-off: Argon2id is the common first choice (OWASP lists it first); swapping is a contained change in `core/security.py` (the hash string carries its scheme).

**D5 – Stateless HMAC-signed session cookie + double-submit CSRF.** Simple, no session store. Cost: no server-side revocation before expiry (60 min); role is re-read from the DB each request to limit damage.

**D6 – No Redis. DEVIATION.** The brief allowed Redis only for a clear need. Rate limiting is in-process (sliding window) and there are no background jobs (detection/forecast run on demand). Consequence: limits are per replica → run one API replica, or add Redis for a shared limiter before scaling out.

**D7 – Same-origin proxy (Next.js rewrites) for `/api/v1`.** Avoids CORS and third-party cookie issues; the CORS allow-list still exists for other clients.

**D8 – Robust z-score (median/MAD) as the default detector, IsolationForest optional.** Transparent, explainable thresholds; MAD tolerates earlier spikes in the window. IsolationForest (`random_state=42`) is offered for multivariate experimentation but is less explainable. Both deterministic.

**D9 – Seasonal-naive-mean forecast.** A deliberately simple baseline with a built-in benchmark (last-value naive) and a backtest, so claims are measured. Not a replacement for Prophet/ETS; no accuracy claim beyond the documented backtest on the dataset provided.

**D10 – Rules-first recommendations; optional LLM.** The app must work offline and without cost. The LLM can only add a labelled explanation; output is schema-validated and falls back silently.

**D11 – Dominant-currency analytics, no FX conversion.** Mixing currencies would produce wrong totals; the API warns when other currencies exist.

**D12 – Idempotency by natural-key hash.** Easy dedup, but corrected amounts for an existing key are ignored (no upsert yet).

**D13 – Dashboard window anchors to the latest stored date.** The demo data is from 2025; "last 30 days from today" would be empty.

**D14 – Terraform AWS only; Azure documented. Cost-bearing resources opt-in.** Per the brief; defaults incur near-zero idle cost.

**D15 – Helm chart + Argo CD apps, prod manual sync pinned to tags.** Prevents unreviewed production changes.

**D16 – Offline test shim (`tests/support/pgshim.py`).** When SQLAlchemy/psycopg are not installed, tests execute the *same SQL text* through `psql` against a real PostgreSQL. CI uses the real drivers. The shim is a test aid only; it does not prove driver-specific behaviour (type adaptation, transactions through psycopg).
