import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0f17", panel: "#121826", line: "#1f2937", muted: "#8b97ab",
        accent: { cyan: "#22d3ee", blue: "#60a5fa", violet: "#a78bfa" },
      },
    },
  },
  plugins: [],
} satisfies Config;
