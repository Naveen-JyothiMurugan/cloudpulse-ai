import { expect, test } from "@playwright/test";

// Requires: stack running, demo data loaded (make up && make seed), E2E_EMAIL / E2E_PASSWORD of an admin.
const email = process.env.E2E_EMAIL ?? "";
const password = process.env.E2E_PASSWORD ?? "";

test.skip(!email || !password, "set E2E_EMAIL and E2E_PASSWORD");

test("sign in, view dashboard, open an alert, acknowledge it", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/login/);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("heading", { name: "Overview" })).toBeVisible();
  await expect(page.getByRole("note")).toContainText(/synthetic/i);

  await page.getByRole("link", { name: "Alerts" }).click();
  await page.getByRole("link", { name: /./ }).filter({ hasText: /spend|cost|anomal/i }).first().click();
  const ack = page.getByRole("button", { name: "Acknowledge" });
  if (await ack.isVisible()) {
    await ack.click();
    await expect(page.getByText("acknowledged").first()).toBeVisible();
  }
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page).toHaveURL(/\/login/);
});
