import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ApiError } from "@/lib/api";
import { validateLogin } from "@/components/LoginForm";
import { DateRange, OriginBanner, Pager, StateView } from "@/components/ui";

describe("StateView", () => {
  it("shows loading", () => {
    render(<StateView loading error={null}>child</StateView>);
    expect(screen.getByRole("status")).toHaveTextContent("Loading");
  });
  it("shows an error with retry", () => {
    const retry = vi.fn();
    render(<StateView loading={false} error={new ApiError(500, "internal_error", "Boom", null, "req-9")} onRetry={retry}>child</StateView>);
    expect(screen.getByRole("alert")).toHaveTextContent("Boom");
    expect(screen.getByText(/req-9/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Retry" }));
    expect(retry).toHaveBeenCalled();
  });
  it("offers sign-in again on 401", () => {
    render(<StateView loading={false} error={new ApiError(401, "unauthorized", "x")}>child</StateView>);
    expect(screen.getByRole("link", { name: /sign in again/i })).toHaveAttribute("href", "/login?expired=1");
  });
  it("shows the empty state, and children otherwise", () => {
    const { rerender } = render(<StateView loading={false} error={null} empty emptyText="Nothing here">child</StateView>);
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
    rerender(<StateView loading={false} error={null}>child</StateView>);
    expect(screen.getByText("child")).toBeInTheDocument();
  });
});

describe("OriginBanner", () => {
  it("labels synthetic data as not real bills", () => {
    render(<OriginBanner origin="synthetic" />);
    expect(screen.getByRole("note")).toHaveTextContent(/not real cloud bills/i);
  });
  it("renders nothing without data", () => {
    const { container } = render(<OriginBanner origin="none" />);
    expect(container).toBeEmptyDOMElement();
  });
});

describe("Pager", () => {
  it("disables boundaries and navigates", () => {
    const go = vi.fn();
    render(<Pager page={1} pages={3} total={60} onPage={go} />);
    expect(screen.getByRole("button", { name: "Previous" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "Next" }));
    expect(go).toHaveBeenCalledWith(2);
  });
});

describe("DateRange filter", () => {
  it("reports changes and flags an inverted range", () => {
    const change = vi.fn();
    const { rerender } = render(<DateRange from="" to="" onChange={change} />);
    fireEvent.change(screen.getByLabelText("From"), { target: { value: "2025-02-01" } });
    expect(change).toHaveBeenCalledWith("2025-02-01", "");
    rerender(<DateRange from="2025-03-01" to="2025-02-01" onChange={change} />);
    expect(screen.getByRole("alert")).toHaveTextContent(/on or before/i);
  });
});

describe("login validation", () => {
  it("rejects bad email and empty password", () => {
    expect(validateLogin("nope", "")).toEqual({ email: "Enter a valid email address.", password: "Password is required." });
  });
  it("accepts valid input", () => {
    expect(validateLogin("a@b.co", "x")).toEqual({});
  });
});
