import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { api, ApiError, qs, setCsrf } from "@/lib/api";
import { money, pct } from "@/lib/format";
import { pivot } from "@/components/charts";

const ok = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });

describe("api client", () => {
  beforeEach(() => { setCsrf(null); });
  afterEach(() => vi.restoreAllMocks());

  it("sends the CSRF header on writes but not on reads", async () => {
    const spy = vi.spyOn(globalThis, "fetch").mockImplementation(async () => ok({}));
    setCsrf("tok123");
    await api("/alerts/1/resolve", { method: "POST" });
    await api("/alerts");
    expect((spy.mock.calls[0][1] as RequestInit).headers).toMatchObject({ "X-CSRF-Token": "tok123" });
    expect((spy.mock.calls[1][1] as RequestInit).headers).not.toHaveProperty("X-CSRF-Token");
  });

  it("maps the API error envelope to ApiError", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(ok({ error: { code: "validation_error", message: "bad", details: [1], request_id: "r1" } }, 422));
    await expect(api("/x")).rejects.toMatchObject({ status: 422, code: "validation_error", message: "bad", requestId: "r1" });
  });

  it("reports network failures clearly", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new TypeError("fail"));
    const e = (await api("/x").catch((x) => x)) as ApiError;
    expect(e).toBeInstanceOf(ApiError);
    expect(e.code).toBe("network_error");
  });

  it("handles 204 responses", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(null, { status: 204 }));
    await expect(api("/auth/logout", { method: "POST" })).resolves.toBeUndefined();
  });
});

describe("helpers", () => {
  it("qs skips empty values and encodes", () => {
    expect(qs({ a: "x y", b: "", c: null, d: 2 })).toBe("?a=x+y&d=2");
    expect(qs({})).toBe("");
  });
  it("formats money and percentages", () => {
    expect(money(1234.5, "USD")).toBe("$1,234.50");
    expect(money(null)).toBe("–");
    expect(pct(12.34)).toBe("+12.3%");
    expect(pct(null)).toBe("n/a");
  });
  it("pivots grouped time series", () => {
    const { rows, groups } = pivot([
      { period: "2025-01-02", group: "b", cost: 2 }, { period: "2025-01-01", group: "a", cost: 1 }, { period: "2025-01-01", group: "b", cost: 3 },
    ]);
    expect(groups).toEqual(["a", "b"]);
    expect(rows[0]).toEqual({ period: "2025-01-01", a: 1, b: 3 });
    expect(rows[1].period).toBe("2025-01-02");
  });
});
