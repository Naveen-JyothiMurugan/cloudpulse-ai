import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("next/link", () => ({ default: ({ children, href }: { children: React.ReactNode; href: string }) => <a href={href}>{children}</a> }));
vi.mock("recharts", () => {
  const Stub = ({ children }: { children?: React.ReactNode }) => <div>{children}</div>;
  return { ResponsiveContainer: Stub, AreaChart: Stub, Area: Stub, BarChart: Stub, Bar: Stub, LineChart: Stub, Line: Stub, CartesianGrid: Stub, XAxis: Stub, YAxis: Stub, Tooltip: Stub, Legend: Stub };
});

import OverviewPage from "@/app/(app)/page";

const dashboard = {
  summary: { has_data: true, data_origin: "synthetic", currency: "USD", period: { from: "2025-03-01", to: "2025-03-30", days: 30 }, total_cost: 1000, previous_period_total: 800, change_amount: 200, change_percent: 25, by_service: [{ name: "EC2", cost: 5 }], by_region: [{ name: "us-east-1", cost: 5 }], freshness: { latest_usage_date: "2025-03-30", last_ingestion_status: "succeeded", last_ingestion_finished_at: null } },
  unresolved_alerts: { total: 2, by_severity: { high: 2 } }, anomalies: { total: 4, by_severity: { critical: 2, high: 2 } },
  recent_events: [], ingestion_health: { recent_runs_by_status: { succeeded: 1 }, last_run: null },
};

function mockFetch(urls: string[]) {
  return vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
    const u = String(input); urls.push(u);
    if (u.includes("/dashboard")) return new Response(JSON.stringify(dashboard), { status: 200 });
    return new Response(JSON.stringify({ has_data: true, points: [{ period: "2025-03-01", group: "aws", cost: 3 }] }), { status: 200 });
  });
}

describe("Overview dashboard", () => {
  afterEach(() => vi.restoreAllMocks());

  it("renders metrics from the API and labels synthetic data", async () => {
    mockFetch([]);
    render(<OverviewPage />);
    expect(await screen.findByText("$1,000.00")).toBeInTheDocument();
    expect(screen.getByText("+25.0%")).toBeInTheDocument();
    expect(screen.getByRole("note")).toHaveTextContent(/synthetic/i);
  });

  it("refetches with the selected date range", async () => {
    const urls: string[] = [];
    mockFetch(urls);
    render(<OverviewPage />);
    await screen.findByText("$1,000.00");
    fireEvent.change(screen.getByLabelText("From"), { target: { value: "2025-02-01" } });
    await waitFor(() => expect(urls.some((u) => u.includes("/dashboard?date_from=2025-02-01"))).toBe(true));
  });

  it("shows an error state with retry when the API fails", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ error: { code: "internal_error", message: "Server broke" } }), { status: 500 }));
    render(<OverviewPage />);
    expect(await screen.findByText("Server broke")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Retry" })).toBeInTheDocument();
  });

  it("shows the empty state when no data is loaded", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ ...dashboard, summary: { has_data: false, data_origin: "none", period: null, total_cost: 0 } }), { status: 200 }));
    render(<OverviewPage />);
    expect(await screen.findByText(/No cost data yet/)).toBeInTheDocument();
  });
});
