import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const replace = vi.fn();
vi.mock("next/navigation", () => ({ useRouter: () => ({ replace }), useSearchParams: () => new URLSearchParams("expired=1") }));

import { LoginForm } from "@/components/LoginForm";
import { getCsrf } from "@/lib/api";

describe("LoginForm flow", () => {
  beforeEach(() => { replace.mockReset(); vi.restoreAllMocks(); });

  it("blocks submit and shows field errors without calling the API", async () => {
    const spy = vi.spyOn(globalThis, "fetch");
    render(<LoginForm />);
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByText("Enter a valid email address.")).toBeInTheDocument();
    expect(spy).not.toHaveBeenCalled();
  });

  it("shows the expired-session notice", () => {
    render(<LoginForm />);
    expect(screen.getByRole("status")).toHaveTextContent(/expired/i);
  });

  it("shows the generic server error on 401", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ error: { code: "invalid_credentials", message: "Invalid email or password." } }), { status: 401 }));
    render(<LoginForm />);
    fireEvent.change(screen.getByLabelText("Email"), { target: { value: "a@b.co" } });
    fireEvent.change(screen.getByLabelText("Password"), { target: { value: "wrong" } });
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByText("Invalid email or password.")).toBeInTheDocument();
    expect(replace).not.toHaveBeenCalled();
  });

  it("stores the CSRF token and redirects on success", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ id: 1, email: "a@b.co", role: "admin", csrf_token: "abc" }), { status: 200 }));
    render(<LoginForm />);
    fireEvent.change(screen.getByLabelText("Email"), { target: { value: "a@b.co" } });
    fireEvent.change(screen.getByLabelText("Password"), { target: { value: "right" } });
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    await waitFor(() => expect(replace).toHaveBeenCalledWith("/"));
    expect(getCsrf()).toBe("abc");
  });
});
