"use client";
import { useState } from "react";
import { api, ApiError, type Integration } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import { Badge, Card, PageHeader, StateView } from "@/components/ui";

export default function IntegrationsPage() {
  const { isAdmin } = useAuth();
  const { data, loading, error, reload } = useApi<{ items: Integration[]; default_mode: string }>("/integrations");
  const [msg, setMsg] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [busy, setBusy] = useState<string | null>(null);

  async function run(key: string, fn: () => Promise<string>) {
    setBusy(key);
    try { const text = await fn(); setMsg((m) => ({ ...m, [key]: { ok: true, text } })); reload(); }
    catch (e) { setMsg((m) => ({ ...m, [key]: { ok: false, text: (e as ApiError).message } })); }
    finally { setBusy(null); }
  }

  return (
    <>
      <PageHeader title="Cloud integrations" subtitle="Credentials are configured on the server (IAM roles, managed identities, environment). Nothing secret is entered here." />
      <StateView loading={loading} error={error} onRetry={reload}>
        <div className="grid gap-4 lg:grid-cols-3">
          {data?.items.map((p) => (
            <Card key={p.provider} title={p.label} action={<Badge value={p.status} />}>
              <p className="text-sm">{p.data_origin === "synthetic" ? "Synthetic data only. Not real cloud billing." : "Reads real provider data when enabled."}</p>
              <dl className="mt-3 space-y-1 text-sm">
                <div className="flex justify-between"><dt className="text-muted">Configured</dt><dd>{p.configured ? "yes" : "no"}</dd></div>
                <div className="flex justify-between"><dt className="text-muted">Enabled</dt><dd>{p.enabled ? "yes" : "no"}</dd></div>
                <div className="flex justify-between"><dt className="text-muted">Last test</dt><dd>{dateTime(p.last_tested_at)}</dd></div>
                <div className="flex justify-between"><dt className="text-muted">Last sync</dt><dd>{dateTime(p.last_sync_at)}{p.last_sync_status ? ` (${p.last_sync_status})` : ""}</dd></div>
              </dl>
              {p.missing_config.length > 0 && <div className="mt-3 text-sm"><p className="text-yellow-200">Missing configuration:</p><ul className="list-disc pl-5 font-mono text-xs">{p.missing_config.map((m) => <li key={m}>{m}</li>)}</ul></div>}
              <details className="mt-3 text-sm"><summary className="cursor-pointer text-accent-cyan">Setup instructions</summary><ol className="mt-2 list-decimal pl-5 text-muted">{p.setup_instructions.map((s, i) => <li key={i}>{s}</li>)}</ol></details>
              {isAdmin && (
                <div className="mt-4 flex flex-wrap gap-2">
                  <button className="btn" disabled={busy !== null} onClick={() => run(p.provider + "-test", async () => { const r = await api<{ ok: boolean; message: string }>(`/integrations/${p.provider}/test`, { method: "POST" }); return `${r.ok ? "OK" : "Failed"}: ${r.message}`; })}>Test connection</button>
                  {p.provider !== "demo" && p.enabled && <button className="btn btn-primary" disabled={busy !== null} onClick={() => run(p.provider + "-sync", async () => { const r = await api<{ status: string; rows_inserted: number; rows_duplicate: number; rows_rejected: number }>(`/integrations/${p.provider}/sync`, { method: "POST", body: {} }); return `Sync ${r.status}: ${r.rows_inserted} new, ${r.rows_duplicate} duplicate, ${r.rows_rejected} rejected (last 30 days).`; })}>Sync last 30 days</button>}
                  {p.provider !== "demo" && <button className="btn" disabled={busy !== null || (!p.enabled && !p.configured)} onClick={() => run(p.provider + "-toggle", async () => { await api(`/integrations/${p.provider}`, { method: "PUT", body: { enabled: !p.enabled } }); return p.enabled ? "Disabled." : "Enabled."; })}>{p.enabled ? "Disable" : "Enable"}</button>}
                  {p.provider === "demo" && <button className="btn btn-primary" disabled={busy !== null} onClick={() => run("demo-load", async () => { await api("/integrations/demo/load", { method: "POST" }); return "Synthetic demo data loaded (safe to repeat)."; })}>Load demo data</button>}
                </div>
              )}
              {[p.provider + "-test", p.provider + "-toggle", p.provider + "-sync", p.provider === "demo" ? "demo-load" : ""].map((k) => msg[k] && <p key={k} role={msg[k].ok ? "status" : "alert"} className={`mt-2 text-sm ${msg[k].ok ? "text-emerald-300" : "text-red-300"}`}>{msg[k].text}</p>)}
            </Card>
          ))}
        </div>
      </StateView>
    </>
  );
}
