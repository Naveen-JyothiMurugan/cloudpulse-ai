"use client";
import { useAuth } from "@/lib/auth";
import { Card, PageHeader } from "@/components/ui";

export default function SettingsPage() {
  const { user } = useAuth();
  return (
    <>
      <PageHeader title="Settings" subtitle="Account and documentation" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Account">
          <dl className="space-y-1 text-sm">
            <div className="flex justify-between"><dt className="text-muted">Email</dt><dd>{user?.email}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Role</dt><dd>{user?.role === "admin" ? "Administrator" : "Read-only"}</dd></div>
          </dl>
          <p className="mt-3 text-xs text-muted">Accounts and password changes are managed by an administrator with <code>python -m app.cli</code>. Sessions expire automatically.</p>
        </Card>
        <Card title="Documentation">
          <ul className="list-disc pl-5 text-sm">
            <li><a className="text-accent-cyan" href="/api/v1/docs" target="_blank" rel="noreferrer">Interactive API documentation (OpenAPI)</a></li>
            <li>Repository docs: <code>docs/PROJECT_DOCUMENTATION.md</code>, <code>docs/API_REFERENCE.md</code>, <code>docs/TROUBLESHOOTING.md</code></li>
          </ul>
        </Card>
      </div>
    </>
  );
}
