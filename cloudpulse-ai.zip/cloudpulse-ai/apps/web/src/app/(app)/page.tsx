"use client";
import Link from "next/link";
import { useState } from "react";
import { qs, type Dashboard, type Timeseries } from "@/lib/api";
import { dateTime, money, pct } from "@/lib/format";
import { useApi } from "@/lib/useApi";
import { BreakdownChart, CostTrendChart } from "@/components/charts";
import { Badge, Card, DateRange, OriginBanner, PageHeader, StateView, Stat } from "@/components/ui";

export default function OverviewPage() {
  const [range, setRange] = useState({ from: "", to: "" });
  const q = qs({ date_from: range.from, date_to: range.to });
  const dash = useApi<Dashboard>(`/dashboard${q}`);
  const series = useApi<Timeseries>(`/costs/timeseries${qs({ date_from: range.from, date_to: range.to, granularity: "day", group_by: "provider" })}`);
  const s = dash.data?.summary;
  const cur = s?.currency ?? "USD";
  const up = (s?.change_percent ?? 0) > 0;

  return (
    <>
      <PageHeader title="Overview" subtitle={s?.period ? `${s.period.from} → ${s.period.to} (${s.period.days} days)` : "Cost and operations at a glance"}>
        <DateRange from={range.from} to={range.to} onChange={(from, to) => setRange({ from, to })} />
      </PageHeader>
      <OriginBanner origin={s?.data_origin} />
      <StateView loading={dash.loading} error={dash.error} onRetry={dash.reload} empty={!!s && !s.has_data}
        emptyText="No cost data yet. Load the synthetic demo data from Integrations or upload a CSV on Cost analytics.">
        {dash.data && s && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <Stat label="Total cost" value={money(s.total_cost, cur)} sub={`Previous period: ${money(s.previous_period_total, cur)}`} />
              <Stat label="Change vs previous" value={pct(s.change_percent)} tone={s.change_percent == null ? undefined : up ? "text-orange-300" : "text-emerald-300"} sub={money(s.change_amount, cur)} />
              <Stat label="Anomalies" value={dash.data.anomalies.total} sub={Object.entries(dash.data.anomalies.by_severity).map(([k, v]) => `${v} ${k}`).join(", ") || "none detected"} />
              <Stat label="Unresolved alerts" value={dash.data.unresolved_alerts.total} sub={Object.entries(dash.data.unresolved_alerts.by_severity).map(([k, v]) => `${v} ${k}`).join(", ") || "none"} />
            </div>
            <Card title="Daily cost by provider">
              <StateView loading={series.loading} error={series.error} onRetry={series.reload} empty={!series.data?.points.length}>
                <CostTrendChart points={series.data?.points ?? []} label="Daily cost by provider" />
              </StateView>
            </Card>
            <div className="grid gap-4 lg:grid-cols-2">
              <Card title="Cost by service"><StateView loading={false} error={null} empty={!s.by_service?.length}><BreakdownChart data={s.by_service ?? []} label="Cost by service" /></StateView></Card>
              <Card title="Cost by region"><StateView loading={false} error={null} empty={!s.by_region?.length}><BreakdownChart data={s.by_region ?? []} label="Cost by region" /></StateView></Card>
            </div>
            <div className="grid gap-4 lg:grid-cols-3">
              <Card title="Data freshness & ingestion health">
                <dl className="space-y-1 text-sm">
                  <div className="flex justify-between"><dt className="text-muted">Latest usage date</dt><dd>{s.freshness?.latest_usage_date ?? "–"}</dd></div>
                  <div className="flex justify-between"><dt className="text-muted">Last ingestion</dt><dd>{dash.data.ingestion_health.last_run ? <Badge value={dash.data.ingestion_health.last_run.status} /> : "none"}</dd></div>
                  <div className="flex justify-between"><dt className="text-muted">Finished</dt><dd>{dateTime(dash.data.ingestion_health.last_run?.finished_at)}</dd></div>
                  <div className="flex justify-between"><dt className="text-muted">Recent runs</dt><dd>{Object.entries(dash.data.ingestion_health.recent_runs_by_status).map(([k, v]) => `${v} ${k}`).join(", ") || "–"}</dd></div>
                </dl>
              </Card>
              <Card title="Recent events" className="lg:col-span-2" action={<Link className="text-xs text-accent-cyan" href="/events">View all</Link>}>
                <StateView loading={false} error={null} empty={!dash.data.recent_events.length} emptyText="No events ingested.">
                  <ul className="divide-y divide-line text-sm">
                    {dash.data.recent_events.map((e) => (
                      <li key={e.id} className="flex items-start gap-2 py-2">
                        <Badge value={e.severity} />
                        <span className="min-w-0 flex-1"><span className="text-muted">{e.provider}/{e.service}</span> {e.message}<br /><span className="text-xs text-muted">{dateTime(e.event_timestamp)}{e.is_synthetic ? " · synthetic" : ""}</span></span>
                      </li>
                    ))}
                  </ul>
                </StateView>
              </Card>
            </div>
          </div>
        )}
      </StateView>
    </>
  );
}
