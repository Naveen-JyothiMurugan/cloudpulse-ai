"use client";
import { type Recommendation } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useList } from "@/lib/useList";
import { Badge, Card, PageHeader, Pager, StateView } from "@/components/ui";

export default function RecommendationsPage() {
  const list = useList<Recommendation>("/recommendations");
  const f = list.filters;
  return (
    <>
      <PageHeader title="Recommendations" subtitle="Findings derived from detected anomalies. Measured facts and AI text are shown separately." />
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search</label><input id="q" className="input" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
        <div className="flex flex-col gap-1"><label htmlFor="rev" className="text-xs text-muted">Human review</label>
          <select id="rev" className="input" value={f.requires_review ?? ""} onChange={(e) => list.setFilter("requires_review", e.target.value)}><option value="">Any</option><option value="true">Required</option><option value="false">Not required</option></select></div>
      </div>
      <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0} emptyText="No recommendations yet. Run anomaly detection first.">
        <div className="space-y-3">
          {list.data?.items.map((r) => (
            <Card key={r.id}>
              <div className="flex flex-wrap items-center gap-2"><Badge value={r.severity} /><h2 className="font-medium">{r.summary}</h2></div>
              <p className="mt-1 text-xs text-muted">{r.provider} · {r.service_name} · {dateTime(r.generated_at)} · source: {r.source}</p>
              <div className="mt-3 grid gap-3 md:grid-cols-2">
                <div><h3 className="text-xs font-semibold uppercase text-muted">Measured evidence</h3>
                  <ul className="mt-1 text-sm">{r.evidence_json.map((e, i) => <li key={i}><span className="text-muted">{e.fact}:</span> {String(e.value)}</li>)}</ul></div>
                <div><h3 className="text-xs font-semibold uppercase text-muted">Suggested next steps</h3>
                  <ol className="mt-1 list-decimal pl-5 text-sm">{r.next_steps_json.map((s, i) => <li key={i}>{s}</li>)}</ol></div>
              </div>
              <p className="mt-3 text-sm"><strong>Potential impact:</strong> {r.potential_impact}</p>
              <p className="mt-1 text-sm text-muted"><strong>Confidence:</strong> {r.confidence_note}</p>
              {r.ai_explanation_json && (
                <div className="mt-3 rounded border border-violet-500/40 bg-violet-500/10 p-3 text-sm"><h3 className="text-xs font-semibold uppercase text-violet-300">AI-generated explanation (not a measured fact)</h3>
                  <pre className="whitespace-pre-wrap text-xs">{JSON.stringify(r.ai_explanation_json, null, 2)}</pre></div>
              )}
              {r.requires_human_review && <p className="mt-2 text-sm text-yellow-200">Human review required before acting.</p>}
            </Card>
          ))}
        </div>
        {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
      </StateView>
    </>
  );
}
