"use client";
import { useRef, useState } from "react";
import { api, ApiError, exportUrl, qs, type CostRow, type Forecast, type IngestionRun, type Page, type Summary, type Timeseries } from "@/lib/api";
import { dateTime, money } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import { useList } from "@/lib/useList";
import { BreakdownChart, CostTrendChart, ForecastChart } from "@/components/charts";
import { Badge, Card, DateRange, ExportLink, OriginBanner, PageHeader, Pager, StateView } from "@/components/ui";

function Upload({ onDone }: { onDone: () => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const file = ref.current?.files?.[0];
    if (!file) return setMsg({ ok: false, text: "Choose a .csv file first." });
    if (!file.name.toLowerCase().endsWith(".csv")) return setMsg({ ok: false, text: "Only .csv files are accepted." });
    if (file.size > 5 * 1024 * 1024) return setMsg({ ok: false, text: "File exceeds the 5 MB limit." });
    setBusy(true); setMsg(null);
    const form = new FormData(); form.append("file", file);
    try {
      const r = await api<{ rows_total: number; rows_inserted: number; rows_duplicate: number; rows_rejected: number; status: string }>("/ingestion/costs", { method: "POST", form });
      setMsg({ ok: true, text: `Run ${r.status}: ${r.rows_inserted} inserted, ${r.rows_duplicate} duplicates skipped, ${r.rows_rejected} rejected of ${r.rows_total}.` });
      onDone();
    } catch (err) {
      const e2 = err as ApiError;
      const d = Array.isArray(e2.details) ? ` (${(e2.details as unknown[]).length} detail entries)` : "";
      setMsg({ ok: false, text: e2.message + d });
    } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="flex flex-wrap items-end gap-2">
      <div className="flex flex-col gap-1"><label htmlFor="csv" className="text-xs text-muted">Upload cost CSV</label><input id="csv" ref={ref} type="file" accept=".csv,text/csv" className="input" /></div>
      <button className="btn btn-primary" disabled={busy}>{busy ? "Uploading…" : "Upload"}</button>
      {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-300" : "text-red-300"}`}>{msg.text}</p>}
    </form>
  );
}

function ForecastPanel({ isAdmin }: { isAdmin: boolean }) {
  const f = useApi<Forecast>("/forecasts/latest");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  async function run() {
    setBusy(true); setErr(null);
    try { await api("/forecasts/run", { method: "POST", body: { horizon_days: 14 } }); f.reload(); }
    catch (e) { setErr((e as ApiError).message); } finally { setBusy(false); }
  }
  const d = f.data;
  return (
    <Card title="Cost forecast (baseline)" action={<div className="flex gap-2"><ExportLink href={exportUrl("forecasts.csv")}>Export CSV</ExportLink>{isAdmin && <button className="btn" onClick={run} disabled={busy}>{busy ? "Running…" : "Generate forecast"}</button>}</div>}>
      {err && <p role="alert" className="mb-2 text-sm text-red-300">{err}</p>}
      <StateView loading={f.loading} error={f.error} onRetry={f.reload} empty={d?.status === "none"} emptyText={isAdmin ? "No forecast yet. Click “Generate forecast”." : "No forecast has been generated yet."}>
        {d && d.status !== "none" && (
          <div className="space-y-3">
            {d.warnings?.map((w) => <p key={w} role="note" className="rounded border border-yellow-500/40 bg-yellow-500/10 px-3 py-2 text-sm text-yellow-100">{w}</p>)}
            {d.status === "ok" && <ForecastChart f={d} />}
            {d.evaluation ? (
              <p className="text-sm text-muted">Backtest ({d.evaluation.origins_used} origins, {d.evaluation.horizon_days}-day horizon): MAE {d.evaluation.mae.toFixed(2)} vs naive {d.evaluation.naive_last_value_mae.toFixed(2)} ({d.evaluation.relative_to_mean_level_pct ?? "n/a"}% of mean daily level). {d.evaluation.note}</p>
            ) : d.status === "ok" && <p className="text-sm text-muted">Not enough history for a backtest; accuracy is unknown.</p>}
            {d.is_synthetic && <p className="text-xs text-violet-300">Forecast computed from synthetic data.</p>}
          </div>
        )}
      </StateView>
    </Card>
  );
}

export default function CostsPage() {
  const { isAdmin } = useAuth();
  const list = useList<CostRow>("/costs", { sort_by: "date", sort_dir: "desc" });
  const f = list.filters;
  const [gran, setGran] = useState<"day" | "month">("day");
  const [group, setGroup] = useState("service");
  const range = { date_from: f.date_from, date_to: f.date_to, provider: f.provider };
  const summary = useApi<Summary>(`/costs/summary${qs(range)}`);
  const series = useApi<Timeseries>(`/costs/timeseries${qs({ ...range, granularity: gran, group_by: group })}`);
  const runs = useApi<Page<IngestionRun>>("/ingestion/runs?page_size=5");
  const s = summary.data;
  const reloadAll = () => { list.reload(); summary.reload(); series.reload(); runs.reload(); };

  return (
    <>
      <PageHeader title="Cost analytics" subtitle="Trends, breakdowns and raw cost records">
        <ExportLink href={exportUrl("costs.csv", f)}>Export records</ExportLink>
        <ExportLink href={exportUrl("cost-summary.csv", range)}>Export summary</ExportLink>
        <ExportLink href={exportUrl("report.md", range)}>Report</ExportLink>
      </PageHeader>
      <OriginBanner origin={s?.data_origin} />
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <DateRange from={f.date_from ?? ""} to={f.date_to ?? ""} onChange={(a, b) => list.setMany({ date_from: a, date_to: b })} />
        <div className="flex flex-col gap-1"><label htmlFor="provider" className="text-xs text-muted">Provider</label>
          <select id="provider" className="input" value={f.provider ?? ""} onChange={(e) => list.setFilter("provider", e.target.value)}><option value="">All</option><option value="aws">AWS</option><option value="azure">Azure</option></select></div>
        <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search</label><input id="q" className="input" placeholder="service, account, region" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
      </div>
      <div className="space-y-4">
        <Card title="Cost trend" action={
          <div className="flex gap-2">
            <label className="sr-only" htmlFor="gran">Granularity</label>
            <select id="gran" className="input" value={gran} onChange={(e) => setGran(e.target.value as "day" | "month")}><option value="day">Daily</option><option value="month">Monthly</option></select>
            <label className="sr-only" htmlFor="grp">Group by</label>
            <select id="grp" className="input" value={group} onChange={(e) => setGroup(e.target.value)}><option value="none">Total</option><option value="provider">Provider</option><option value="service">Service</option><option value="region">Region</option></select>
          </div>}>
          <StateView loading={series.loading} error={series.error} onRetry={series.reload} empty={!series.data?.points.length}>
            <CostTrendChart points={series.data?.points ?? []} label={`${gran} cost grouped by ${group}`} />
          </StateView>
        </Card>
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="By provider"><StateView loading={summary.loading} error={summary.error} empty={!s?.by_provider?.length}><BreakdownChart data={s?.by_provider ?? []} label="Cost by provider" /></StateView></Card>
          <Card title="By service"><StateView loading={summary.loading} error={summary.error} empty={!s?.by_service?.length}><BreakdownChart data={s?.by_service ?? []} label="Cost by service" /></StateView></Card>
          <Card title="By region"><StateView loading={summary.loading} error={summary.error} empty={!s?.by_region?.length}><BreakdownChart data={s?.by_region ?? []} label="Cost by region" /></StateView></Card>
        </div>
        <ForecastPanel isAdmin={isAdmin} />
        <Card title="Cost records">
          <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0}>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <caption className="sr-only">Cost records</caption>
                <thead className="text-xs uppercase text-muted"><tr><th scope="col" className="py-2">Date</th><th scope="col">Provider</th><th scope="col">Service</th><th scope="col">Region</th><th scope="col">Account</th><th scope="col" className="text-right">Cost</th><th scope="col">Source</th></tr></thead>
                <tbody className="divide-y divide-line">
                  {list.data?.items.map((r) => (
                    <tr key={r.id}><td className="py-2">{r.usage_date}</td><td>{r.provider}</td><td>{r.service_name}</td><td>{r.region}</td><td>{r.account_identifier}</td><td className="text-right">{money(r.cost_amount, r.currency)}</td><td>{r.is_synthetic ? <Badge value="open" label="synthetic" /> : r.source_type}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
            {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
          </StateView>
        </Card>
        <Card title="Ingestion">
          {isAdmin ? <Upload onDone={reloadAll} /> : <p className="text-sm text-muted">Uploads require an administrator.</p>}
          <StateView loading={runs.loading} error={runs.error} onRetry={runs.reload} empty={!runs.data?.items.length} emptyText="No ingestion runs yet.">
            <ul className="mt-3 divide-y divide-line text-sm">
              {runs.data?.items.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-2 py-2"><Badge value={r.status} /><span>{r.filename ?? r.source_type}</span><span className="text-muted">{r.rows_inserted} new · {r.rows_duplicate} dup · {r.rows_rejected} rejected</span><span className="ml-auto text-xs text-muted">{dateTime(r.started_at)}</span></li>
              ))}
            </ul>
          </StateView>
        </Card>
      </div>
    </>
  );
}
