"use client";
import { exportUrl, type EventRow } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useList } from "@/lib/useList";
import { Badge, Card, DateRange, ExportLink, PageHeader, Pager, StateView } from "@/components/ui";

export default function EventsPage() {
  const list = useList<EventRow>("/events", { sort_by: "timestamp", sort_dir: "desc" });
  const f = list.filters;
  return (
    <>
      <PageHeader title="Event explorer" subtitle="Searchable operational event history"><ExportLink href={exportUrl("events.csv", f)}>Export CSV</ExportLink></PageHeader>
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <DateRange from={f.date_from ?? ""} to={f.date_to ?? ""} onChange={(a, b) => list.setMany({ date_from: a, date_to: b })} />
        <div className="flex flex-col gap-1"><label htmlFor="sev" className="text-xs text-muted">Severity</label>
          <select id="sev" className="input" value={f.severity ?? ""} onChange={(e) => list.setFilter("severity", e.target.value)}><option value="">All</option>{["critical", "error", "warning", "info"].map((s) => <option key={s}>{s}</option>)}</select></div>
        <div className="flex flex-col gap-1"><label htmlFor="prov" className="text-xs text-muted">Provider</label>
          <select id="prov" className="input" value={f.provider ?? ""} onChange={(e) => list.setFilter("provider", e.target.value)}><option value="">All</option><option value="aws">AWS</option><option value="azure">Azure</option></select></div>
        <div className="flex flex-col gap-1"><label htmlFor="env" className="text-xs text-muted">Environment</label><input id="env" className="input" value={f.environment ?? ""} onChange={(e) => list.setFilter("environment", e.target.value)} /></div>
        <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search messages</label><input id="q" className="input" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
      </div>
      <Card>
        <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0} emptyText="No events match these filters.">
          <ul className="divide-y divide-line text-sm">
            {list.data?.items.map((e) => (
              <li key={e.id} className="py-2">
                <div className="flex flex-wrap items-center gap-2"><Badge value={e.severity} /><span className="text-muted">{e.provider}/{e.service}</span><span className="text-xs text-muted">{e.environment} · {e.event_type}</span><span className="ml-auto text-xs text-muted">{dateTime(e.event_timestamp)}</span></div>
                {/* message is untrusted: rendered as text only */}
                <p className="mt-1">{e.message}</p>
                {e.correlation_id && <p className="text-xs text-muted">correlation: {e.correlation_id}{e.is_synthetic ? " · synthetic" : ""}</p>}
              </li>
            ))}
          </ul>
          {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
        </StateView>
      </Card>
    </>
  );
}
