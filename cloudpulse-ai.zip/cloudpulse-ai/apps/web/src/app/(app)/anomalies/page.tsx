"use client";
import { useState } from "react";
import Link from "next/link";
import { api, ApiError, exportUrl, type Anomaly } from "@/lib/api";
import { money, pct } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useList } from "@/lib/useList";
import { Badge, Card, DateRange, ExportLink, PageHeader, Pager, StateView } from "@/components/ui";

export default function AnomaliesPage() {
  const { isAdmin } = useAuth();
  const list = useList<Anomaly>("/anomalies", { sort_by: "date", sort_dir: "desc" });
  const f = list.filters;
  const [open, setOpen] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  async function run() {
    setBusy(true); setMsg(null);
    try {
      const r = await api<{ detected: number; new: number; suppressed_duplicates: number; status: string }>("/anomalies/run", { method: "POST", body: {} });
      setMsg({ ok: true, text: `Detection ${r.status}: ${r.detected} found, ${r.new} new, ${r.suppressed_duplicates} duplicates suppressed.` });
      list.reload();
    } catch (e) { setMsg({ ok: false, text: (e as ApiError).message }); } finally { setBusy(false); }
  }
  return (
    <>
      <PageHeader title="Anomaly investigations" subtitle="Deterministic statistical detection over stored cost records">
        <ExportLink href={exportUrl("anomalies.csv", f)}>Export CSV</ExportLink>
        {isAdmin && <button className="btn btn-primary" onClick={run} disabled={busy}>{busy ? "Running…" : "Run detection"}</button>}
      </PageHeader>
      {msg && <p role={msg.ok ? "status" : "alert"} className={`mb-3 text-sm ${msg.ok ? "text-emerald-300" : "text-red-300"}`}>{msg.text}</p>}
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <DateRange from={f.date_from ?? ""} to={f.date_to ?? ""} onChange={(a, b) => list.setMany({ date_from: a, date_to: b })} />
        <div className="flex flex-col gap-1"><label htmlFor="sev" className="text-xs text-muted">Severity</label>
          <select id="sev" className="input" value={f.severity ?? ""} onChange={(e) => list.setFilter("severity", e.target.value)}><option value="">All</option>{["critical", "high", "medium", "low"].map((s) => <option key={s}>{s}</option>)}</select></div>
        <div className="flex flex-col gap-1"><label htmlFor="prov" className="text-xs text-muted">Provider</label>
          <select id="prov" className="input" value={f.provider ?? ""} onChange={(e) => list.setFilter("provider", e.target.value)}><option value="">All</option><option value="aws">AWS</option><option value="azure">Azure</option></select></div>
        <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search</label><input id="q" className="input" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
      </div>
      <Card>
        <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0} emptyText="No anomalies. Load data and run detection.">
          <ul className="divide-y divide-line">
            {list.data?.items.map((a) => (
              <li key={a.id} className="py-3">
                <button className="flex w-full flex-wrap items-center gap-3 text-left" aria-expanded={open === a.id} onClick={() => setOpen(open === a.id ? null : a.id)}>
                  <Badge value={a.severity} />
                  <span className="font-medium">{a.service_name}</span>
                  <span className="text-sm text-muted">{a.provider} · {a.usage_date}</span>
                  <span className="ml-auto text-sm">{money(a.observed_value)} vs {money(a.expected_value)} ({pct(a.pct_change)}){a.is_synthetic ? " · synthetic" : ""}</span>
                </button>
                {open === a.id && (
                  <div className="mt-2 space-y-2 rounded bg-bg p-3 text-sm">
                    <p>{a.explanation}</p>
                    <p className="text-muted">Method: {a.method} · score {a.score.toFixed(2)} · {a.direction}</p>
                    <pre className="overflow-x-auto text-xs text-muted">{JSON.stringify(a.signals_json, null, 2)}</pre>
                    <p><Link className="text-accent-cyan" href="/recommendations">See recommendations</Link></p>
                  </div>
                )}
              </li>
            ))}
          </ul>
          {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
        </StateView>
      </Card>
    </>
  );
}
