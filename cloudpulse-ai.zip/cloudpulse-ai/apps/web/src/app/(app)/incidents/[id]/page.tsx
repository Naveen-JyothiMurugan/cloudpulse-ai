"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { api, ApiError, type IncidentDetail } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import { Badge, Card, PageHeader, StateView } from "@/components/ui";

const NEXT: Record<string, string[]> = { open: ["investigating", "resolved", "closed"], investigating: ["open", "resolved", "closed"], resolved: ["open", "closed"], closed: [] };

export default function IncidentDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isAdmin } = useAuth();
  const { data: i, loading, error, reload } = useApi<IncidentDetail>(`/incidents/${id}`);
  const [note, setNote] = useState("");
  const [err, setErr] = useState<string | null>(null);

  async function call(fn: () => Promise<unknown>) {
    setErr(null);
    try { await fn(); reload(); return true; } catch (e) { setErr((e as ApiError).message); return false; }
  }
  return (
    <StateView loading={loading} error={error} onRetry={reload}>
      {i && (
        <>
          <PageHeader title={i.title} subtitle={`Opened ${dateTime(i.opened_at)}${i.closed_at ? ` · closed ${dateTime(i.closed_at)}` : ""}`}>
            <Badge value={i.severity} /><Badge value={i.status} />
            {isAdmin && NEXT[i.status]?.map((s) => <button key={s} className="btn" onClick={() => call(() => api(`/incidents/${id}`, { method: "PATCH", body: { status: s } }))}>Mark {s}</button>)}
          </PageHeader>
          {err && <p role="alert" className="mb-3 text-sm text-red-300">{err}</p>}
          {i.summary && <p className="mb-4 text-sm">{i.summary}</p>}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Linked alerts"><StateView loading={false} error={null} empty={i.alerts.length === 0} emptyText="No alerts linked.">
              <ul className="text-sm">{i.alerts.map((a) => <li key={a.id} className="flex gap-2 py-1"><Badge value={a.severity} /><Badge value={a.status} /><Link className="text-accent-cyan" href={`/alerts/${a.id}`}>{a.title}</Link></li>)}</ul></StateView></Card>
            <Card title="Linked events"><StateView loading={false} error={null} empty={i.events.length === 0} emptyText="No events linked.">
              <ul className="text-sm">{i.events.map((e) => <li key={e.id} className="py-1"><Badge value={e.severity} /> {e.message}</li>)}</ul></StateView></Card>
            <Card title="Notes" className="lg:col-span-2">
              <StateView loading={false} error={null} empty={i.notes.length === 0} emptyText="No notes yet.">
                <ul className="space-y-2 text-sm">{i.notes.map((n) => <li key={n.id} className="rounded bg-bg p-2"><p className="whitespace-pre-wrap">{n.body}</p><p className="text-xs text-muted">{n.author ?? "unknown"} · {dateTime(n.created_at)}</p></li>)}</ul>
              </StateView>
              {isAdmin && (
                <form className="mt-3 flex flex-col gap-2" onSubmit={async (e) => { e.preventDefault(); if (!note.trim()) return setErr("Write a note before saving."); if (await call(() => api(`/incidents/${id}/notes`, { method: "POST", body: { body: note.trim() } }))) setNote(""); }}>
                  <label htmlFor="note" className="text-xs text-muted">Add a note</label>
                  <textarea id="note" className="input min-h-20" maxLength={4000} value={note} onChange={(e) => setNote(e.target.value)} />
                  <button className="btn self-start">Save note</button>
                </form>
              )}
            </Card>
          </div>
        </>
      )}
    </StateView>
  );
}
