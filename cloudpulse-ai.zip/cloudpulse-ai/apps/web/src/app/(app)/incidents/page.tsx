"use client";
import Link from "next/link";
import { useState } from "react";
import { api, ApiError, type AlertRow, type IncidentRow, type Page } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import { useList } from "@/lib/useList";
import { Badge, Card, Field, PageHeader, Pager, StateView } from "@/components/ui";

function NewIncident({ onCreated }: { onCreated: () => void }) {
  const alerts = useApi<Page<AlertRow>>("/alerts?status=unresolved&page_size=50");
  const [title, setTitle] = useState("");
  const [severity, setSeverity] = useState("medium");
  const [summary, setSummary] = useState("");
  const [picked, setPicked] = useState<number[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [fieldErr, setFieldErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    if (title.trim().length < 3) return setFieldErr("Title must be at least 3 characters.");
    setFieldErr(null);
    try {
      await api("/incidents", { method: "POST", body: { title: title.trim(), severity, summary: summary.trim() || null, alert_ids: picked } });
      setTitle(""); setSummary(""); setPicked([]); onCreated();
    } catch (e2) { setErr((e2 as ApiError).message); }
  }
  return (
    <Card title="Open an incident">
      <form onSubmit={submit} className="grid gap-3 md:grid-cols-2" noValidate>
        <Field label="Title" htmlFor="inc-title" error={fieldErr}><input id="inc-title" className="input" value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        <Field label="Severity" htmlFor="inc-sev"><select id="inc-sev" className="input" value={severity} onChange={(e) => setSeverity(e.target.value)}>{["low", "medium", "high", "critical"].map((s) => <option key={s}>{s}</option>)}</select></Field>
        <div className="md:col-span-2"><Field label="Summary (optional)" htmlFor="inc-sum"><textarea id="inc-sum" className="input" maxLength={4000} value={summary} onChange={(e) => setSummary(e.target.value)} /></Field></div>
        <fieldset className="md:col-span-2"><legend className="text-xs text-muted">Link unresolved alerts</legend>
          <div className="max-h-40 overflow-y-auto text-sm">
            {alerts.data?.items.map((a) => (
              <label key={a.id} className="flex items-center gap-2 py-1"><input type="checkbox" checked={picked.includes(a.id)} onChange={(e) => setPicked(e.target.checked ? [...picked, a.id] : picked.filter((x) => x !== a.id))} />{a.title}</label>
            ))}
            {alerts.data?.items.length === 0 && <p className="text-muted">No unresolved alerts.</p>}
          </div></fieldset>
        {err && <p role="alert" className="text-sm text-red-300 md:col-span-2">{err}</p>}
        <button className="btn btn-primary md:col-span-2 md:w-40">Create incident</button>
      </form>
    </Card>
  );
}

export default function IncidentsPage() {
  const { isAdmin } = useAuth();
  const list = useList<IncidentRow>("/incidents", { sort_by: "opened", sort_dir: "desc" });
  const f = list.filters;
  return (
    <>
      <PageHeader title="Incidents" subtitle="Investigation history" />
      <div className="space-y-4">
        {isAdmin && <NewIncident onCreated={list.reload} />}
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex flex-col gap-1"><label htmlFor="st" className="text-xs text-muted">Status</label>
            <select id="st" className="input" value={f.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)}><option value="">All</option>{["open", "investigating", "resolved", "closed"].map((s) => <option key={s}>{s}</option>)}</select></div>
          <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search</label><input id="q" className="input" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
        </div>
        <Card>
          <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0} emptyText="No incidents yet.">
            <ul className="divide-y divide-line text-sm">
              {list.data?.items.map((i) => (
                <li key={i.id} className="flex flex-wrap items-center gap-2 py-3"><Badge value={i.severity} /><Badge value={i.status} /><Link className="font-medium text-accent-cyan hover:underline" href={`/incidents/${i.id}`}>{i.title}</Link><span className="ml-auto text-xs text-muted">opened {dateTime(i.opened_at)}</span></li>
              ))}
            </ul>
            {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
          </StateView>
        </Card>
      </div>
    </>
  );
}
