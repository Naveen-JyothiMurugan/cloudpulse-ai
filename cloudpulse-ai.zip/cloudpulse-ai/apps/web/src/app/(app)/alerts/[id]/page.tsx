"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { api, ApiError, type AlertDetail } from "@/lib/api";
import { dateTime, money, pct } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import { Badge, Card, PageHeader, StateView } from "@/components/ui";

export default function AlertDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isAdmin } = useAuth();
  const { data: a, loading, error, reload } = useApi<AlertDetail>(`/alerts/${id}`);
  const [note, setNote] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function act(path: string, body?: unknown) {
    setBusy(true); setErr(null);
    try { await api(`/alerts/${id}/${path}`, { method: "POST", body }); reload(); return true; }
    catch (e) { setErr((e as ApiError).message); return false; } finally { setBusy(false); }
  }
  async function addNote(e: React.FormEvent) {
    e.preventDefault();
    if (!note.trim()) return setErr("Write a note before saving.");
    if (await act("notes", { body: note.trim() })) setNote("");
  }

  return (
    <StateView loading={loading} error={error} onRetry={reload}>
      {a && (
        <>
          <PageHeader title={a.title} subtitle={`${a.provider} · ${a.service_name} · created ${dateTime(a.created_at)}`}>
            <Badge value={a.severity} /><Badge value={a.status} />
            {isAdmin && a.status === "open" && <button className="btn" disabled={busy} onClick={() => act("acknowledge")}>Acknowledge</button>}
            {isAdmin && a.status !== "resolved" && <button className="btn btn-primary" disabled={busy} onClick={() => act("resolve")}>Resolve</button>}
          </PageHeader>
          {err && <p role="alert" className="mb-3 text-sm text-red-300">{err}</p>}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Associated anomaly">
              {a.anomaly ? (
                <div className="space-y-1 text-sm">
                  <p>{a.anomaly.explanation}</p>
                  <p className="text-muted">Observed {money(a.anomaly.observed_value)} vs expected {money(a.anomaly.expected_value)} ({pct(a.anomaly.pct_change)}) on {a.anomaly.usage_date}</p>
                  <p className="text-muted">Method {a.anomaly.method}{a.anomaly.is_synthetic ? " · synthetic data" : ""}</p>
                </div>
              ) : <p className="text-sm text-muted">No linked anomaly.</p>}
              {a.recommendation && <p className="mt-3 text-sm"><strong>Recommendation:</strong> {a.recommendation.summary} <Link className="text-accent-cyan" href="/recommendations">details</Link></p>}
            </Card>
            <Card title="Incidents">
              {a.incidents.length ? <ul className="text-sm">{a.incidents.map((i) => <li key={i.id}><Link className="text-accent-cyan" href={`/incidents/${i.id}`}>{i.title}</Link> <Badge value={i.status} /></li>)}</ul> : <p className="text-sm text-muted">Not part of any incident.</p>}
              <p className="mt-2 text-xs text-muted">Acknowledged: {dateTime(a.acknowledged_at)} · Resolved: {dateTime(a.resolved_at)}</p>
            </Card>
            <Card title="Related events (same provider/service, ±1 day)" className="lg:col-span-2">
              <StateView loading={false} error={null} empty={a.events.length === 0} emptyText="No related events.">
                <ul className="divide-y divide-line text-sm">{a.events.map((e) => <li key={e.id} className="flex gap-2 py-2"><Badge value={e.severity} /><span className="flex-1">{e.message}</span><span className="text-xs text-muted">{dateTime(e.event_timestamp)}</span></li>)}</ul>
              </StateView>
            </Card>
            <Card title="Investigation notes" className="lg:col-span-2">
              <StateView loading={false} error={null} empty={a.notes.length === 0} emptyText="No notes yet.">
                <ul className="space-y-2 text-sm">{a.notes.map((n) => <li key={n.id} className="rounded bg-bg p-2"><p className="whitespace-pre-wrap">{n.body}</p><p className="text-xs text-muted">{n.author ?? "unknown"} · {dateTime(n.created_at)}</p></li>)}</ul>
              </StateView>
              {isAdmin && (
                <form onSubmit={addNote} className="mt-3 flex flex-col gap-2">
                  <label htmlFor="note" className="text-xs text-muted">Add a note</label>
                  <textarea id="note" className="input min-h-20" maxLength={4000} value={note} onChange={(e) => setNote(e.target.value)} />
                  <button className="btn self-start" disabled={busy}>Save note</button>
                </form>
              )}
            </Card>
          </div>
        </>
      )}
    </StateView>
  );
}
