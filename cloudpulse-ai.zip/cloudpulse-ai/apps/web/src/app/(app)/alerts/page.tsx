"use client";
import Link from "next/link";
import { exportUrl, type AlertRow } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useList } from "@/lib/useList";
import { Badge, Card, DateRange, ExportLink, PageHeader, Pager, StateView } from "@/components/ui";

export default function AlertsPage() {
  const list = useList<AlertRow>("/alerts", { status: "unresolved", sort_by: "created", sort_dir: "desc" });
  const f = list.filters;
  return (
    <>
      <PageHeader title="Alerts" subtitle="Created from anomalies; repeated detection never duplicates an alert"><ExportLink href={exportUrl("alerts.csv", f)}>Export CSV</ExportLink></PageHeader>
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <DateRange from={f.date_from ?? ""} to={f.date_to ?? ""} onChange={(a, b) => list.setMany({ date_from: a, date_to: b })} />
        <div className="flex flex-col gap-1"><label htmlFor="status" className="text-xs text-muted">Status</label>
          <select id="status" className="input" value={f.status ?? ""} onChange={(e) => list.setFilter("status", e.target.value)}><option value="">All</option><option value="unresolved">Unresolved</option><option value="open">Open</option><option value="acknowledged">Acknowledged</option><option value="resolved">Resolved</option></select></div>
        <div className="flex flex-col gap-1"><label htmlFor="sev" className="text-xs text-muted">Severity</label>
          <select id="sev" className="input" value={f.severity ?? ""} onChange={(e) => list.setFilter("severity", e.target.value)}><option value="">All</option>{["critical", "high", "medium", "low"].map((s) => <option key={s}>{s}</option>)}</select></div>
        <div className="flex flex-col gap-1"><label htmlFor="prov" className="text-xs text-muted">Provider</label>
          <select id="prov" className="input" value={f.provider ?? ""} onChange={(e) => list.setFilter("provider", e.target.value)}><option value="">All</option><option value="aws">AWS</option><option value="azure">Azure</option></select></div>
        <div className="flex flex-col gap-1"><label htmlFor="q" className="text-xs text-muted">Search</label><input id="q" className="input" value={f.q ?? ""} onChange={(e) => list.setFilter("q", e.target.value)} /></div>
      </div>
      <Card>
        <StateView loading={list.loading} error={list.error} onRetry={list.reload} empty={list.data?.items.length === 0} emptyText="No alerts match these filters.">
          <ul className="divide-y divide-line text-sm">
            {list.data?.items.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-2 py-3">
                <Badge value={a.severity} /><Badge value={a.status} />
                <Link className="font-medium text-accent-cyan hover:underline" href={`/alerts/${a.id}`}>{a.title}</Link>
                <span className="text-muted">{a.provider} · {a.service_name}</span>
                <span className="ml-auto text-xs text-muted">{dateTime(a.created_at)}</span>
              </li>
            ))}
          </ul>
          {list.data && <Pager page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={list.setPage} />}
        </StateView>
      </Card>
    </>
  );
}
