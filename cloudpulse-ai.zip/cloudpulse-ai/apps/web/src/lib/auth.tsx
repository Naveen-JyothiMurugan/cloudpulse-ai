"use client";
import { useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, ApiError, setCsrf, type User } from "./api";

type Ctx = { user: User | null; isAdmin: boolean; logout: () => Promise<void> };
const AuthCtx = createContext<Ctx>({ user: null, isAdmin: false, logout: async () => {} });
export const useAuth = () => useContext(AuthCtx);

/** Loads /auth/me once. Expired or missing sessions (401) send the user to /login. */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [failure, setFailure] = useState<string | null>(null);

  useEffect(() => {
    api<User>("/auth/me")
      .then((u) => { setCsrf(u.csrf_token ?? u.csrf ?? null); setUser(u); })
      .catch((e: ApiError) => {
        if (e.status === 401) router.replace("/login?expired=1");
        else setFailure(e.message);
      });
  }, [router]);

  const logout = useCallback(async () => {
    try { await api("/auth/logout", { method: "POST" }); } finally { setCsrf(null); router.replace("/login"); }
  }, [router]);

  if (failure) return <p role="alert" className="p-8 text-red-300">Cannot load your session: {failure}</p>;
  if (!user) return <p className="p-8 text-muted" role="status">Loading…</p>;
  return <AuthCtx.Provider value={{ user, isAdmin: user.role === "admin", logout }}>{children}</AuthCtx.Provider>;
}
