"use client";
import { useCallback, useState } from "react";
import { qs, type Page } from "./api";
import { useApi } from "./useApi";

/** Filter + pagination state for a paginated list endpoint. Changing any filter resets to page 1. */
export function useList<T>(endpoint: string, initial: Record<string, string> = {}, pageSize = 25) {
  const [filters, setFilters] = useState<Record<string, string>>(initial);
  const [page, setPage] = useState(1);
  const path = `${endpoint}${qs({ ...filters, page, page_size: pageSize })}`;
  const state = useApi<Page<T>>(path);
  const setFilter = useCallback((k: string, v: string) => { setFilters((f) => ({ ...f, [k]: v })); setPage(1); }, []);
  const setMany = useCallback((v: Record<string, string>) => { setFilters((f) => ({ ...f, ...v })); setPage(1); }, []);
  return { ...state, filters, setFilter, setMany, page, setPage, path };
}
