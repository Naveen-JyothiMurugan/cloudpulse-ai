/** Thin typed client for the CloudPulse API. Cookies are HttpOnly; only the CSRF token lives in memory. */

export class ApiError extends Error {
  status: number;
  code: string;
  details: unknown;
  requestId?: string;
  constructor(status: number, code: string, message: string, details?: unknown, requestId?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
    this.requestId = requestId;
  }
}

let csrfToken: string | null = null;
export const setCsrf = (t: string | null) => { csrfToken = t; };
export const getCsrf = () => csrfToken;

export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === null || v === undefined || v === "") continue;
    sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}

type Opts = { method?: string; body?: unknown; form?: FormData };

export async function api<T = unknown>(path: string, opts: Opts = {}): Promise<T> {
  const method = (opts.method ?? "GET").toUpperCase();
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  if (method !== "GET" && method !== "HEAD" && csrfToken) headers["X-CSRF-Token"] = csrfToken;

  let res: Response;
  try {
    res = await fetch(`/api/v1${path}`, { method, headers, body, credentials: "same-origin", cache: "no-store" });
  } catch {
    throw new ApiError(0, "network_error", "Cannot reach the API. Check that the backend is running.");
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* non-JSON body */ }
  if (!res.ok) {
    const e = json?.error;
    throw new ApiError(res.status, e?.code ?? "http_error", e?.message ?? `Request failed (${res.status})`, e?.details, e?.request_id);
  }
  return json as T;
}

export const exportUrl = (name: string, params: Record<string, string | number | boolean | null | undefined> = {}) =>
  `/api/v1/exports/${name}${qs(params)}`;

// ---- types (mirror the API responses) ----
export type Page<T> = { items: T[]; total: number; page: number; page_size: number; pages: number };
export type Origin = "synthetic" | "provider" | "uploaded" | "mixed" | "none";
export type Breakdown = { name: string; cost: number };
export type Summary = {
  has_data: boolean; data_origin: Origin; message?: string; currency?: string;
  period: { from: string; to: string; days: number } | null;
  previous_period?: { from: string; to: string };
  total_cost: number; previous_period_total?: number; change_amount?: number; change_percent?: number | null;
  by_provider?: Breakdown[]; by_service?: Breakdown[]; by_region?: Breakdown[]; source_types?: string[];
  freshness?: { latest_usage_date: string | null; last_ingestion_status: string | null; last_ingestion_finished_at: string | null };
};
export type EventRow = {
  id: number; external_event_id?: string; provider: string; service: string; environment?: string; severity: string;
  event_type: string; event_timestamp: string; message: string; correlation_id?: string | null;
  metadata_json?: Record<string, unknown>; is_synthetic: boolean;
};
export type Dashboard = {
  summary: Summary;
  unresolved_alerts: { total: number; by_severity: Record<string, number> };
  anomalies: { total: number; by_severity: Record<string, number> };
  recent_events: EventRow[];
  ingestion_health: {
    recent_runs_by_status: Record<string, number>;
    last_run: { id: number; status: string; rows_inserted: number; rows_rejected: number; started_at: string; finished_at: string | null } | null;
  };
};
export type TimePoint = { period: string; group: string; cost: number };
export type Timeseries = { has_data: boolean; currency?: string; points: TimePoint[]; granularity?: string; group_by?: string };
export type CostRow = {
  id: number; usage_date: string; provider: string; account_identifier: string; service_name: string; region: string;
  usage_quantity: number | null; usage_unit: string | null; cost_amount: number; currency: string; source_type: string; is_synthetic: boolean;
};
export type Anomaly = {
  id: number; provider: string; service_name: string; region: string | null; usage_date: string; observed_value: number;
  expected_value: number; deviation: number; pct_change: number | null; score: number; severity: string; method: string;
  direction: string; signals_json: Record<string, unknown>; explanation: string; is_synthetic: boolean; detected_at: string;
};
export type Recommendation = {
  id: number; anomaly_id: number; provider: string; service_name: string; summary: string;
  evidence_json: { fact: string; value: unknown }[]; potential_impact: string; confidence_note: string;
  next_steps_json: string[]; requires_human_review: boolean; source: string;
  ai_explanation_json: Record<string, unknown> | null; generated_at: string; severity: string; usage_date: string;
};
export type AlertRow = {
  id: number; anomaly_id: number | null; title: string; severity: string; status: string; provider: string;
  service_name: string; created_at: string; updated_at: string; acknowledged_at: string | null; resolved_at: string | null;
};
export type Note = { id: number; body: string; created_at: string; author: string | null };
export type AlertDetail = AlertRow & {
  anomaly: Anomaly | null; recommendation?: Recommendation | null; events: EventRow[]; notes: Note[];
  incidents: { id: number; title: string; status: string }[];
};
export type IncidentRow = { id: number; title: string; status: string; severity: string; owner_id: number | null; opened_at: string; closed_at: string | null };
export type IncidentDetail = IncidentRow & {
  summary: string | null; alerts: { id: number; title: string; severity: string; status: string }[]; events: EventRow[]; notes: Note[];
};
export type Forecast = {
  status: "ok" | "insufficient_data" | "none"; message?: string; warnings?: string[];
  history?: { date: string; value: number }[];
  forecast?: { date: string; value: number; lower: number | null; upper: number | null }[];
  evaluation?: { metric: string; mae: number; naive_last_value_mae: number; relative_to_mean_level_pct: number | null; beats_naive_benchmark: boolean; origins_used: number; horizon_days: number; note: string } | null;
  data_points?: number; forecast_total?: number; is_synthetic?: boolean; created_at?: string;
};
export type Integration = {
  provider: string; label: string; configured: boolean; missing_config: string[]; data_origin: string;
  setup_instructions: string[]; capabilities: string[]; enabled: boolean; status: string;
  last_tested_at: string | null; last_sync_at: string | null; last_sync_status: string | null;
};
export type IngestionRun = {
  id: number; source_type: string; filename: string | null; status: string; rows_total: number; rows_inserted: number;
  rows_duplicate: number; rows_rejected: number; error_summary: string | null; started_at: string; finished_at: string | null;
};
export type User = { id: number; email: string; role: "admin" | "readonly"; csrf_token?: string; csrf?: string };
