"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "./api";

export type ApiState<T> = { data: T | null; error: ApiError | null; loading: boolean; reload: () => void };

/** GET helper with loading/error state. Pass null to skip. Stale responses are ignored. */
export function useApi<T>(path: string | null): ApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState<boolean>(path !== null);
  const [tick, setTick] = useState(0);
  const seq = useRef(0);

  useEffect(() => {
    if (path === null) { setLoading(false); return; }
    const mine = ++seq.current;
    setLoading(true);
    setError(null);
    api<T>(path)
      .then((d) => { if (mine === seq.current) { setData(d); setLoading(false); } })
      .catch((e) => {
        if (mine !== seq.current) return;
        setError(e instanceof ApiError ? e : new ApiError(0, "unknown", String(e)));
        setLoading(false);
      });
  }, [path, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { data, error, loading, reload };
}
