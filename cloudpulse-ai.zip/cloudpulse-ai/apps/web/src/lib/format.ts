export function money(v: number | null | undefined, currency = "USD"): string {
  if (v === null || v === undefined || Number.isNaN(v)) return "–";
  try {
    return new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(v);
  } catch {
    return `${v.toFixed(2)} ${currency}`;
  }
}

export function pct(v: number | null | undefined): string {
  if (v === null || v === undefined) return "n/a";
  return `${v > 0 ? "+" : ""}${v.toFixed(1)}%`;
}

export function dateTime(iso: string | null | undefined): string {
  if (!iso) return "–";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toISOString().replace("T", " ").slice(0, 16) + " UTC";
}

export const originLabel: Record<string, string> = {
  synthetic: "Synthetic demo data", provider: "Cloud provider data", uploaded: "Uploaded CSV data",
  mixed: "Mixed data sources", none: "No data loaded",
};

export const severityTone: Record<string, string> = {
  critical: "bg-red-500/15 text-red-300 border-red-500/40",
  high: "bg-orange-500/15 text-orange-300 border-orange-500/40",
  error: "bg-orange-500/15 text-orange-300 border-orange-500/40",
  medium: "bg-yellow-500/15 text-yellow-200 border-yellow-500/40",
  warning: "bg-yellow-500/15 text-yellow-200 border-yellow-500/40",
  low: "bg-sky-500/15 text-sky-300 border-sky-500/40",
  info: "bg-sky-500/15 text-sky-300 border-sky-500/40",
  open: "bg-violet-500/15 text-violet-300 border-violet-500/40",
  acknowledged: "bg-blue-500/15 text-blue-300 border-blue-500/40",
  investigating: "bg-blue-500/15 text-blue-300 border-blue-500/40",
  resolved: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
  closed: "bg-slate-500/15 text-slate-300 border-slate-500/40",
  succeeded: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
  partial: "bg-yellow-500/15 text-yellow-200 border-yellow-500/40",
  failed: "bg-red-500/15 text-red-300 border-red-500/40",
  connected: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
  configured: "bg-blue-500/15 text-blue-300 border-blue-500/40",
  not_configured: "bg-slate-500/15 text-slate-300 border-slate-500/40",
  error_: "bg-red-500/15 text-red-300 border-red-500/40",
};
