"use client";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Breakdown, Forecast, TimePoint } from "@/lib/api";

const COLORS = ["#22d3ee", "#60a5fa", "#a78bfa", "#34d399", "#f59e0b", "#f472b6"];
const axis = { stroke: "#8b97ab", fontSize: 11 };
const tip = { contentStyle: { background: "#121826", border: "1px solid #1f2937", color: "#e2e8f0" } };

/** Pivot [{period, group, cost}] into rows keyed by group so multi-series charts work. */
export function pivot(points: TimePoint[]): { rows: Record<string, number | string>[]; groups: string[] } {
  const groups = Array.from(new Set(points.map((p) => p.group))).sort();
  const map = new Map<string, Record<string, number | string>>();
  for (const p of points) {
    const row = map.get(p.period) ?? { period: p.period };
    row[p.group] = p.cost;
    map.set(p.period, row);
  }
  return { rows: Array.from(map.values()).sort((a, b) => String(a.period).localeCompare(String(b.period))), groups };
}

export function CostTrendChart({ points, label = "Cost over time" }: { points: TimePoint[]; label?: string }) {
  const { rows, groups } = pivot(points);
  return (
    <div role="img" aria-label={label} className="h-72 w-full">
      <ResponsiveContainer>
        <AreaChart data={rows}>
          <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
          <XAxis dataKey="period" {...axis} /><YAxis {...axis} />
          <Tooltip {...tip} />
          {groups.length > 1 && <Legend />}
          {groups.map((g, i) => (
            <Area key={g} type="monotone" dataKey={g} stackId={groups.length > 1 ? "1" : undefined} stroke={COLORS[i % COLORS.length]} fill={COLORS[i % COLORS.length]} fillOpacity={0.25} />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function BreakdownChart({ data, label }: { data: Breakdown[]; label: string }) {
  return (
    <div role="img" aria-label={label} className="h-64 w-full">
      <ResponsiveContainer>
        <BarChart data={data} layout="vertical" margin={{ left: 24 }}>
          <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
          <XAxis type="number" {...axis} /><YAxis type="category" dataKey="name" width={130} {...axis} />
          <Tooltip {...tip} />
          <Bar dataKey="cost" fill="#60a5fa" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/** History and forecast are separate series so the projection is never confused with measured spend. */
export function ForecastChart({ f }: { f: Forecast }) {
  const rows: Record<string, number | string | null>[] = [
    ...(f.history ?? []).map((h) => ({ date: h.date, actual: h.value })),
    ...(f.forecast ?? []).map((p) => ({ date: p.date, forecast: p.value, lower: p.lower, upper: p.upper })),
  ];
  return (
    <div role="img" aria-label="Historical cost and forecast" className="h-72 w-full">
      <ResponsiveContainer>
        <LineChart data={rows}>
          <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
          <XAxis dataKey="date" {...axis} /><YAxis {...axis} />
          <Tooltip {...tip} /><Legend />
          <Line type="monotone" dataKey="actual" name="Measured" stroke="#22d3ee" dot={false} connectNulls={false} />
          <Line type="monotone" dataKey="forecast" name="Forecast" stroke="#a78bfa" strokeDasharray="6 3" dot={false} />
          <Line type="monotone" dataKey="upper" name="Upper band" stroke="#a78bfa" strokeOpacity={0.4} dot={false} />
          <Line type="monotone" dataKey="lower" name="Lower band" stroke="#a78bfa" strokeOpacity={0.4} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
