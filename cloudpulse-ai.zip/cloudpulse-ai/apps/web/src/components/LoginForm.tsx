"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { api, ApiError, setCsrf, type User } from "@/lib/api";
import { Field } from "./ui";

export function validateLogin(email: string, password: string): { email?: string; password?: string } {
  const errors: { email?: string; password?: string } = {};
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) errors.email = "Enter a valid email address.";
  if (password.length === 0) errors.password = "Password is required.";
  return errors;
}

export function LoginForm() {
  const router = useRouter();
  const expired = useSearchParams()?.get("expired") === "1";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);
    const v = validateLogin(email, password);
    setErrors(v);
    if (Object.keys(v).length) return;
    setBusy(true);
    try {
      const u = await api<User>("/auth/login", { method: "POST", body: { email: email.trim(), password } });
      setCsrf(u.csrf_token ?? null);
      router.replace("/");
    } catch (err) {
      setServerError(err instanceof ApiError ? err.message : "Sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} noValidate className="w-full max-w-sm space-y-4 rounded-lg border border-line bg-panel p-6">
      <h1 className="text-xl font-semibold">Sign in to CloudPulse AI</h1>
      {expired && <p role="status" className="text-sm text-yellow-200">Your session expired. Please sign in again.</p>}
      <Field label="Email" htmlFor="email" error={errors.email}>
        <input id="email" type="email" autoComplete="username" className="input" value={email} onChange={(e) => setEmail(e.target.value)} aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-error" : undefined} />
      </Field>
      <Field label="Password" htmlFor="password" error={errors.password}>
        <input id="password" type="password" autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} aria-invalid={!!errors.password} aria-describedby={errors.password ? "password-error" : undefined} />
      </Field>
      {serverError && <p role="alert" className="text-sm text-red-300">{serverError}</p>}
      <button type="submit" className="btn btn-primary w-full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
      <p className="text-xs text-muted">Accounts are created by an administrator (see README, “Create the first admin”).</p>
    </form>
  );
}
