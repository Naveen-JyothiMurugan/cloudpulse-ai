"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/lib/auth";

export const NAV = [
  { href: "/", label: "Overview" }, { href: "/costs", label: "Cost analytics" }, { href: "/anomalies", label: "Anomalies" },
  { href: "/recommendations", label: "Recommendations" }, { href: "/events", label: "Events" }, { href: "/alerts", label: "Alerts" },
  { href: "/incidents", label: "Incidents" }, { href: "/integrations", label: "Integrations" }, { href: "/settings", label: "Settings" },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const active = (h: string) => (h === "/" ? path === "/" : path.startsWith(h));
  return (
    <div className="min-h-screen md:flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-panel focus:p-2">Skip to content</a>
      <header className="flex items-center justify-between border-b border-line bg-panel px-4 py-3 md:hidden">
        <span className="font-semibold text-accent-cyan">CloudPulse AI</span>
        <button className="btn" aria-expanded={open} aria-controls="sidebar" onClick={() => setOpen(!open)}>Menu</button>
      </header>
      <aside id="sidebar" className={`${open ? "block" : "hidden"} border-r border-line bg-panel md:block md:w-56 md:shrink-0`}>
        <div className="hidden px-4 py-4 text-lg font-semibold md:block"><span className="bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">CloudPulse AI</span></div>
        <nav aria-label="Main" className="flex flex-col gap-1 p-2">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} aria-current={active(n.href) ? "page" : undefined}
              className={`rounded px-3 py-2 text-sm ${active(n.href) ? "bg-cyan-500/15 text-cyan-200" : "text-slate-300 hover:bg-white/5"}`}>{n.label}</Link>
          ))}
        </nav>
        <div className="border-t border-line p-3 text-xs text-muted">
          <p className="truncate">{user?.email}</p>
          <p>Role: {user?.role === "admin" ? "Administrator" : "Read-only"}</p>
          <button className="btn mt-2 w-full" onClick={logout}>Sign out</button>
        </div>
      </aside>
      <main id="main" className="min-w-0 flex-1 p-4 md:p-6">{children}</main>
    </div>
  );
}
