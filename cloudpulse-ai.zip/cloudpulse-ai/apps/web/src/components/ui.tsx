"use client";
import Link from "next/link";
import { ApiError } from "@/lib/api";
import { originLabel, severityTone } from "@/lib/format";

export function Card({ title, action, children, className = "" }: { title?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-line bg-panel p-4 ${className}`}>
      {(title || action) && (
        <header className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="text-sm font-semibold uppercase tracking-wide text-muted">{title}</h2>}
          {action}
        </header>
      )}
      {children}
    </section>
  );
}

export function Badge({ value, label }: { value: string; label?: string }) {
  const tone = severityTone[value] ?? "bg-slate-500/15 text-slate-300 border-slate-500/40";
  return <span className={`inline-block rounded border px-2 py-0.5 text-xs font-medium ${tone}`}>{label ?? value.replace("_", " ")}</span>;
}

/** Wraps any async block so every chart/table has loading, error and empty states. */
export function StateView({ loading, error, empty, emptyText = "No data for this selection.", onRetry, children }: {
  loading: boolean; error: ApiError | null; empty?: boolean; emptyText?: string; onRetry?: () => void; children: React.ReactNode;
}) {
  if (loading) return <div role="status" aria-live="polite" className="animate-pulse py-10 text-center text-sm text-muted">Loading…</div>;
  if (error) {
    return (
      <div role="alert" className="rounded border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">
        <p>{error.status === 401 ? "Your session has expired." : error.message}</p>
        {error.requestId && <p className="mt-1 text-xs text-red-300/70">Request ID: {error.requestId}</p>}
        <div className="mt-2 flex gap-2">
          {error.status === 401 ? <Link className="btn" href="/login?expired=1">Sign in again</Link> : onRetry && <button className="btn" onClick={onRetry}>Retry</button>}
        </div>
      </div>
    );
  }
  if (empty) return <p className="py-10 text-center text-sm text-muted">{emptyText}</p>;
  return <>{children}</>;
}

/** Always tells the viewer where the numbers came from. */
export function OriginBanner({ origin }: { origin: string | undefined }) {
  if (!origin || origin === "none") return null;
  const synthetic = origin === "synthetic" || origin === "mixed";
  return (
    <div role="note" className={`mb-4 rounded border px-3 py-2 text-sm ${synthetic ? "border-violet-500/40 bg-violet-500/10 text-violet-200" : "border-cyan-500/40 bg-cyan-500/10 text-cyan-200"}`}>
      <strong>{originLabel[origin] ?? origin}.</strong>{" "}
      {synthetic ? "Generated for demonstration; these are not real cloud bills." : origin === "provider" ? "Retrieved from the connected cloud provider." : "Loaded from a file you uploaded."}
    </div>
  );
}

export function Pager({ page, pages, total, onPage }: { page: number; pages: number; total: number; onPage: (p: number) => void }) {
  return (
    <nav aria-label="Pagination" className="mt-3 flex items-center justify-between text-sm text-muted">
      <span>{total.toLocaleString()} result{total === 1 ? "" : "s"}</span>
      <span className="flex items-center gap-2">
        <button className="btn" disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</button>
        <span aria-live="polite">Page {page} of {Math.max(pages, 1)}</span>
        <button className="btn" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</button>
      </span>
    </nav>
  );
}

export function Stat({ label, value, sub, tone }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: string }) {
  return (
    <div className="rounded-lg border border-line bg-panel p-4">
      <p className="text-xs uppercase tracking-wide text-muted">{label}</p>
      <p className={`mt-1 text-2xl font-semibold ${tone ?? "text-slate-100"}`}>{value}</p>
      {sub && <p className="mt-1 text-xs text-muted">{sub}</p>}
    </div>
  );
}

export function Field({ label, htmlFor, error, children }: { label: string; htmlFor: string; error?: string | null; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={htmlFor} className="text-xs font-medium text-muted">{label}</label>
      {children}
      {error && <p id={`${htmlFor}-error`} role="alert" className="text-xs text-red-300">{error}</p>}
    </div>
  );
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold text-slate-100">{title}</h1>
        {subtitle && <p className="text-sm text-muted">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export function DateRange({ from, to, onChange }: { from: string; to: string; onChange: (from: string, to: string) => void }) {
  const invalid = from !== "" && to !== "" && from > to;
  return (
    <div className="flex flex-wrap items-end gap-2">
      <Field label="From" htmlFor="date-from"><input id="date-from" type="date" className="input" value={from} onChange={(e) => onChange(e.target.value, to)} /></Field>
      <Field label="To" htmlFor="date-to" error={invalid ? "Start date must be on or before the end date." : null}>
        <input id="date-to" type="date" className="input" value={to} aria-invalid={invalid} onChange={(e) => onChange(from, e.target.value)} />
      </Field>
    </div>
  );
}

export function ExportLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <a className="btn" href={href} download>{children}</a>;
}
