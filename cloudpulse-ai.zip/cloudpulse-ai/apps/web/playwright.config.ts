import { defineConfig } from "@playwright/test";

// Runs against an already started stack (make up && make seed). Needs E2E_EMAIL / E2E_PASSWORD.
export default defineConfig({
  testDir: "./e2e",
  use: { baseURL: process.env.E2E_BASE_URL || "http://localhost:3000" },
  reporter: [["list"]],
});
