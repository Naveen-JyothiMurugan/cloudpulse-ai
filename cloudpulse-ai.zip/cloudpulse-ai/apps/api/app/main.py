"""CloudPulse AI API application factory."""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from .core import metrics
from .core.errors import install_error_handlers
from .core.logging import configure_logging, request_id_var
from .db import get_settings
from .routers import alerts, analytics, auth, data, exports, system

API_PREFIX = "/api/v1"
log = logging.getLogger("cloudpulse.http")

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-site",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",  # JSON API: nothing is renderable
    "Cache-Control": "no-store",
}


def create_app() -> FastAPI:
    s = get_settings()
    configure_logging(s.log_level)
    app = FastAPI(
        title="CloudPulse AI API",
        version="1.0.0",
        description=(
            "Cloud cost and operations intelligence. All cost data is labelled by origin "
            "(synthetic, uploaded or provider-sourced). Errors use {error:{code,message,details,request_id}}."
        ),
        docs_url=f"{API_PREFIX}/docs",
        openapi_url=f"{API_PREFIX}/openapi.json",
        redoc_url=None,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=s.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH"],
        allow_headers=["Content-Type", "X-CSRF-Token", "X-Request-ID"],
        max_age=600,
    )

    @app.middleware("http")
    async def observe(request: Request, call_next):
        rid = request.headers.get("x-request-id", "")[:64]
        rid = rid if rid.replace("-", "").isalnum() and rid else uuid.uuid4().hex
        token = request_id_var.set(rid)
        start = time.perf_counter()
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
            docs = request.url.path.startswith(f"{API_PREFIX}/docs")
            for k, v in SECURITY_HEADERS.items():
                if docs and k == "Content-Security-Policy":
                    continue  # Swagger UI loads its own assets
                response.headers.setdefault(k, v)
            response.headers["X-Request-ID"] = rid  # set while the request-id context is still active
            return response
        finally:
            elapsed = time.perf_counter() - start
            route = getattr(request.scope.get("route"), "path", "unmatched")  # template, not raw path: low cardinality
            metrics.HTTP_REQUESTS.labels(request.method, route, str(status)).inc()
            metrics.HTTP_LATENCY.labels(request.method, route).observe(elapsed)
            if route not in (f"{API_PREFIX}/health", f"{API_PREFIX}/metrics"):
                log.info(
                    "request",
                    extra={
                        "method": request.method,
                        "route": route,
                        "status": status,
                        "duration_ms": round(elapsed * 1000, 1),
                    },
                )
            request_id_var.reset(token)

    install_error_handlers(app)
    for r in (system.router, auth.router, data.router, analytics.router, alerts.router, exports.router):
        app.include_router(r, prefix=API_PREFIX)
    return app


app = create_app()
