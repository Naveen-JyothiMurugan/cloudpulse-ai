"""Database engine and per-request transactional connection (SQLAlchemy Core, parameterised SQL)."""

from __future__ import annotations

from collections.abc import Iterator
from functools import lru_cache

from sqlalchemy import create_engine
from sqlalchemy.engine import Connection, Engine

from .core.config import Settings, load_settings


@lru_cache
def get_settings() -> Settings:
    return load_settings()


@lru_cache
def get_engine() -> Engine:
    s = get_settings()
    return create_engine(
        s.database_url,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=5,
        pool_timeout=10,  # fail fast instead of hanging when the pool is exhausted
        connect_args={"connect_timeout": 5, "options": "-c statement_timeout=20000 -c timezone=UTC"},
    )


def get_conn() -> Iterator[Connection]:
    """One connection per request. Write endpoints call ``conn.commit()`` explicitly before returning,
    so data is durable before the client sees the response. Anything uncommitted (including on any
    exception) is rolled back when the connection is closed."""
    conn = get_engine().connect()
    try:
        yield conn
    finally:
        conn.rollback()
        conn.close()
