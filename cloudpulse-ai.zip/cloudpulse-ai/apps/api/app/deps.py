"""Authentication / authorization dependencies and audit helper."""

from __future__ import annotations

import hmac
import json
from typing import Any

from fastapi import Depends, Request
from sqlalchemy import text
from sqlalchemy.engine import Connection

from .core.errors import ApiError
from .core.logging import request_id_var
from .core.security import SessionError, csrf_ok, verify_session_token
from .db import get_conn, get_settings

COOKIE_NAME = "cp_session"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def client_ip(request: Request) -> str:
    # Behind a trusted ingress, configure uvicorn --proxy-headers so request.client is the real address.
    return request.client.host if request.client else "unknown"


def _load_user(conn: Connection, user_id: int) -> dict[str, Any] | None:
    row = (
        conn.execute(
            text(
                "SELECT u.id, u.email, u.is_active, r.name AS role FROM users u JOIN roles r ON r.id = u.role_id "
                "WHERE u.id = :id"
            ),
            {"id": user_id},
        )
        .mappings()
        .first()
    )
    return dict(row) if row else None


def current_user(request: Request, conn: Connection = Depends(get_conn)) -> dict[str, Any]:
    settings = get_settings()
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise ApiError(401, "not_authenticated", "Authentication required.")
    try:
        sess = verify_session_token(settings.secret_key, token)
    except SessionError as e:
        code = "session_expired" if e.reason == "expired" else "not_authenticated"
        raise ApiError(
            401,
            code,
            "Your session has expired. Please sign in again." if e.reason == "expired" else "Authentication required.",
        )
    if request.method not in SAFE_METHODS and not csrf_ok(sess, request.headers.get("x-csrf-token")):
        raise ApiError(403, "csrf_failed", "Missing or invalid CSRF token.")
    user = _load_user(conn, sess.user_id)
    if not user or not user["is_active"]:
        raise ApiError(401, "not_authenticated", "Authentication required.")
    user["csrf"] = sess.csrf  # the role comes from the DB, never from the token
    return user


def require_admin(user: dict = Depends(current_user)) -> dict[str, Any]:
    if user["role"] != "admin":
        raise ApiError(403, "forbidden", "Administrator role required.")
    return user


def ingest_principal(request: Request, conn: Connection = Depends(get_conn)) -> dict[str, Any]:
    """Admin session OR the server-side ingest bearer token (used by Lambda / Azure Functions)."""
    settings = get_settings()
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        supplied = auth[7:].strip()
        if settings.ingest_api_token and hmac.compare_digest(supplied, settings.ingest_api_token):
            return {"id": None, "email": "service:ingest", "role": "ingest"}
        raise ApiError(401, "not_authenticated", "Invalid credentials.")
    return require_admin(current_user(request, conn))


def audit(
    conn: Connection,
    request: Request,
    user: dict | None,
    action: str,
    entity_type: str | None = None,
    entity_id: Any = None,
    details: dict | None = None,
) -> None:
    conn.execute(
        text(
            "INSERT INTO audit_events (actor_id, actor_email, action, entity_type, entity_id, ip_address, "
            "request_id, details_json) VALUES (:a, :e, :act, :et, :eid, :ip, :rid, CAST(:d AS jsonb))"
        ),
        {
            "a": user.get("id") if user else None,
            "e": user.get("email") if user else None,
            "act": action,
            "et": entity_type,
            "eid": None if entity_id is None else str(entity_id),
            "ip": client_ip(request),
            "rid": request_id_var.get(),
            "d": json.dumps(details or {}, default=str),
        },
    )
