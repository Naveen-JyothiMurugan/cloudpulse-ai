"""Validated list/filter/sort/pagination dependencies shared by list endpoints and CSV exports.

Each ``*_listing`` dependency returns a ``Listing`` holding allow-listed SQL fragments plus bind
parameters. Values never get concatenated into SQL text.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Any

from fastapi import Query
from sqlalchemy import text
from sqlalchemy.engine import Connection

from .core import queryutil as qu

PROVIDERS = {"aws", "azure", "other"}
ALERT_SEVERITIES = {"low", "medium", "high", "critical"}
EVENT_SEVERITIES = {"info", "warning", "error", "critical"}
SEV_RANK = "CASE severity WHEN 'low' THEN 1 WHEN 'medium' THEN 2 WHEN 'high' THEN 3 ELSE 4 END"
EVT_RANK = "CASE severity WHEN 'info' THEN 1 WHEN 'warning' THEN 2 WHEN 'error' THEN 3 ELSE 4 END"


@dataclass
class Listing:
    where: qu.Where
    order: str
    page: int
    page_size: int


def _common(
    page: int,
    page_size: int,
    sort_by: str | None,
    sort_dir: str | None,
    allowed: dict[str, str],
    default: str,
    where: qu.Where,
    tiebreak: str = "id",
) -> Listing:
    p, ps = qu.parse_page(page, page_size)
    order = qu.parse_sort(sort_by, sort_dir, allowed, default, tiebreak)
    return Listing(where, order, p, ps)


def _dates(where: qu.Where, col: str, date_from: str | None, date_to: str | None, as_timestamp: bool) -> None:
    df, dt = qu.parse_date("date_from", date_from), qu.parse_date("date_to", date_to)
    qu.check_range(df, dt)
    if df:
        where.add(f"{col} >= :date_from", date_from=df)
    if dt:
        where.add(
            f"{col} < :date_to_excl" if as_timestamp else f"{col} <= :date_to",
            **({"date_to_excl": dt + timedelta(days=1)} if as_timestamp else {"date_to": dt}),
        )


def _q(where: qu.Where, cols: list[str], q: str | None) -> None:
    if q and q.strip():
        like = f"%{qu.escape_like(q.strip()[:100])}%"
        where.add("(" + " OR ".join(f"{c} ILIKE :q ESCAPE '\\'" for c in cols) + ")", q=like)


def cost_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    service: str | None = Query(None),
    region: str | None = Query(None),
    source_type: str | None = Query(None),
    synthetic: bool | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "usage_date", date_from, date_to, False)
    if p := qu.pick("provider", provider, PROVIDERS):
        w.add("provider = :provider", provider=p)
    if service:
        w.add("service_name = :service", service=service.strip())
    if region:
        w.add("region = :region", region=region.strip().lower())
    if source_type:
        w.add("source_type = :source_type", source_type=source_type.strip().lower())
    if synthetic is not None:
        w.add("is_synthetic = :synthetic", synthetic=synthetic)
    _q(w, ["service_name", "account_identifier", "region"], q)
    allowed = {
        "date": "usage_date",
        "cost": "cost_amount",
        "service": "service_name",
        "provider": "provider",
        "region": "region",
    }
    return _common(page, page_size, sort_by, sort_dir, allowed, "date", w)


def event_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    severity: str | None = Query(None),
    provider: str | None = Query(None),
    service: str | None = Query(None),
    environment: str | None = Query(None),
    event_type: str | None = Query(None),
    correlation_id: str | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "event_timestamp", date_from, date_to, True)
    if s := qu.pick("severity", severity, EVENT_SEVERITIES):
        w.add("severity = :severity", severity=s)
    if p := qu.pick("provider", provider, PROVIDERS):
        w.add("provider = :provider", provider=p)
    if service:
        w.add("service = :service", service=service.strip())
    if environment:
        w.add("environment = :environment", environment=environment.strip().lower())
    if event_type:
        w.add("event_type = :event_type", event_type=event_type.strip())
    if correlation_id:
        w.add("correlation_id = :corr", corr=correlation_id.strip())
    if q and q.strip():
        w.add(
            "(search_vector @@ plainto_tsquery('simple', :fts) OR message ILIKE :q ESCAPE '\\')",
            fts=q.strip()[:100],
            q=f"%{qu.escape_like(q.strip()[:100])}%",
        )
    allowed = {"timestamp": "event_timestamp", "severity": EVT_RANK, "service": "service", "provider": "provider"}
    return _common(page, page_size, sort_by, sort_dir, allowed, "timestamp", w)


def anomaly_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    severity: str | None = Query(None),
    provider: str | None = Query(None),
    service: str | None = Query(None),
    method: str | None = Query(None),
    direction: str | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "usage_date", date_from, date_to, False)
    if s := qu.pick("severity", severity, ALERT_SEVERITIES):
        w.add("severity = :severity", severity=s)
    if p := qu.pick("provider", provider, PROVIDERS):
        w.add("provider = :provider", provider=p)
    if service:
        w.add("service_name = :service", service=service.strip())
    if m := qu.pick("method", method, {"robust_zscore", "isolation_forest"}):
        w.add("method = :method", method=m)
    if d := qu.pick("direction", direction, {"increase", "decrease"}):
        w.add("direction = :direction", direction=d)
    _q(w, ["explanation", "service_name"], q)
    allowed = {
        "date": "usage_date",
        "score": "score",
        "severity": SEV_RANK,
        "deviation": "deviation",
        "detected": "detected_at",
    }
    return _common(page, page_size, sort_by, sort_dir, allowed, "date", w)


def alert_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    severity: str | None = Query(None),
    status: str | None = Query(None),
    provider: str | None = Query(None),
    service: str | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "created_at", date_from, date_to, True)
    if s := qu.pick("severity", severity, ALERT_SEVERITIES):
        w.add("severity = :severity", severity=s)
    if st := qu.pick("status", status, {"open", "acknowledged", "resolved", "unresolved"}):
        w.add(
            "status <> 'resolved'" if st == "unresolved" else "status = :status",
            **({} if st == "unresolved" else {"status": st}),
        )
    if p := qu.pick("provider", provider, PROVIDERS):
        w.add("provider = :provider", provider=p)
    if service:
        w.add("service_name = :service", service=service.strip())
    _q(w, ["title", "service_name"], q)
    allowed = {"created": "created_at", "severity": SEV_RANK, "status": "status", "updated": "updated_at"}
    return _common(page, page_size, sort_by, sort_dir, allowed, "created", w)


def recommendation_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    service: str | None = Query(None),
    requires_review: bool | None = Query(None),
    source: str | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "r.generated_at", date_from, date_to, True)
    if p := qu.pick("provider", provider, PROVIDERS):
        w.add("r.provider = :provider", provider=p)
    if service:
        w.add("r.service_name = :service", service=service.strip())
    if requires_review is not None:
        w.add("r.requires_human_review = :rr", rr=requires_review)
    if s := qu.pick("source", source, {"rules", "rules+llm"}):
        w.add("r.source = :source", source=s)
    _q(w, ["r.summary", "r.service_name"], q)
    allowed = {
        "generated": "r.generated_at",
        "severity": "CASE a.severity WHEN 'low' THEN 1 WHEN 'medium' THEN 2 WHEN 'high' THEN 3 ELSE 4 END",
        "service": "r.service_name",
    }
    return _common(page, page_size, sort_by, sort_dir, allowed, "generated", w, tiebreak="r.id")


def incident_listing(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    status: str | None = Query(None),
    severity: str | None = Query(None),
    q: str | None = Query(None),
    sort_by: str | None = Query(None),
    sort_dir: str | None = Query(None),
    page: int = Query(1),
    page_size: int = Query(25),
) -> Listing:
    w = qu.Where()
    _dates(w, "opened_at", date_from, date_to, True)
    if st := qu.pick("status", status, {"open", "investigating", "resolved", "closed"}):
        w.add("status = :status", status=st)
    if s := qu.pick("severity", severity, ALERT_SEVERITIES):
        w.add("severity = :severity", severity=s)
    _q(w, ["title", "summary"], q)
    allowed = {"opened": "opened_at", "severity": SEV_RANK, "status": "status"}
    return _common(page, page_size, sort_by, sort_dir, allowed, "opened", w)


def run_listing(status: str | None = Query(None), page: int = Query(1), page_size: int = Query(25)) -> Listing:
    w = qu.Where()
    if st := qu.pick("status", status, {"running", "succeeded", "partial", "failed"}):
        w.add("status = :status", status=st)
    return _common(page, page_size, None, None, {"started": "started_at"}, "started", w)


def fetch_page(conn: Connection, columns: str, from_clause: str, lst: Listing) -> dict[str, Any]:
    where = lst.where.sql()
    total = conn.execute(text(f"SELECT count(*) FROM {from_clause} {where}"), lst.where.params).scalar_one()
    params = {**lst.where.params, "limit": lst.page_size, "offset": (lst.page - 1) * lst.page_size}
    rows = (
        conn.execute(
            text(f"SELECT {columns} FROM {from_clause} {where} ORDER BY {lst.order} LIMIT :limit OFFSET :offset"),
            params,
        )
        .mappings()
        .all()
    )
    return {
        "items": [dict(r) for r in rows],
        "total": total,
        "page": lst.page,
        "page_size": lst.page_size,
        "pages": (total + lst.page_size - 1) // lst.page_size,
    }


def fetch_all(conn: Connection, columns: str, from_clause: str, lst: Listing, limit: int = 50_000) -> list[dict]:
    """Unpaginated rows for exports: same filters and ordering, bounded by ``limit``."""
    rows = (
        conn.execute(
            text(f"SELECT {columns} FROM {from_clause} {lst.where.sql()} ORDER BY {lst.order} LIMIT :limit"),
            {**lst.where.params, "limit": limit},
        )
        .mappings()
        .all()
    )
    return [dict(r) for r in rows]
