from ..core.config import Settings
from .aws import AwsAdapter
from .azure import AzureAdapter
from .base import ConnectionResult, ProviderAdapter, ProviderStatus
from .mock import DemoAdapter


def get_adapters(settings: Settings) -> dict[str, ProviderAdapter]:
    return {"demo": DemoAdapter(settings.demo_data_dir), "aws": AwsAdapter(settings), "azure": AzureAdapter(settings)}


__all__ = ["ConnectionResult", "ProviderAdapter", "ProviderStatus", "get_adapters"]
