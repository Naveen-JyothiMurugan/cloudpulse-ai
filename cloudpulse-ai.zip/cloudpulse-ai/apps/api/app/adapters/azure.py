"""Azure adapter (OPTIONAL, disabled by default). NOT exercised against a real Azure subscription in this
repository's automated tests; see docs/TEST_RESULTS.md.

Authentication uses azure-identity's DefaultAzureCredential (managed identity in Azure, `az login`/env service
principal locally). No secrets are stored by CloudPulse. Cost data comes from the Cost Management Query REST API;
CONFIRM the current api-version and request schema in Microsoft's documentation before enabling this in
production (it is configurable via AZURE_COST_API_VERSION).
"""

from __future__ import annotations

import os
from typing import Any

from ..core.config import Settings
from .base import ConnectionResult, ProviderStatus

ARM_SCOPE = "https://management.azure.com/.default"


class AzureAdapter:
    name = "azure"

    def __init__(self, settings: Settings):
        self.s = settings
        self.api_version = os.environ.get("AZURE_COST_API_VERSION", "2023-11-01")

    def _missing(self) -> list[str]:
        return [
            n
            for n, v in (
                ("AZURE_TENANT_ID", self.s.azure_tenant_id),
                ("AZURE_SUBSCRIPTION_ID", self.s.azure_subscription_id),
            )
            if not v
        ]

    def status(self) -> ProviderStatus:
        miss = self._missing()
        return ProviderStatus(
            provider="azure",
            label="Microsoft Azure",
            configured=not miss,
            missing_config=miss,
            data_origin="provider",
            setup_instructions=[
                "Run the API with a managed identity (Container Apps / AKS workload identity) or `az login` locally.",
                "Set AZURE_TENANT_ID and AZURE_SUBSCRIPTION_ID (AZURE_CLIENT_ID for a user-assigned identity).",
                "Grant the identity the 'Cost Management Reader' and 'Reader' roles at the subscription scope.",
                "Never paste client secrets or passwords into this application.",
            ],
            capabilities=["cost_management", "functions_ingestion", "cosmos_events", "azure_monitor"],
        )

    def _token(self) -> str:
        from azure.identity import DefaultAzureCredential  # optional: pip install azure-identity

        kwargs = {"managed_identity_client_id": self.s.azure_client_id} if self.s.azure_client_id else {}
        return DefaultAzureCredential(**kwargs).get_token(ARM_SCOPE).token

    def test_connection(self) -> ConnectionResult:
        miss = self._missing()
        if miss:
            return ConnectionResult(False, f"Missing configuration: {', '.join(miss)}", {"missing": miss})
        try:
            self._token()
        except ImportError:
            return ConnectionResult(False, "azure-identity is not installed in this deployment.")
        except Exception as exc:
            return ConnectionResult(False, f"Azure authentication failed ({type(exc).__name__}).")
        return ConnectionResult(
            True, "Acquired an Azure Resource Manager token.", {"subscription": self.s.azure_subscription_id}
        )

    def fetch_costs(self, start: str, end: str) -> list[dict[str, Any]]:
        from datetime import date, timedelta

        import httpx  # in requirements

        # Adapter contract: `end` is exclusive (as in AWS); the Azure query's `to` is inclusive.
        end_inclusive = (date.fromisoformat(end) - timedelta(days=1)).isoformat()

        url = (
            f"https://management.azure.com/subscriptions/{self.s.azure_subscription_id}"
            f"/providers/Microsoft.CostManagement/query?api-version={self.api_version}"
        )
        body = {
            "type": "ActualCost",
            "timeframe": "Custom",
            "timePeriod": {"from": start, "to": end_inclusive},
            "dataset": {
                "granularity": "Daily",
                "aggregation": {"totalCost": {"name": "Cost", "function": "Sum"}},
                "grouping": [
                    {"type": "Dimension", "name": "ServiceName"},
                    {"type": "Dimension", "name": "ResourceLocation"},
                ],
            },
        }
        resp = httpx.post(url, json=body, headers={"Authorization": f"Bearer {self._token()}"}, timeout=30.0)
        resp.raise_for_status()
        props = resp.json()["properties"]
        cols = [c["name"] for c in props["columns"]]
        rows: list[dict[str, Any]] = []
        for r in props["rows"]:
            d = dict(zip(cols, r))
            raw_date = str(d.get("UsageDate"))  # YYYYMMDD integer in this API
            rows.append(
                {
                    "usage_date": f"{raw_date[:4]}-{raw_date[4:6]}-{raw_date[6:8]}",
                    "provider": "azure",
                    "account_identifier": self.s.azure_subscription_id,
                    "service_name": d.get("ServiceName") or "Unknown",
                    "region": (d.get("ResourceLocation") or "global"),
                    "usage_quantity": 0,
                    "usage_unit": "n/a",
                    "cost_amount": d.get("Cost", d.get("PreTaxCost", 0)),
                    "currency": d.get("Currency") or "USD",
                    "source_type": "azure_cost_management",
                }
            )
        return rows
