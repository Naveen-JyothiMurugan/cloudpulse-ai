"""AWS adapter (OPTIONAL, disabled by default). NOT exercised against a real AWS account in this repository's
automated tests; see docs/TEST_RESULTS.md. Uses boto3's default credential chain (IAM role, SSO, instance or
task role). Static access keys must never be entered into the UI or stored in the database.

Services touched (read-only unless noted): STS (identity check), Cost Explorer (GetCostAndUsage), S3 (raw file
storage, writes only to the configured bucket), CloudWatch (alarm/metric reads), DynamoDB (optional event table).
Cost Explorer API requests are billed per request by AWS, so results should be cached and polled sparingly.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from ..core.config import Settings
from .base import ConnectionResult, ProviderStatus

LEAST_PRIVILEGE_POLICY = """{
  "Version": "2012-10-17",
  "Statement": [
    {"Sid": "CostRead", "Effect": "Allow", "Action": ["ce:GetCostAndUsage"], "Resource": "*"},
    {"Sid": "Identity", "Effect": "Allow", "Action": ["sts:GetCallerIdentity"], "Resource": "*"},
    {"Sid": "MetricsRead", "Effect": "Allow", "Action": ["cloudwatch:DescribeAlarms", "cloudwatch:GetMetricData"], "Resource": "*"},
    {"Sid": "RawBucket", "Effect": "Allow", "Action": ["s3:GetObject", "s3:PutObject"], "Resource": "arn:aws:s3:::YOUR-BUCKET/cloudpulse/*"}
  ]
}"""


class AwsAdapter:
    name = "aws"

    def __init__(self, settings: Settings):
        self.s = settings

    def _missing(self) -> list[str]:
        miss = []
        if not self.s.aws_region:
            miss.append("AWS_REGION")
        return miss  # credentials come from the default chain / role, so they cannot be listed as 'missing'

    def status(self) -> ProviderStatus:
        miss = self._missing()
        return ProviderStatus(
            provider="aws",
            label="Amazon Web Services",
            configured=not miss,
            missing_config=miss,
            data_origin="provider",
            setup_instructions=[
                "Run the API with an IAM role (ECS task role, EC2 instance profile, IRSA) or local AWS SSO credentials.",
                "Set AWS_REGION (and optionally AWS_ROLE_ARN to assume a read-only role, AWS_S3_BUCKET, AWS_DYNAMODB_TABLE).",
                "Enable Cost Explorer in the AWS Billing console; allow billing access to the IAM principal.",
                "Attach a least-privilege policy such as the one in docs/DEPLOYMENT_GUIDE.md.",
                "Never paste access keys or root credentials into this application.",
            ],
            capabilities=["cost_explorer", "s3_raw_storage", "lambda_ingestion", "dynamodb_events", "cloudwatch"],
        )

    def _client(self, service: str):
        import boto3  # optional dependency: pip install boto3

        session = boto3.session.Session(region_name=self.s.aws_region or None)
        if self.s.aws_role_arn:
            sts = session.client("sts")
            creds = sts.assume_role(RoleArn=self.s.aws_role_arn, RoleSessionName="cloudpulse")["Credentials"]
            session = boto3.session.Session(
                aws_access_key_id=creds["AccessKeyId"],
                aws_secret_access_key=creds["SecretAccessKey"],
                aws_session_token=creds["SessionToken"],
                region_name=self.s.aws_region or None,
            )
        return session.client(service)

    def test_connection(self) -> ConnectionResult:
        miss = self._missing()
        if miss:
            return ConnectionResult(False, f"Missing configuration: {', '.join(miss)}", {"missing": miss})
        try:
            ident = self._client("sts").get_caller_identity()
        except ImportError:
            return ConnectionResult(False, "boto3 is not installed in this deployment.")
        except Exception as exc:  # botocore errors vary; never leak credentials or full responses
            return ConnectionResult(False, f"AWS call failed ({type(exc).__name__}).")
        return ConnectionResult(True, "Authenticated with AWS STS.", {"account": ident.get("Account")})

    def fetch_costs(self, start: str, end: str) -> list[dict[str, Any]]:
        """Daily UnblendedCost grouped by SERVICE. `end` is exclusive (Cost Explorer semantics)."""
        ce = self._client("ce")
        rows: list[dict[str, Any]] = []
        token = None
        account = self._client("sts").get_caller_identity().get("Account") or "unknown"
        while True:
            kwargs = {
                "TimePeriod": {"Start": start, "End": end},
                "Granularity": "DAILY",
                "Metrics": ["UnblendedCost", "UsageQuantity"],
                "GroupBy": [{"Type": "DIMENSION", "Key": "SERVICE"}],
            }
            if token:
                kwargs["NextPageToken"] = token
            resp = ce.get_cost_and_usage(**kwargs)
            for day in resp["ResultsByTime"]:
                for g in day["Groups"]:
                    cost = g["Metrics"]["UnblendedCost"]
                    qty = g["Metrics"]["UsageQuantity"]
                    rows.append(
                        {
                            "usage_date": date.fromisoformat(day["TimePeriod"]["Start"]).isoformat(),
                            "provider": "aws",
                            "account_identifier": account,
                            "service_name": g["Keys"][0],
                            "region": (self.s.aws_region or "global"),
                            "usage_quantity": qty["Amount"],
                            "usage_unit": qty.get("Unit") or "units",
                            "cost_amount": cost["Amount"],
                            "currency": cost["Unit"],
                            "source_type": "aws_cost_explorer",
                        }
                    )
            token = resp.get("NextPageToken")
            if not token:
                return rows
