"""Provider adapter interface. Adapters never receive credentials from the browser; they read
server-side configuration (env vars, IAM roles, managed identities) only."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class ConnectionResult:
    ok: bool
    message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProviderStatus:
    provider: str
    label: str
    configured: bool
    missing_config: list[str]
    data_origin: str  # "synthetic" | "provider"
    setup_instructions: list[str]
    capabilities: list[str]


class ProviderAdapter(Protocol):
    name: str

    def status(self) -> ProviderStatus: ...

    def test_connection(self) -> ConnectionResult: ...

    def fetch_costs(self, start: str, end: str) -> list[dict[str, Any]]:
        """Return rows shaped like the cost CSV schema (see docs/DATA_DICTIONARY.md)."""
        ...
