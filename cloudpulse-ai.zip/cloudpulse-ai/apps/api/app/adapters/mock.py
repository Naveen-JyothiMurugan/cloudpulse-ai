"""Demo adapter: always available, needs no credentials, produces SYNTHETIC data only."""

from __future__ import annotations

from pathlib import Path

from .base import ConnectionResult, ProviderStatus


class DemoAdapter:
    name = "demo"

    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)

    def status(self) -> ProviderStatus:
        has_files = (self.data_dir / "synthetic_costs.csv").exists()
        return ProviderStatus(
            provider="demo",
            label="Demo (synthetic data)",
            configured=True,
            missing_config=[] if has_files else [f"sample data files in {self.data_dir}"],
            data_origin="synthetic",
            setup_instructions=[
                "No credentials needed. Use 'Load demo data' to import the bundled synthetic dataset.",
                "Synthetic values are fabricated and are not real cloud bills.",
            ],
            capabilities=["cost_ingestion", "event_ingestion", "anomaly_detection", "forecasting"],
        )

    def test_connection(self) -> ConnectionResult:
        ok = (self.data_dir / "synthetic_costs.csv").exists()
        return ConnectionResult(
            ok, "Bundled synthetic dataset found." if ok else f"Synthetic dataset not found in {self.data_dir}."
        )

    def fetch_costs(self, start: str, end: str):
        raise NotImplementedError("Use load_demo_data(); the demo adapter serves a fixed CSV.")
