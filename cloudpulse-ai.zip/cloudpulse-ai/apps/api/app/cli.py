"""Operational CLI: bootstrap the first admin, load demo data, reset dev data.

  python -m app.cli create-admin --email you@example.com        (password from $CLOUDPULSE_ADMIN_PASSWORD or prompt)
  python -m app.cli create-user  --email viewer@example.com --role readonly
  python -m app.cli load-demo
  python -m app.cli reset-dev-data --yes                        (development only; refuses in production)

There is deliberately no public registration endpoint; accounts are created here by an operator.
"""

from __future__ import annotations

import argparse
import getpass
import os
import sys

from sqlalchemy import text
from sqlalchemy.engine import Connection

from .core.security import hash_password, validate_password_strength


def create_user(conn: Connection, email: str, password: str, role: str) -> int:
    email = email.strip().lower()
    if "@" not in email or len(email) > 254:
        raise ValueError("invalid email address")
    if role not in ("admin", "readonly"):
        raise ValueError("role must be admin or readonly")
    problems = validate_password_strength(password)
    if problems:
        raise ValueError("password " + "; ".join(problems))
    exists = conn.execute(text("SELECT 1 FROM users WHERE lower(email) = :e"), {"e": email}).first()
    if exists:
        raise ValueError(f"user {email} already exists")
    uid = conn.execute(
        text(
            "INSERT INTO users (email, password_hash, role_id) VALUES (:e, :h, (SELECT id FROM roles WHERE name = :r)) "
            "RETURNING id"
        ),
        {"e": email, "h": hash_password(password), "r": role},
    ).scalar_one()
    conn.execute(
        text(
            "INSERT INTO audit_events (actor_email, action, entity_type, entity_id, details_json) "
            "VALUES ('cli', 'user.create', 'user', :id, CAST(:d AS jsonb))"
        ),
        {"id": str(uid), "d": '{"role": "%s"}' % role},
    )
    conn.commit()
    return uid


def _password(args) -> str:
    pw = os.environ.get("CLOUDPULSE_ADMIN_PASSWORD") or os.environ.get("CLOUDPULSE_USER_PASSWORD")
    if pw:
        return pw
    if not sys.stdin.isatty():
        raise SystemExit("Set CLOUDPULSE_ADMIN_PASSWORD (non-interactive) or run in a terminal to be prompted.")
    first = getpass.getpass("Password: ")
    if first != getpass.getpass("Repeat password: "):
        raise SystemExit("Passwords do not match.")
    return first


def main(argv: list[str] | None = None) -> int:
    from .db import get_engine, get_settings

    p = argparse.ArgumentParser(prog="app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("create-admin", "create-user"):
        sp = sub.add_parser(name)
        sp.add_argument("--email", required=True)
        if name == "create-user":
            sp.add_argument("--role", choices=["admin", "readonly"], default="readonly")
    sub.add_parser("load-demo")
    rd = sub.add_parser("reset-dev-data")
    rd.add_argument("--yes", action="store_true")
    args = p.parse_args(argv)
    settings = get_settings()

    with get_engine().connect() as conn:
        if args.cmd in ("create-admin", "create-user"):
            role = "admin" if args.cmd == "create-admin" else args.role
            try:
                uid = create_user(conn, args.email, _password(args), role)
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
            print(f"created {role} user id={uid}")
        elif args.cmd == "load-demo":
            from .services.ingest import load_demo_data

            out = load_demo_data(conn, settings.demo_data_dir, None)
            print("loaded SYNTHETIC demo data:", out)
        elif args.cmd == "reset-dev-data":
            if settings.is_production:
                print("refusing to reset data when APP_ENV=production", file=sys.stderr)
                return 2
            if not args.yes:
                print("pass --yes to confirm deleting cost, event, anomaly, alert and incident data", file=sys.stderr)
                return 2
            conn.execute(
                text(
                    "TRUNCATE incident_events, incident_alerts, investigation_notes, incidents, alert_events, "
                    "alerts, recommendations, anomalies, forecast_runs, operational_events, cost_records, "
                    "ingestion_runs RESTART IDENTITY CASCADE"
                )
            )
            conn.commit()
            print("development data cleared (users and audit log were kept)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
