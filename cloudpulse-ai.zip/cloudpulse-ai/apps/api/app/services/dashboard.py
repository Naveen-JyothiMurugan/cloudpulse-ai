"""Dashboard and cost aggregation queries. Everything is computed from stored rows."""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Connection

from .detect import primary_currency

PROVIDER_SOURCES = {"aws_cost_explorer", "azure_cost_management"}


def resolve_period(
    conn: Connection, date_from: date | None, date_to: date | None, default_days: int = 30
) -> tuple[date | None, date | None]:
    """Default the window to the most recent ``default_days`` of *stored* data (demo data is historical)."""
    latest = conn.execute(text("SELECT max(usage_date) FROM cost_records")).scalar()
    if latest is None:
        return date_from, date_to
    to = date_to or latest
    frm = date_from or (to - timedelta(days=default_days - 1))
    return frm, to


def classify_origin(source_types: set[str]) -> str:
    if not source_types:
        return "none"
    if source_types <= {"synthetic"}:
        return "synthetic"
    if source_types <= PROVIDER_SOURCES:
        return "provider"
    if source_types <= {"manual_csv"}:
        return "uploaded"
    return "mixed"


def _total(conn: Connection, cur: str, frm: date, to: date, provider: str | None) -> float:
    return float(
        conn.execute(
            text(
                "SELECT COALESCE(sum(cost_amount), 0) FROM cost_records WHERE currency = :c AND usage_date BETWEEN "
                ":f AND :t AND (CAST(:p AS text) IS NULL OR provider = :p)"
            ),
            {"c": cur, "f": frm, "t": to, "p": provider},
        ).scalar_one()
    )


def _breakdown(conn: Connection, col: str, cur: str, frm: date, to: date, provider: str | None, limit: int = 15):
    if col not in ("provider", "service_name", "region"):  # identifier allow-list, never user input
        raise ValueError("invalid breakdown column")
    rows = (
        conn.execute(
            text(
                f"SELECT {col} AS name, sum(cost_amount) AS cost FROM cost_records WHERE currency = :c AND usage_date "
                f"BETWEEN :f AND :t AND (CAST(:p AS text) IS NULL OR provider = :p) GROUP BY {col} "
                f"ORDER BY sum(cost_amount) DESC, {col} LIMIT :lim"
            ),
            {"c": cur, "f": frm, "t": to, "p": provider, "lim": limit},
        )
        .mappings()
        .all()
    )
    return [{"name": r["name"], "cost": round(float(r["cost"]), 2)} for r in rows]


def cost_summary(
    conn: Connection, date_from: date | None, date_to: date | None, provider: str | None = None
) -> dict[str, Any]:
    cur = primary_currency(conn)
    frm, to = resolve_period(conn, date_from, date_to)
    if cur is None or frm is None or to is None:
        return {
            "has_data": False,
            "data_origin": "none",
            "period": None,
            "total_cost": 0.0,
            "message": "No cost data loaded. Load the demo data or upload a CSV.",
        }
    days = (to - frm).days + 1
    prev_to, prev_from = frm - timedelta(days=1), frm - timedelta(days=days)
    total = _total(conn, cur, frm, to, provider)
    prev = _total(conn, cur, prev_from, prev_to, provider)
    sources = {
        r[0]
        for r in conn.execute(
            text("SELECT DISTINCT source_type FROM cost_records WHERE usage_date BETWEEN :f AND :t"),
            {"f": frm, "t": to},
        ).all()
    }
    latest, last_run = (
        conn.execute(text("SELECT max(usage_date) FROM cost_records")).scalar(),
        conn.execute(text("SELECT status, finished_at FROM ingestion_runs ORDER BY started_at DESC, id DESC LIMIT 1"))
        .mappings()
        .first(),
    )
    return {
        "has_data": True,
        "currency": cur,
        "period": {"from": frm.isoformat(), "to": to.isoformat(), "days": days},
        "previous_period": {"from": prev_from.isoformat(), "to": prev_to.isoformat()},
        "total_cost": round(total, 2),
        "previous_period_total": round(prev, 2),
        "change_amount": round(total - prev, 2),
        "change_percent": round((total - prev) / prev * 100, 2) if prev else None,
        "by_provider": _breakdown(conn, "provider", cur, frm, to, provider),
        "by_service": _breakdown(conn, "service_name", cur, frm, to, provider),
        "by_region": _breakdown(conn, "region", cur, frm, to, provider),
        "data_origin": classify_origin(sources),
        "source_types": sorted(sources),
        "freshness": {
            "latest_usage_date": latest.isoformat() if latest else None,
            "last_ingestion_status": last_run["status"] if last_run else None,
            "last_ingestion_finished_at": last_run["finished_at"] if last_run else None,
        },
    }


def timeseries(
    conn: Connection,
    date_from: date | None,
    date_to: date | None,
    granularity: str = "day",
    group_by: str = "none",
    provider: str | None = None,
) -> dict[str, Any]:
    if granularity not in ("day", "month"):
        raise ValueError("granularity must be day or month")
    cols = {"none": "'all'", "provider": "provider", "service": "service_name", "region": "region"}
    if group_by not in cols:
        raise ValueError("group_by must be one of none, provider, service, region")
    cur = primary_currency(conn)
    frm, to = resolve_period(conn, date_from, date_to, default_days=90 if granularity == "day" else 365)
    if cur is None or frm is None or to is None:
        return {"has_data": False, "points": []}
    trunc = "day" if granularity == "day" else "month"
    rows = (
        conn.execute(
            text(
                f"SELECT to_char(date_trunc('{trunc}', usage_date), 'YYYY-MM-DD') AS period, {cols[group_by]} AS grp, "
                "sum(cost_amount) AS cost FROM cost_records WHERE currency = :c AND usage_date BETWEEN :f AND :t "
                "AND (CAST(:p AS text) IS NULL OR provider = :p) GROUP BY 1, 2 ORDER BY 1, 2"
            ),
            {"c": cur, "f": frm, "t": to, "p": provider},
        )
        .mappings()
        .all()
    )
    return {
        "has_data": True,
        "currency": cur,
        "granularity": granularity,
        "group_by": group_by,
        "period": {"from": frm.isoformat(), "to": to.isoformat()},
        "points": [{"period": r["period"], "group": r["grp"], "cost": round(float(r["cost"]), 2)} for r in rows],
    }


def dashboard(
    conn: Connection, date_from: date | None, date_to: date | None, provider: str | None = None
) -> dict[str, Any]:
    summary = cost_summary(conn, date_from, date_to, provider)
    frm, to = resolve_period(conn, date_from, date_to)
    alert_rows = (
        conn.execute(text("SELECT severity, count(*) AS n FROM alerts WHERE status <> 'resolved' GROUP BY severity"))
        .mappings()
        .all()
    )
    unresolved = {r["severity"]: r["n"] for r in alert_rows}
    anomaly_rows = (
        conn.execute(
            text(
                "SELECT severity, count(*) AS n FROM anomalies WHERE (CAST(:f AS date) IS NULL OR usage_date >= :f) "
                "AND (CAST(:t AS date) IS NULL OR usage_date <= :t) GROUP BY severity"
            ),
            {"f": frm, "t": to},
        )
        .mappings()
        .all()
    )
    events = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT id, provider, service, severity, event_type, event_timestamp, message, is_synthetic "
                "FROM operational_events ORDER BY event_timestamp DESC, id DESC LIMIT 8"
            )
        )
        .mappings()
        .all()
    ]
    runs = (
        conn.execute(
            text(
                "SELECT status, count(*) AS n FROM (SELECT status FROM ingestion_runs ORDER BY started_at DESC, id DESC "
                "LIMIT 20) r GROUP BY status"
            )
        )
        .mappings()
        .all()
    )
    last = (
        conn.execute(
            text(
                "SELECT id, status, rows_inserted, rows_rejected, started_at, finished_at FROM ingestion_runs "
                "ORDER BY started_at DESC, id DESC LIMIT 1"
            )
        )
        .mappings()
        .first()
    )
    return {
        "summary": summary,
        "unresolved_alerts": {"total": sum(unresolved.values()), "by_severity": unresolved},
        "anomalies": {
            "total": sum(r["n"] for r in anomaly_rows),
            "by_severity": {r["severity"]: r["n"] for r in anomaly_rows},
        },
        "recent_events": events,
        "ingestion_health": {
            "recent_runs_by_status": {r["status"]: r["n"] for r in runs},
            "last_run": dict(last) if last else None,
        },
    }
