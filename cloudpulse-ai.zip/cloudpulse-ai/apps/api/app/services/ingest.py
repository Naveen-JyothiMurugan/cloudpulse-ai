"""Cost CSV and operational-event ingestion into PostgreSQL (idempotent, set-based SQL)."""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import UTC, datetime
from typing import Any

from cloudpulse_ingestion import EventValidationError, parse_cost_csv, validate_event
from sqlalchemy import text
from sqlalchemy.engine import Connection

log = logging.getLogger("cloudpulse.ingest")

CHUNK = 2000
MAX_EVENTS_PER_REQUEST = 500

_COST_INSERT = text("""
INSERT INTO cost_records (usage_date, provider, account_identifier, service_name, region, usage_quantity,
                          usage_unit, cost_amount, currency, source_type, is_synthetic, row_hash, ingestion_run_id)
SELECT x.usage_date, x.provider, x.account_identifier, x.service_name, x.region, x.usage_quantity, x.usage_unit,
       x.cost_amount, x.currency, x.source_type, x.is_synthetic, x.row_hash, :run
FROM jsonb_to_recordset(CAST(:rows AS jsonb)) AS x(
    usage_date date, provider text, account_identifier text, service_name text, region text,
    usage_quantity numeric, usage_unit text, cost_amount numeric, currency text, source_type text,
    is_synthetic boolean, row_hash text)
ON CONFLICT (row_hash) DO NOTHING
""")


def _finish_run(
    conn: Connection,
    run_id: int,
    status: str,
    total: int,
    inserted: int,
    dup: int,
    rejected: int,
    summary: str | None,
    errors: list[dict],
) -> None:
    conn.execute(
        text(
            "UPDATE ingestion_runs SET status = :s, rows_total = :t, rows_inserted = :i, rows_duplicate = :d, "
            "rows_rejected = :r, error_summary = :sum, errors_json = CAST(:e AS jsonb), finished_at = now() "
            "WHERE id = :id"
        ),
        {
            "s": status,
            "t": total,
            "i": inserted,
            "d": dup,
            "r": rejected,
            "sum": summary,
            "e": json.dumps(errors),
            "id": run_id,
        },
    )


def ingest_cost_csv(
    conn: Connection, data: bytes, filename: str | None, user_id: int | None, source_label: str = "csv_upload"
) -> dict[str, Any]:
    """Validate and load a cost CSV. Re-uploading the same data inserts nothing new."""
    sha = hashlib.sha256(data).hexdigest()
    run_id = conn.execute(
        text(
            "INSERT INTO ingestion_runs (source_type, filename, file_sha256, status, user_id) "
            "VALUES (:src, :fn, :sha, 'running', :uid) RETURNING id"
        ),
        {"src": source_label, "fn": (filename or "")[:255] or None, "sha": sha, "uid": user_id},
    ).scalar_one()
    conn.commit()  # the run row survives even if loading fails

    res = parse_cost_csv(data)
    errors = [e.to_dict() for e in res.errors]
    if not res.ok:
        _finish_run(conn, run_id, "failed", res.rows_total, 0, 0, res.rows_rejected, res.file_error, errors)
        conn.commit()
        return {
            "run_id": run_id,
            "status": "failed",
            "rows_total": res.rows_total,
            "rows_inserted": 0,
            "rows_duplicate": 0,
            "rows_rejected": res.rows_rejected,
            "error": res.file_error,
            "errors": errors,
            "errors_truncated": res.errors_truncated,
            "file_sha256": sha,
        }
    try:
        inserted = 0
        rows = res.valid_rows
        for i in range(0, len(rows), CHUNK):
            payload = json.dumps(rows[i : i + CHUNK], default=str)
            inserted += conn.execute(_COST_INSERT, {"rows": payload, "run": run_id}).rowcount
        duplicates = len(rows) - inserted
        if res.rows_rejected and inserted + duplicates == 0:
            status = "failed"
        elif res.rows_rejected:
            status = "partial"
        else:
            status = "succeeded"
        summary = f"{res.rows_rejected} row(s) rejected" if res.rows_rejected else None
        _finish_run(conn, run_id, status, res.rows_total, inserted, duplicates, res.rows_rejected, summary, errors)
        conn.commit()
    except Exception:
        conn.rollback()
        _finish_run(
            conn, run_id, "failed", res.rows_total, 0, 0, res.rows_rejected, "Database error while loading.", errors
        )
        conn.commit()
        raise
    return {
        "run_id": run_id,
        "status": status,
        "rows_total": res.rows_total,
        "rows_inserted": inserted,
        "rows_duplicate": duplicates,
        "rows_rejected": res.rows_rejected,
        "errors": errors,
        "errors_truncated": res.errors_truncated,
        "file_sha256": sha,
    }


_EVENT_INSERT = text("""
INSERT INTO operational_events (external_event_id, provider, service, environment, severity, event_type,
                                event_timestamp, message, correlation_id, metadata_json, is_synthetic)
SELECT x.external_event_id, x.provider, x.service, x.environment, x.severity, x.event_type, x.event_timestamp,
       x.message, x.correlation_id, x.metadata_json, x.is_synthetic
FROM jsonb_to_recordset(CAST(:rows AS jsonb)) AS x(
    external_event_id text, provider text, service text, environment text, severity text, event_type text,
    event_timestamp timestamptz, message text, correlation_id text, metadata_json jsonb, is_synthetic boolean)
ON CONFLICT (provider, external_event_id) DO NOTHING
RETURNING provider, external_event_id
""")


def ingest_events(conn: Connection, payloads: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate and store events. Returns per-item results; duplicates are reported, not errors."""
    if not payloads:
        return {"created": 0, "duplicates": 0, "rejected": 0, "results": []}
    if len(payloads) > MAX_EVENTS_PER_REQUEST:
        raise ValueError(f"at most {MAX_EVENTS_PER_REQUEST} events per request")
    results: list[dict[str, Any]] = [{} for _ in payloads]
    valid: list[tuple[int, dict[str, Any]]] = []
    for idx, p in enumerate(payloads):
        if not isinstance(p, dict):
            results[idx] = {
                "index": idx,
                "status": "rejected",
                "errors": [{"field": "body", "reason": "must be an object"}],
            }
            continue
        try:
            valid.append((idx, validate_event(p)))
        except EventValidationError as e:
            results[idx] = {
                "index": idx,
                "event_id": str(p.get("event_id", "")),
                "status": "rejected",
                "errors": e.problems,
            }
    created_keys: set[tuple[str, str]] = set()
    if valid:
        rows = [
            {**ev, "event_timestamp": ev["event_timestamp"].isoformat(), "metadata_json": ev["metadata"]}
            for _, ev in valid
        ]
        for r in rows:
            r.pop("metadata", None)
        got = conn.execute(_EVENT_INSERT, {"rows": json.dumps(rows, default=str)}).mappings().all()
        created_keys = {(g["provider"], g["external_event_id"]) for g in got}
    seen: set[tuple[str, str]] = set()
    for idx, ev in valid:
        key = (ev["provider"], ev["external_event_id"])
        status = "created" if key in created_keys and key not in seen else "duplicate"
        seen.add(key)
        results[idx] = {"index": idx, "event_id": ev["external_event_id"], "status": status}
    out = {
        "created": sum(r["status"] == "created" for r in results),
        "duplicates": sum(r["status"] == "duplicate" for r in results),
        "rejected": sum(r["status"] == "rejected" for r in results),
        "results": results,
    }
    conn.commit()
    return out


def load_demo_data(conn: Connection, data_dir: str, user_id: int | None) -> dict[str, Any]:
    """Load the bundled SYNTHETIC cost CSV and events (idempotent)."""
    from pathlib import Path

    base = Path(data_dir)
    cost_path, event_path = base / "synthetic_costs.csv", base / "synthetic_events.json"
    if not cost_path.exists() or not event_path.exists():
        raise FileNotFoundError(f"demo data not found in {base}")
    costs = ingest_cost_csv(conn, cost_path.read_bytes(), cost_path.name, user_id, "demo_load")
    events = ingest_events(conn, json.loads(event_path.read_text()))
    conn.execute(
        text(
            "UPDATE cloud_integrations SET last_sync_at = :now, last_sync_status = 'succeeded', "
            "status = 'connected' WHERE provider = 'demo'"
        ),
        {"now": datetime.now(UTC)},
    )
    conn.commit()
    return {
        "costs": {k: v for k, v in costs.items() if k != "errors"},
        "events": {k: v for k, v in events.items() if k != "results"},
        "synthetic": True,
    }


class SyncError(Exception):
    """The provider call failed; the message is safe to show to users (no credentials, no raw responses)."""


def rows_to_csv(rows: list[dict[str, Any]]) -> bytes:
    """Serialise adapter rows in the documented CSV schema so they pass through the same validation as uploads."""
    import csv
    import io

    cols = [
        "usage_date", "provider", "account_identifier", "service_name", "region",
        "usage_quantity", "usage_unit", "cost_amount", "currency", "source_type",
    ]  # fmt: skip
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore", lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue().encode("utf-8")


def sync_from_adapter(
    conn: Connection, adapter: Any, provider: str, start: str, end: str, user_id: int | None
) -> dict[str, Any]:
    """Pull cost rows from a provider adapter and load them idempotently. `end` is exclusive."""
    try:
        rows = adapter.fetch_costs(start, end)
    except Exception as exc:  # botocore / azure / network errors vary; never leak details to the client
        log.warning("provider sync failed", extra={"provider": provider, "error": type(exc).__name__})
        conn.execute(
            text(
                "UPDATE cloud_integrations SET last_sync_at = now(), last_sync_status = 'failed', "
                "status = 'error' WHERE provider = :p"
            ),
            {"p": provider},
        )
        conn.commit()
        raise SyncError(
            f"The {provider} request failed ({type(exc).__name__}). Check credentials and permissions."
        ) from None
    result = ingest_cost_csv(conn, rows_to_csv(rows), f"{provider}_{start}_{end}.csv", user_id, f"{provider}_sync")
    ok = result["status"] in ("succeeded", "partial")
    conn.execute(
        text(
            "UPDATE cloud_integrations SET last_sync_at = now(), last_sync_status = :s, "
            "status = CASE WHEN :ok THEN 'connected' ELSE 'error' END WHERE provider = :p"
        ),
        {"s": "succeeded" if ok else "failed", "ok": ok, "p": provider},
    )
    conn.commit()
    return {k: v for k, v in result.items() if k != "errors"}
