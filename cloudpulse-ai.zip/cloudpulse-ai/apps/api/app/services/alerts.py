"""Alert and incident lifecycle. State changes are single conditional UPDATEs, so concurrent
requests cannot double-apply a transition."""

from __future__ import annotations

from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Connection


class NotFound(Exception):
    pass


class Conflict(Exception):
    pass


def get_alert(conn: Connection, alert_id: int) -> dict[str, Any]:
    a = conn.execute(text("SELECT * FROM alerts WHERE id = :id"), {"id": alert_id}).mappings().first()
    if not a:
        raise NotFound("alert")
    out = dict(a)
    out["anomaly"] = None
    if a["anomaly_id"]:
        an = conn.execute(text("SELECT * FROM anomalies WHERE id = :id"), {"id": a["anomaly_id"]}).mappings().first()
        out["anomaly"] = dict(an) if an else None
        rec = (
            conn.execute(text("SELECT * FROM recommendations WHERE anomaly_id = :id"), {"id": a["anomaly_id"]})
            .mappings()
            .first()
        )
        out["recommendation"] = dict(rec) if rec else None
    out["events"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT e.id, e.provider, e.service, e.severity, e.event_type, e.event_timestamp, e.message, e.correlation_id "
                "FROM alert_events ae JOIN operational_events e ON e.id = ae.event_id WHERE ae.alert_id = :id "
                "ORDER BY e.event_timestamp, e.id"
            ),
            {"id": alert_id},
        )
        .mappings()
        .all()
    ]
    out["notes"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT n.id, n.body, n.created_at, u.email AS author FROM investigation_notes n "
                "LEFT JOIN users u ON u.id = n.author_id WHERE n.alert_id = :id ORDER BY n.created_at, n.id"
            ),
            {"id": alert_id},
        )
        .mappings()
        .all()
    ]
    out["incidents"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT i.id, i.title, i.status FROM incident_alerts ia JOIN incidents i ON i.id = ia.incident_id "
                "WHERE ia.alert_id = :id ORDER BY i.opened_at DESC"
            ),
            {"id": alert_id},
        )
        .mappings()
        .all()
    ]
    return out


def acknowledge(conn: Connection, alert_id: int, user_id: int) -> dict[str, Any]:
    """open -> acknowledged. Re-acknowledging is a no-op; a resolved alert cannot be acknowledged."""
    changed = conn.execute(
        text(
            "UPDATE alerts SET status = 'acknowledged', acknowledged_at = now(), acknowledged_by = :u, "
            "updated_at = now() WHERE id = :id AND status = 'open' RETURNING id"
        ),
        {"id": alert_id, "u": user_id},
    ).first()
    if not changed:
        cur = conn.execute(text("SELECT status FROM alerts WHERE id = :id"), {"id": alert_id}).scalar()
        if cur is None:
            raise NotFound("alert")
        if cur == "resolved":
            raise Conflict("Alert is already resolved.")
    conn.commit()
    return get_alert(conn, alert_id)


def resolve(conn: Connection, alert_id: int, user_id: int) -> dict[str, Any]:
    """open|acknowledged -> resolved. Resolving twice is a no-op."""
    changed = conn.execute(
        text(
            "UPDATE alerts SET status = 'resolved', resolved_at = now(), resolved_by = :u, updated_at = now() "
            "WHERE id = :id AND status <> 'resolved' RETURNING id"
        ),
        {"id": alert_id, "u": user_id},
    ).first()
    if not changed and conn.execute(text("SELECT 1 FROM alerts WHERE id = :id"), {"id": alert_id}).first() is None:
        raise NotFound("alert")
    conn.commit()
    return get_alert(conn, alert_id)


def add_note(
    conn: Connection, user_id: int, body: str, alert_id: int | None = None, incident_id: int | None = None
) -> dict[str, Any]:
    body = body.strip()
    if not 1 <= len(body) <= 4000:
        raise ValueError("note must be between 1 and 4000 characters")
    table, ident = ("alerts", alert_id) if alert_id else ("incidents", incident_id)
    if conn.execute(text(f"SELECT 1 FROM {table} WHERE id = :id"), {"id": ident}).first() is None:
        raise NotFound(table[:-1])
    row = (
        conn.execute(
            text(
                "INSERT INTO investigation_notes (alert_id, incident_id, author_id, body) VALUES (:a, :i, :u, :b) "
                "RETURNING id, body, created_at"
            ),
            {"a": alert_id, "i": incident_id, "u": user_id, "b": body},
        )
        .mappings()
        .first()
    )
    if alert_id:
        conn.execute(text("UPDATE alerts SET updated_at = now() WHERE id = :id"), {"id": alert_id})
    conn.commit()
    return dict(row)


def create_incident(
    conn: Connection, user_id: int, title: str, severity: str, summary: str | None, alert_ids: list[int]
) -> dict[str, Any]:
    title = title.strip()
    if not 3 <= len(title) <= 200:
        raise ValueError("title must be between 3 and 200 characters")
    if alert_ids:
        found = {
            r[0]
            for r in conn.execute(text("SELECT id FROM alerts WHERE id = ANY(:ids)"), {"ids": list(alert_ids)}).all()
        }
        missing = set(alert_ids) - found
        if missing:
            raise NotFound(f"alerts {sorted(missing)}")
    iid = conn.execute(
        text(
            "INSERT INTO incidents (title, summary, severity, owner_id, created_by) VALUES (:t, :s, :sev, :u, :u) "
            "RETURNING id"
        ),
        {"t": title, "s": summary, "sev": severity, "u": user_id},
    ).scalar_one()
    for aid in dict.fromkeys(alert_ids):
        conn.execute(
            text("INSERT INTO incident_alerts (incident_id, alert_id) VALUES (:i, :a) ON CONFLICT DO NOTHING"),
            {"i": iid, "a": aid},
        )
    conn.execute(
        text(
            "INSERT INTO incident_events (incident_id, event_id) SELECT :i, ae.event_id FROM alert_events ae "
            "WHERE ae.alert_id = ANY(:ids) ON CONFLICT DO NOTHING"
        ),
        {"i": iid, "ids": list(alert_ids)},
    )
    conn.commit()
    return get_incident(conn, iid)


def get_incident(conn: Connection, incident_id: int) -> dict[str, Any]:
    inc = conn.execute(text("SELECT * FROM incidents WHERE id = :id"), {"id": incident_id}).mappings().first()
    if not inc:
        raise NotFound("incident")
    out = dict(inc)
    out["alerts"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT a.id, a.title, a.severity, a.status FROM incident_alerts ia JOIN alerts a ON a.id = ia.alert_id "
                "WHERE ia.incident_id = :id ORDER BY a.created_at, a.id"
            ),
            {"id": incident_id},
        )
        .mappings()
        .all()
    ]
    out["events"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT e.id, e.provider, e.service, e.severity, e.event_type, e.event_timestamp, e.message "
                "FROM incident_events ie JOIN operational_events e ON e.id = ie.event_id WHERE ie.incident_id = :id "
                "ORDER BY e.event_timestamp, e.id"
            ),
            {"id": incident_id},
        )
        .mappings()
        .all()
    ]
    out["notes"] = [
        dict(r)
        for r in conn.execute(
            text(
                "SELECT n.id, n.body, n.created_at, u.email AS author FROM investigation_notes n "
                "LEFT JOIN users u ON u.id = n.author_id WHERE n.incident_id = :id ORDER BY n.created_at, n.id"
            ),
            {"id": incident_id},
        )
        .mappings()
        .all()
    ]
    return out


_TRANSITIONS = {
    "open": {"investigating", "resolved", "closed"},
    "investigating": {"open", "resolved", "closed"},
    "resolved": {"open", "closed"},
    "closed": set(),
}


def update_incident_status(conn: Connection, incident_id: int, new_status: str) -> dict[str, Any]:
    cur = conn.execute(text("SELECT status FROM incidents WHERE id = :id"), {"id": incident_id}).scalar()
    if cur is None:
        raise NotFound("incident")
    if new_status == cur:
        return get_incident(conn, incident_id)
    if new_status not in _TRANSITIONS.get(cur, set()):
        raise Conflict(f"Cannot move an incident from {cur} to {new_status}.")
    conn.execute(
        text(
            "UPDATE incidents SET status = :s, closed_at = CASE WHEN :s IN ('resolved','closed') "
            "THEN now() ELSE NULL END WHERE id = :id"
        ),
        {"s": new_status, "id": incident_id},
    )
    conn.commit()
    return get_incident(conn, incident_id)
