"""Run anomaly detection and forecasting over stored cost data; create alerts and recommendations."""

from __future__ import annotations

import dataclasses
import json
from typing import Any

import pandas as pd
from cloudpulse_analytics import (
    DetectionConfig,
    ForecastConfig,
    build_recommendation,
    detect_anomalies,
    enrich_with_llm,
    run_forecast,
)
from sqlalchemy import text
from sqlalchemy.engine import Connection

ALLOWED_OVERRIDES = {f.name for f in dataclasses.fields(DetectionConfig)}


def primary_currency(conn: Connection) -> str | None:
    """No FX conversion is performed; analytics run on the dominant currency only."""
    return conn.execute(
        text("SELECT currency FROM cost_records GROUP BY currency ORDER BY count(*) DESC, currency LIMIT 1")
    ).scalar()


def load_cost_frame(
    conn: Connection, currency: str, date_from: str | None = None, date_to: str | None = None
) -> pd.DataFrame:
    rows = (
        conn.execute(
            text(
                "SELECT usage_date, provider, service_name, cost_amount, is_synthetic FROM cost_records "
                "WHERE currency = :cur AND (CAST(:df AS date) IS NULL OR usage_date >= CAST(:df AS date)) "
                "AND (CAST(:dt AS date) IS NULL OR usage_date <= CAST(:dt AS date)) ORDER BY usage_date, provider, "
                "service_name, id"
            ),
            {"cur": currency, "df": date_from, "dt": date_to},
        )
        .mappings()
        .all()
    )
    df = pd.DataFrame(
        [dict(r) for r in rows], columns=["usage_date", "provider", "service_name", "cost_amount", "is_synthetic"]
    )
    df["cost_amount"] = pd.to_numeric(df["cost_amount"])
    return df


def build_config(overrides: dict[str, Any] | None) -> DetectionConfig:
    overrides = overrides or {}
    unknown = set(overrides) - ALLOWED_OVERRIDES
    if unknown:
        raise ValueError(f"unknown detection setting(s): {sorted(unknown)}")
    cfg = DetectionConfig(**overrides)
    cfg.validate()
    return cfg


def run_detection(
    conn: Connection,
    overrides: dict[str, Any] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    llm_client=None,
    on_llm_error=None,
) -> dict[str, Any]:
    cfg = build_config(overrides)
    warnings: list[str] = []
    cur = primary_currency(conn)
    if cur is None:
        return {
            "status": "no_data",
            "detected": 0,
            "new": 0,
            "suppressed_duplicates": 0,
            "alerts_created": 0,
            "recommendations_created": 0,
            "warnings": ["No cost records are loaded."],
            "by_severity": {},
            "config": dataclasses.asdict(cfg),
        }
    n_cur = conn.execute(text("SELECT count(DISTINCT currency) FROM cost_records")).scalar_one()
    if n_cur > 1:
        warnings.append(f"Multiple currencies present; analysed {cur} only (no FX conversion is performed).")

    df = load_cost_frame(conn, cur, date_from, date_to)
    anomalies = detect_anomalies(df, cfg) if not df.empty else []
    synth: dict[tuple, bool] = {}
    if not df.empty:
        d = df.assign(usage_date=pd.to_datetime(df["usage_date"]).dt.strftime("%Y-%m-%d"))
        synth = d.groupby(["provider", "service_name", "usage_date"])["is_synthetic"].all().to_dict()

    new = alerts_created = recs_created = 0
    by_sev: dict[str, int] = {}
    cfg_json = json.dumps(dataclasses.asdict(cfg))
    for a in anomalies:
        ad = a.to_dict()
        is_syn = bool(synth.get((a.provider, a.service_name, a.usage_date), False))
        row = conn.execute(
            text(
                "INSERT INTO anomalies (provider, service_name, region, usage_date, observed_value, expected_value, "
                "deviation, pct_change, score, severity, method, direction, signals_json, explanation, config_json, "
                "is_synthetic, fingerprint) VALUES (:provider, :service_name, :region, :usage_date, :observed_value, "
                ":expected_value, :deviation, :pct_change, :score, :severity, :method, :direction, "
                "CAST(:signals AS jsonb), :explanation, CAST(:cfg AS jsonb), :syn, :fingerprint) "
                "ON CONFLICT (fingerprint) DO NOTHING RETURNING id"
            ),
            {
                **{
                    k: ad[k]
                    for k in (
                        "provider",
                        "service_name",
                        "region",
                        "usage_date",
                        "observed_value",
                        "expected_value",
                        "deviation",
                        "pct_change",
                        "score",
                        "severity",
                        "method",
                        "direction",
                        "explanation",
                        "fingerprint",
                    )
                },
                "signals": json.dumps(ad["signals"]),
                "cfg": cfg_json,
                "syn": is_syn,
            },
        ).first()
        anomaly_id = (
            row[0]
            if row
            else conn.execute(
                text("SELECT id FROM anomalies WHERE fingerprint = :f"), {"f": a.fingerprint}
            ).scalar_one()
        )
        if row:
            new += 1
            by_sev[a.severity] = by_sev.get(a.severity, 0) + 1
            title = f"{a.severity.title()}: {a.provider.upper()} {a.service_name} cost {a.direction} on {a.usage_date}"
            alerts_created += conn.execute(
                text(
                    "INSERT INTO alerts (anomaly_id, fingerprint, title, severity, provider, service_name) "
                    "VALUES (:aid, :fp, :t, :sev, :p, :s) ON CONFLICT (fingerprint) DO NOTHING RETURNING id"
                ),
                {
                    "aid": anomaly_id,
                    "fp": a.fingerprint,
                    "t": title,
                    "sev": a.severity,
                    "p": a.provider,
                    "s": a.service_name,
                },
            ).rowcount
            rec = enrich_with_llm(build_recommendation(ad), llm_client, on_llm_error)
            recs_created += conn.execute(
                text(
                    "INSERT INTO recommendations (anomaly_id, provider, service_name, summary, evidence_json, "
                    "potential_impact, confidence_note, next_steps_json, requires_human_review, source, "
                    "ai_explanation_json) VALUES (:aid, :p, :s, :sum, CAST(:ev AS jsonb), :imp, :conf, "
                    "CAST(:steps AS jsonb), :rr, :src, CAST(:ai AS jsonb)) ON CONFLICT (anomaly_id) DO NOTHING "
                    "RETURNING id"
                ),
                {
                    "aid": anomaly_id,
                    "p": rec["provider"],
                    "s": rec["service_name"],
                    "sum": rec["summary"],
                    "ev": json.dumps(rec["evidence"], default=str),
                    "imp": rec["potential_impact"],
                    "conf": rec["confidence_note"],
                    "steps": json.dumps(rec["next_steps"]),
                    "rr": rec["requires_human_review"],
                    "src": rec["source"],
                    "ai": json.dumps(rec["ai_explanation"]) if rec["ai_explanation"] else None,
                },
            ).rowcount
    # Link operational events within +/- 1 day of each anomaly to its alert (idempotent; also picks up
    # events ingested after the alert was created).
    conn.execute(
        text(
            "INSERT INTO alert_events (alert_id, event_id) SELECT al.id, e.id FROM alerts al "
            "JOIN anomalies an ON an.id = al.anomaly_id JOIN operational_events e ON e.provider = an.provider "
            "AND lower(e.service) = lower(an.service_name) "
            "AND e.event_timestamp >= an.usage_date - 1 AND e.event_timestamp < an.usage_date + 2 "
            "ON CONFLICT DO NOTHING"
        )
    )
    conn.commit()
    return {
        "status": "ok",
        "detected": len(anomalies),
        "new": new,
        "suppressed_duplicates": len(anomalies) - new,
        "alerts_created": alerts_created,
        "recommendations_created": recs_created,
        "by_severity": by_sev,
        "warnings": warnings,
        "currency": cur,
        "config": dataclasses.asdict(cfg),
    }


def run_forecast_job(conn: Connection, horizon_days: int, user_id: int | None) -> dict[str, Any]:
    cfg = ForecastConfig(horizon_days=horizon_days)
    cfg.validate()
    cur = primary_currency(conn)
    if cur is None:
        df = pd.DataFrame({"usage_date": [], "cost_amount": []})
        synthetic = False
    else:
        df = load_cost_frame(conn, cur)
        synthetic = bool(df["is_synthetic"].all()) if not df.empty else False
    result = run_forecast(df, cfg)
    if cur and conn.execute(text("SELECT count(DISTINCT currency) FROM cost_records")).scalar_one() > 1:
        result["warnings"].append(f"Multiple currencies present; forecast covers {cur} only.")
    result["currency"] = cur
    result["is_synthetic"] = synthetic
    ev = result.get("evaluation") or {}
    fid = conn.execute(
        text(
            "INSERT INTO forecast_runs (horizon_days, method, status, data_points, mae, params_json, results_json, "
            "warnings_json, is_synthetic, created_by) VALUES (:h, :m, :st, :n, :mae, CAST(:p AS jsonb), "
            "CAST(:r AS jsonb), CAST(:w AS jsonb), :syn, :uid) RETURNING id"
        ),
        {
            "h": horizon_days,
            "m": cfg.method,
            "st": result["status"],
            "n": result.get("data_points", 0),
            "mae": ev.get("mae"),
            "p": json.dumps(result["config"]),
            "r": json.dumps({k: result.get(k) for k in ("history", "forecast", "evaluation", "forecast_total")}),
            "w": json.dumps(result["warnings"]),
            "syn": synthetic,
            "uid": user_id,
        },
    ).scalar_one()
    conn.commit()
    result["id"] = fid
    return result
