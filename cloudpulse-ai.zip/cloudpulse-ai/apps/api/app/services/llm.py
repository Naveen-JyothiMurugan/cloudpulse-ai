"""Optional LLM provider abstraction (disabled unless LLM_PROVIDER and LLM_API_KEY are set server-side).

Only the Anthropic Messages API is implemented here, via plain HTTPS. The key lives in the API process
environment and is never returned to the browser. Output is validated by cloudpulse_analytics before use,
and any failure falls back to the deterministic rule text. NOT exercised against a live provider in this
repository's automated tests (a fake client is used instead).
"""

from __future__ import annotations

from ..core.config import Settings


class AnthropicClient:
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, api_key: str, model: str, timeout: float):
        self._key, self.model, self.timeout = api_key, model, timeout

    def complete(self, prompt: str) -> str:
        import httpx

        r = httpx.post(
            self.URL,
            timeout=self.timeout,
            headers={"x-api-key": self._key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": self.model, "max_tokens": 600, "messages": [{"role": "user", "content": prompt}]},
        )
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")

    def __repr__(self) -> str:  # never print the key
        return f"AnthropicClient(model={self.model!r})"


def build_llm_client(s: Settings):
    if not s.llm_provider or not s.llm_api_key:
        return None
    if s.llm_provider.lower() == "anthropic" and s.llm_model:
        return AnthropicClient(s.llm_api_key, s.llm_model, s.llm_timeout_s)
    return None  # unknown provider or missing model: behave as if no LLM is configured
