"""In-process sliding-window rate limiter.

Suitable for a single API replica. With several replicas the counters are per-process; use a
shared store (Redis) or an ingress/gateway limit in that case. See docs/DECISIONS.md.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable


class SlidingWindowLimiter:
    def __init__(self, max_calls: int, window_s: float, clock: Callable[[], float] = time.monotonic):
        if max_calls < 1 or window_s <= 0:
            raise ValueError("max_calls must be >= 1 and window_s > 0")
        self.max_calls, self.window_s, self.clock = max_calls, window_s, clock
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> tuple[bool, int]:
        """Record an attempt. Returns (allowed, retry_after_seconds)."""
        now = self.clock()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] >= self.window_s:
                q.popleft()
            if len(q) >= self.max_calls:
                return False, max(1, int(self.window_s - (now - q[0])) + 1)
            q.append(now)
            if len(self._hits) > 10_000:  # bound memory: drop idle keys
                for k in [k for k, v in self._hits.items() if not v or now - v[-1] >= self.window_s]:
                    del self._hits[k]
            return True, 0

    def reset(self, key: str) -> None:
        with self._lock:
            self._hits.pop(key, None)
