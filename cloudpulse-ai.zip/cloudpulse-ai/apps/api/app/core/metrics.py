"""Prometheus metrics: API latency/errors, ingestion outcomes, anomaly processing, DB health."""

from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram, generate_latest

REGISTRY = CollectorRegistry()

HTTP_REQUESTS = Counter(
    "cloudpulse_http_requests_total", "HTTP requests", ["method", "route", "status"], registry=REGISTRY
)
HTTP_LATENCY = Histogram(
    "cloudpulse_http_request_duration_seconds",
    "HTTP request latency",
    ["method", "route"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10),
    registry=REGISTRY,
)
INGESTION_RUNS = Counter(
    "cloudpulse_ingestion_runs_total", "Ingestion runs by outcome", ["source", "status"], registry=REGISTRY
)
INGESTION_ROWS = Counter("cloudpulse_ingestion_rows_total", "Ingested rows by result", ["result"], registry=REGISTRY)
ANOMALIES_DETECTED = Counter(
    "cloudpulse_anomalies_detected_total", "Anomalies by severity (new only)", ["severity"], registry=REGISTRY
)
DETECTION_RUNS = Counter("cloudpulse_detection_runs_total", "Anomaly detection runs", ["status"], registry=REGISTRY)
DETECTION_SECONDS = Histogram("cloudpulse_detection_duration_seconds", "Anomaly detection duration", registry=REGISTRY)
DB_UP = Gauge("cloudpulse_db_up", "1 if the last database check succeeded", registry=REGISTRY)
LLM_FALLBACKS = Counter("cloudpulse_llm_fallbacks_total", "LLM calls that fell back to rules", registry=REGISTRY)


def render() -> bytes:
    return generate_latest(REGISTRY)
