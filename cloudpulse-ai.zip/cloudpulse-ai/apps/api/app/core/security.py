"""Password hashing, signed session tokens and CSRF helpers (standard library only).

* Passwords: scrypt (RFC 7914) from hashlib/OpenSSL with a per-password random salt.
* Sessions: stateless, HMAC-SHA256 signed token carried in an HttpOnly cookie. Contains the
  user id, role, expiry and a CSRF secret. Role is re-read from the database on each request,
  so revoking or demoting a user takes effect immediately.
* CSRF: double-submit pattern. The CSRF secret inside the signed session must be echoed by the
  client in the X-CSRF-Token header for unsafe methods.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass

SCRYPT_N, SCRYPT_R, SCRYPT_P = 2**15, 8, 1
SCRYPT_MAXMEM = 128 * 1024 * 1024
MIN_PASSWORD_LENGTH = 12


class SessionError(Exception):
    """Invalid, tampered or expired session token."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason  # "invalid" | "expired"


def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def validate_password_strength(password: str) -> list[str]:
    problems = []
    if len(password) < MIN_PASSWORD_LENGTH:
        problems.append(f"must be at least {MIN_PASSWORD_LENGTH} characters")
    if len(password) > 256:
        problems.append("must be at most 256 characters")
    if password.lower() == password or password.upper() == password or not any(c.isdigit() for c in password):
        problems.append("must mix upper and lower case letters and include a digit")
    return problems


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(
        password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, maxmem=SCRYPT_MAXMEM, dklen=32
    )
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_b64e(salt)}${_b64e(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt, expected = stored.split("$")
        if scheme != "scrypt":
            return False
        dk = hashlib.scrypt(
            password.encode(),
            salt=_b64d(salt),
            n=int(n),
            r=int(r),
            p=int(p),
            maxmem=SCRYPT_MAXMEM,
            dklen=len(_b64d(expected)),
        )
        return hmac.compare_digest(dk, _b64d(expected))
    except (ValueError, TypeError):
        return False


# A fixed hash used so that logins for unknown users cost the same time as real ones.
DUMMY_HASH = hash_password("dummy-password-for-timing-0")


@dataclass(frozen=True)
class Session:
    user_id: int
    role: str
    csrf: str
    expires_at: int


def create_session_token(secret: str, user_id: int, role: str, ttl_seconds: int, now: float | None = None) -> str:
    now = time.time() if now is None else now
    payload = {"uid": user_id, "role": role, "csrf": secrets.token_urlsafe(24), "exp": int(now + ttl_seconds)}
    body = _b64e(json.dumps(payload, separators=(",", ":")).encode())
    sig = _b64e(hmac.new(secret.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def verify_session_token(secret: str, token: str, now: float | None = None) -> Session:
    now = time.time() if now is None else now
    try:
        body, sig = token.split(".")
        expected = _b64e(hmac.new(secret.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            raise SessionError("invalid")
        data = json.loads(_b64d(body))
        sess = Session(int(data["uid"]), str(data["role"]), str(data["csrf"]), int(data["exp"]))
    except SessionError:
        raise
    except Exception:
        raise SessionError("invalid")
    if sess.expires_at <= now:
        raise SessionError("expired")
    return sess


def csrf_ok(session: Session, header_value: str | None) -> bool:
    return bool(header_value) and hmac.compare_digest(session.csrf, header_value)
