"""Safe pagination, sorting and filter building for parameterised SQL (stdlib only).

Sort fields come from per-resource allow-lists; every value goes through bind parameters,
so user input is never concatenated into SQL text.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

MAX_PAGE_SIZE = 200
DEFAULT_PAGE_SIZE = 25


class QueryError(ValueError):
    def __init__(self, field_name: str, reason: str):
        super().__init__(f"{field_name}: {reason}")
        self.field, self.reason = field_name, reason


def parse_page(page: int | None, page_size: int | None) -> tuple[int, int]:
    page = 1 if page is None else page
    page_size = DEFAULT_PAGE_SIZE if page_size is None else page_size
    if page < 1:
        raise QueryError("page", "must be >= 1")
    if not 1 <= page_size <= MAX_PAGE_SIZE:
        raise QueryError("page_size", f"must be between 1 and {MAX_PAGE_SIZE}")
    return page, page_size


def parse_sort(
    sort_by: str | None, sort_dir: str | None, allowed: dict[str, str], default: str, tiebreak: str = "id"
) -> str:
    """Return an ORDER BY clause fragment using only allow-listed column expressions."""
    key = sort_by or default
    if key not in allowed:
        raise QueryError("sort_by", f"must be one of {sorted(allowed)}")
    direction = (sort_dir or "desc").lower()
    if direction not in ("asc", "desc"):
        raise QueryError("sort_dir", "must be asc or desc")
    return f"{allowed[key]} {direction.upper()}, {tiebreak} {direction.upper()}"  # stable, predictable order


def parse_date(name: str, value: str | date | None) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise QueryError(name, "must be an ISO date (YYYY-MM-DD)")


def check_range(date_from: date | None, date_to: date | None) -> None:
    if date_from and date_to and date_from > date_to:
        raise QueryError("date_from", "must not be after date_to")


def pick(name: str, value: str | None, allowed: set[str]) -> str | None:
    if value is None or value == "":
        return None
    v = value.strip().lower()
    if v not in allowed:
        raise QueryError(name, f"must be one of {sorted(allowed)}")
    return v


@dataclass
class Where:
    """Accumulates AND-ed predicates and their bind parameters."""

    clauses: list[str] = field(default_factory=list)
    params: dict[str, Any] = field(default_factory=dict)

    def add(self, clause: str, **params: Any) -> "Where":
        self.clauses.append(clause)
        self.params.update(params)
        return self

    def sql(self) -> str:
        return ("WHERE " + " AND ".join(self.clauses)) if self.clauses else ""


def escape_like(term: str) -> str:
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
