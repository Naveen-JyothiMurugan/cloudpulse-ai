"""Environment-driven configuration (stdlib only). No secrets have defaults in production."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

DEV_SECRET = "dev-only-insecure-secret-change-me-0123456789"  # noqa: S105  (rejected outside development, see validate)


class ConfigError(RuntimeError):
    pass


def _bool(name: str, default: bool) -> bool:
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _list(name: str, default: str) -> list[str]:
    return [x.strip() for x in os.environ.get(name, default).split(",") if x.strip()]


@dataclass(frozen=True)
class Settings:
    app_env: str = "development"  # development | test | production
    database_url: str = "postgresql+psycopg://cloudpulse:cloudpulse@localhost:5432/cloudpulse"
    secret_key: str = DEV_SECRET
    session_ttl_minutes: int = 60
    cookie_secure: bool = False
    cors_origins: list[str] = field(default_factory=lambda: ["http://localhost:3000"])
    default_data_mode: str = "demo"
    login_rate_limit: int = 5  # attempts
    login_rate_window_s: int = 300
    upload_rate_limit: int = 10
    upload_rate_window_s: int = 60
    max_upload_bytes: int = 5 * 1024 * 1024
    lockout_threshold: int = 5
    lockout_minutes: int = 15
    log_level: str = "INFO"
    llm_provider: str = ""  # "" disables the optional LLM
    llm_api_key: str = ""
    llm_model: str = ""
    llm_timeout_s: float = 10.0
    metrics_enabled: bool = True
    ingest_api_token: str = ""  # optional bearer token for serverless ingestion (Lambda / Functions)
    demo_data_dir: str = "data/sample"
    # Optional cloud integrations (all disabled unless configured server-side)
    aws_region: str = ""
    aws_role_arn: str = ""
    aws_s3_bucket: str = ""
    aws_dynamodb_table: str = ""
    azure_tenant_id: str = ""
    azure_subscription_id: str = ""
    azure_client_id: str = ""

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"


def load_settings(env: dict[str, str] | None = None) -> Settings:
    if env is not None:  # tests may inject a mapping
        old = os.environ.copy()
        os.environ.clear()
        os.environ.update(env)
        try:
            return load_settings()
        finally:
            os.environ.clear()
            os.environ.update(old)
    g = os.environ.get
    s = Settings(
        app_env=g("APP_ENV", "development"),
        database_url=g("DATABASE_URL", Settings.database_url),
        secret_key=g("SECRET_KEY", DEV_SECRET),
        session_ttl_minutes=int(g("SESSION_TTL_MINUTES", "60")),
        cookie_secure=_bool("COOKIE_SECURE", False),
        cors_origins=_list("CORS_ORIGINS", "http://localhost:3000"),
        default_data_mode=g("DEFAULT_DATA_MODE", "demo"),
        login_rate_limit=int(g("LOGIN_RATE_LIMIT", "5")),
        login_rate_window_s=int(g("LOGIN_RATE_WINDOW_S", "300")),
        upload_rate_limit=int(g("UPLOAD_RATE_LIMIT", "10")),
        upload_rate_window_s=int(g("UPLOAD_RATE_WINDOW_S", "60")),
        max_upload_bytes=int(g("MAX_UPLOAD_BYTES", str(5 * 1024 * 1024))),
        lockout_threshold=int(g("LOCKOUT_THRESHOLD", "5")),
        lockout_minutes=int(g("LOCKOUT_MINUTES", "15")),
        log_level=g("LOG_LEVEL", "INFO").upper(),
        llm_provider=g("LLM_PROVIDER", ""),
        llm_api_key=g("LLM_API_KEY", ""),
        llm_model=g("LLM_MODEL", ""),
        llm_timeout_s=float(g("LLM_TIMEOUT_S", "10")),
        metrics_enabled=_bool("METRICS_ENABLED", True),
        ingest_api_token=g("INGEST_API_TOKEN", ""),
        demo_data_dir=g("DEMO_DATA_DIR", "data/sample"),
        aws_region=g("AWS_REGION", ""),
        aws_role_arn=g("AWS_ROLE_ARN", ""),
        aws_s3_bucket=g("AWS_S3_BUCKET", ""),
        aws_dynamodb_table=g("AWS_DYNAMODB_TABLE", ""),
        azure_tenant_id=g("AZURE_TENANT_ID", ""),
        azure_subscription_id=g("AZURE_SUBSCRIPTION_ID", ""),
        azure_client_id=g("AZURE_CLIENT_ID", ""),
    )
    validate_settings(s)
    return s


def validate_settings(s: Settings) -> None:
    if s.app_env not in ("development", "test", "production"):
        raise ConfigError("APP_ENV must be development, test or production")
    if s.default_data_mode not in ("demo", "aws", "azure"):
        raise ConfigError("DEFAULT_DATA_MODE must be demo, aws or azure")
    if s.is_production:
        if s.secret_key == DEV_SECRET or len(s.secret_key) < 32:
            raise ConfigError("SECRET_KEY must be set to a random value of at least 32 characters in production")
        if not s.cookie_secure:
            raise ConfigError("COOKIE_SECURE must be true in production")
        if "*" in s.cors_origins:
            raise ConfigError("CORS_ORIGINS must not contain '*' in production")
    if s.ingest_api_token and len(s.ingest_api_token) < 24:
        raise ConfigError("INGEST_API_TOKEN must be at least 24 characters when set")
    if len(s.secret_key) < 16:
        raise ConfigError("SECRET_KEY is too short")
    if s.session_ttl_minutes < 1:
        raise ConfigError("SESSION_TTL_MINUTES must be >= 1")
