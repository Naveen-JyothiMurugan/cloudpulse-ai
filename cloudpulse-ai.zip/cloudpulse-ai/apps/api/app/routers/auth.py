from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Connection

from ..core.errors import ApiError, error_body
from ..core.ratelimit import SlidingWindowLimiter
from ..core.security import DUMMY_HASH, create_session_token, verify_password, verify_session_token
from ..db import get_conn, get_settings
from ..deps import COOKIE_NAME, audit, client_ip, current_user

router = APIRouter(prefix="/auth", tags=["auth"])

_s = get_settings()
_limit_pair = SlidingWindowLimiter(_s.login_rate_limit, _s.login_rate_window_s)  # per ip + email
_limit_ip = SlidingWindowLimiter(_s.login_rate_limit * 4, _s.login_rate_window_s)  # per ip, any email
GENERIC_FAILURE = "Invalid email or password."


class LoginRequest(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=256)


def _user_payload(u: dict, csrf: str | None = None) -> dict:
    out = {"id": u["id"], "email": u["email"], "role": u["role"]}
    if csrf:
        out["csrf_token"] = csrf
    return out


@router.post("/login", summary="Sign in and receive an HttpOnly session cookie")
def login(body: LoginRequest, request: Request, conn: Connection = Depends(get_conn)):
    s = get_settings()
    ip, email = client_ip(request), body.email.strip().lower()
    for lim, key in ((_limit_ip, ip), (_limit_pair, f"{ip}|{email}")):
        allowed, retry = lim.check(key)
        if not allowed:
            raise ApiError(
                429, "rate_limited", "Too many sign-in attempts. Try again later.", headers={"Retry-After": str(retry)}
            )
    row = (
        conn.execute(
            text(
                "SELECT u.id, u.email, u.password_hash, u.is_active, u.failed_login_count, u.locked_until, r.name AS role "
                "FROM users u JOIN roles r ON r.id = u.role_id WHERE lower(u.email) = :e"
            ),
            {"e": email},
        )
        .mappings()
        .first()
    )
    now = datetime.now(UTC)
    locked = bool(row and row["locked_until"] and row["locked_until"] > now)
    # Always run one hash verification so timing does not reveal whether the account exists or is locked.
    valid = verify_password(body.password, row["password_hash"] if row and not locked else DUMMY_HASH)
    if row and valid and row["is_active"] and not locked:
        conn.execute(
            text("UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = now() WHERE id = :id"),
            {"id": row["id"]},
        )
        user = {"id": row["id"], "email": row["email"], "role": row["role"]}
        audit(conn, request, user, "auth.login.success", "user", row["id"])
        conn.commit()
        _limit_pair.reset(f"{ip}|{email}")
        ttl = s.session_ttl_minutes * 60
        token = create_session_token(s.secret_key, row["id"], row["role"], ttl)
        csrf = verify_session_token(s.secret_key, token).csrf
        resp = JSONResponse(_user_payload(user, csrf))
        resp.set_cookie(
            COOKIE_NAME, token, max_age=ttl, httponly=True, secure=s.cookie_secure, samesite="lax", path="/"
        )
        return resp
    # Failure path: record it and COMMIT (no exception is raised, so the audit row and counter persist).
    if row and not locked:
        failed = row["failed_login_count"] + 1
        lock_until = now + timedelta(minutes=s.lockout_minutes) if failed >= s.lockout_threshold else None
        conn.execute(
            text("UPDATE users SET failed_login_count = :n, locked_until = :l WHERE id = :id"),
            {"n": 0 if lock_until else failed, "l": lock_until, "id": row["id"]},
        )
    audit(conn, request, None, "auth.login.failure", "user", None, {"email": email, "locked": locked})
    conn.commit()
    return JSONResponse(error_body("invalid_credentials", GENERIC_FAILURE), status_code=401)


@router.post("/logout", status_code=204, summary="End the session (clears the cookie)")
def logout() -> Response:
    resp = Response(status_code=204)
    resp.delete_cookie(COOKIE_NAME, path="/")
    return resp


@router.get("/me", summary="Current user, role and CSRF token")
def me(user: dict = Depends(current_user)):
    return _user_payload(user, user["csrf"])
