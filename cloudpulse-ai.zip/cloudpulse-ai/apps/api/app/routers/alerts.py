from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy.engine import Connection

from ..core.errors import ApiError
from ..db import get_conn
from ..deps import audit, current_user, require_admin
from ..listing import Listing, alert_listing, fetch_page, incident_listing
from ..services import alerts as svc

router = APIRouter()


class NoteRequest(BaseModel):
    body: str = Field(min_length=1, max_length=4000)


class IncidentCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    severity: str = Field(pattern="^(low|medium|high|critical)$")
    summary: str | None = Field(default=None, max_length=4000)
    alert_ids: list[int] = Field(default_factory=list, max_length=50)


class IncidentStatus(BaseModel):
    status: str = Field(pattern="^(open|investigating|resolved|closed)$")


def _translate(fn, *a, **kw):
    """Map service exceptions to API errors."""
    try:
        return fn(*a, **kw)
    except svc.NotFound as e:
        raise ApiError(404, "not_found", f"{e} not found.")
    except svc.Conflict as e:
        raise ApiError(409, "conflict", str(e))
    except ValueError as e:
        raise ApiError(422, "validation_error", str(e))


@router.get("/alerts", tags=["alerts"], summary="List alerts (filter by severity, status, provider, date)")
def list_alerts(
    lst: Listing = Depends(alert_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(
        conn,
        "id, anomaly_id, title, severity, status, provider, service_name, created_at, updated_at, "
        "acknowledged_at, resolved_at",
        "alerts",
        lst,
    )


@router.get("/alerts/{alert_id}", tags=["alerts"], summary="Alert detail with anomaly, events, notes, incidents")
def get_alert(alert_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    return _translate(svc.get_alert, conn, alert_id)


@router.post("/alerts/{alert_id}/acknowledge", tags=["alerts"], summary="Acknowledge an open alert")
def acknowledge(
    alert_id: int, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    out = _translate(svc.acknowledge, conn, alert_id, admin["id"])
    audit(conn, request, admin, "alert.acknowledge", "alert", alert_id)
    conn.commit()
    return out


@router.post("/alerts/{alert_id}/resolve", tags=["alerts"], summary="Resolve an alert")
def resolve(
    alert_id: int, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    out = _translate(svc.resolve, conn, alert_id, admin["id"])
    audit(conn, request, admin, "alert.resolve", "alert", alert_id)
    conn.commit()
    return out


@router.post("/alerts/{alert_id}/notes", tags=["alerts"], status_code=201, summary="Add an investigation note")
def alert_note(
    alert_id: int,
    body: NoteRequest,
    request: Request,
    conn: Connection = Depends(get_conn),
    admin: dict = Depends(require_admin),
):
    out = _translate(svc.add_note, conn, admin["id"], body.body, alert_id=alert_id)
    audit(conn, request, admin, "alert.note", "alert", alert_id)
    conn.commit()
    return out


@router.get("/incidents", tags=["incidents"], summary="Incident history")
def list_incidents(
    lst: Listing = Depends(incident_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(conn, "id, title, status, severity, owner_id, opened_at, closed_at", "incidents", lst)


@router.post("/incidents", tags=["incidents"], status_code=201, summary="Open an incident from one or more alerts")
def create_incident(
    body: IncidentCreate, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    out = _translate(svc.create_incident, conn, admin["id"], body.title, body.severity, body.summary, body.alert_ids)
    audit(conn, request, admin, "incident.create", "incident", out["id"])
    conn.commit()
    return out


@router.get("/incidents/{incident_id}", tags=["incidents"], summary="Incident detail")
def get_incident(incident_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    return _translate(svc.get_incident, conn, incident_id)


@router.patch("/incidents/{incident_id}", tags=["incidents"], summary="Change incident status")
def update_incident(
    incident_id: int,
    body: IncidentStatus,
    request: Request,
    conn: Connection = Depends(get_conn),
    admin: dict = Depends(require_admin),
):
    out = _translate(svc.update_incident_status, conn, incident_id, body.status)
    audit(conn, request, admin, "incident.status", "incident", incident_id, {"status": body.status})
    conn.commit()
    return out


@router.post("/incidents/{incident_id}/notes", tags=["incidents"], status_code=201, summary="Add an incident note")
def incident_note(
    incident_id: int,
    body: NoteRequest,
    request: Request,
    conn: Connection = Depends(get_conn),
    admin: dict = Depends(require_admin),
):
    out = _translate(svc.add_note, conn, admin["id"], body.body, incident_id=incident_id)
    audit(conn, request, admin, "incident.note", "incident", incident_id)
    conn.commit()
    return out
