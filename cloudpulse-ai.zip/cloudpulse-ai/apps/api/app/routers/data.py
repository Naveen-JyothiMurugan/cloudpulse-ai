from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, File, Query, Request, UploadFile
from sqlalchemy import text
from sqlalchemy.engine import Connection

from ..core import metrics
from ..core import queryutil as qu
from ..core.errors import ApiError
from ..core.ratelimit import SlidingWindowLimiter
from ..db import get_conn, get_settings
from ..deps import audit, client_ip, current_user, ingest_principal
from ..listing import PROVIDERS, Listing, cost_listing, event_listing, fetch_page, run_listing
from ..services import dashboard as dash
from ..services import ingest as ing

router = APIRouter()
_s = get_settings()
_upload_limit = SlidingWindowLimiter(_s.upload_rate_limit, _s.upload_rate_window_s)
_event_limit = SlidingWindowLimiter(60, 60)
ALLOWED_UPLOAD_TYPES = {
    "text/csv",
    "application/csv",
    "text/plain",
    "application/vnd.ms-excel",
    "application/octet-stream",
}


def _throttle(limiter: SlidingWindowLimiter, request: Request, principal: dict) -> None:
    ok, retry = limiter.check(f"{principal['email']}|{client_ip(request)}")
    if not ok:
        raise ApiError(429, "rate_limited", "Too many requests. Slow down.", headers={"Retry-After": str(retry)})


# ---- cost ingestion -----------------------------------------------------------------------------------------
@router.post(
    "/ingestion/costs",
    tags=["ingestion"],
    status_code=201,
    summary="Upload a cost CSV (validated, normalised, idempotent)",
)
def upload_costs(
    request: Request,
    file: UploadFile = File(...),
    conn: Connection = Depends(get_conn),
    principal: dict = Depends(ingest_principal),
):
    _throttle(_upload_limit, request, principal)
    name = (file.filename or "").strip()
    if not name.lower().endswith(".csv"):
        raise ApiError(400, "invalid_file", "Only .csv files are accepted.")
    if (file.content_type or "application/octet-stream").split(";")[0].strip().lower() not in ALLOWED_UPLOAD_TYPES:
        raise ApiError(400, "invalid_file", "Unsupported content type for CSV upload.")
    limit = get_settings().max_upload_bytes
    data = file.file.read(limit + 1)  # never read more than the limit into memory
    if len(data) > limit:
        raise ApiError(413, "file_too_large", f"File exceeds the {limit // (1024 * 1024)} MB limit.")
    result = ing.ingest_cost_csv(conn, data, name, principal["id"], "csv_upload")
    audit(
        conn,
        request,
        principal,
        "ingestion.costs",
        "ingestion_run",
        result["run_id"],
        {k: result[k] for k in ("status", "rows_total", "rows_inserted", "rows_duplicate", "rows_rejected")},
    )
    conn.commit()
    metrics.INGESTION_RUNS.labels("csv_upload", result["status"]).inc()
    for k, label in (("rows_inserted", "inserted"), ("rows_duplicate", "duplicate"), ("rows_rejected", "rejected")):
        metrics.INGESTION_ROWS.labels(label).inc(result[k])
    if result["status"] == "failed" and result.get("error"):
        raise ApiError(422, "invalid_csv", result["error"], {"run_id": result["run_id"]})
    return result


@router.get("/ingestion/runs", tags=["ingestion"], summary="Ingestion run history")
def list_runs(
    lst: Listing = Depends(run_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(
        conn,
        "id, source_type, filename, status, rows_total, rows_inserted, rows_duplicate, "
        "rows_rejected, error_summary, started_at, finished_at",
        "ingestion_runs",
        lst,
    )


@router.get("/ingestion/runs/{run_id}", tags=["ingestion"], summary="Run detail including row errors")
def get_run(run_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    row = conn.execute(text("SELECT * FROM ingestion_runs WHERE id = :id"), {"id": run_id}).mappings().first()
    if not row:
        raise ApiError(404, "not_found", "Ingestion run not found.")
    return dict(row)


# ---- costs --------------------------------------------------------------------------------------------------
COST_COLS = (
    "id, usage_date, provider, account_identifier, service_name, region, usage_quantity, usage_unit, "
    "cost_amount, currency, source_type, is_synthetic, ingestion_run_id"
)


@router.get("/costs", tags=["costs"], summary="Paginated, filterable cost records")
def list_costs(
    lst: Listing = Depends(cost_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(conn, COST_COLS, "cost_records", lst)


def _period(date_from: str | None, date_to: str | None, provider: str | None):
    df, dt = qu.parse_date("date_from", date_from), qu.parse_date("date_to", date_to)
    qu.check_range(df, dt)
    return df, dt, qu.pick("provider", provider, PROVIDERS)


@router.get(
    "/costs/summary", tags=["costs"], summary="Totals, previous-period comparison and breakdowns for a date range"
)
def costs_summary(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    conn: Connection = Depends(get_conn),
    _: dict = Depends(current_user),
):
    return dash.cost_summary(conn, *_period(date_from, date_to, provider))


@router.get("/costs/timeseries", tags=["costs"], summary="Daily or monthly cost series, optionally grouped")
def costs_timeseries(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    granularity: str = Query("day"),
    group_by: str = Query("none"),
    provider: str | None = Query(None),
    conn: Connection = Depends(get_conn),
    _: dict = Depends(current_user),
):
    df, dt, prov = _period(date_from, date_to, provider)
    try:
        return dash.timeseries(conn, df, dt, granularity, group_by, prov)
    except ValueError as e:
        raise ApiError(422, "validation_error", str(e))


@router.get("/dashboard", tags=["costs"], summary="Everything the overview page needs, in one call")
def dashboard(
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    conn: Connection = Depends(get_conn),
    _: dict = Depends(current_user),
):
    return dash.dashboard(conn, *_period(date_from, date_to, provider))


# ---- events -------------------------------------------------------------------------------------------------
EVENT_COLS = (
    "id, external_event_id, provider, service, environment, severity, event_type, event_timestamp, "
    "message, correlation_id, metadata_json, is_synthetic"
)


@router.post(
    "/events",
    tags=["events"],
    status_code=201,
    summary='Ingest one event or {"events": [...]} (deduplicated by provider + event_id)',
)
def ingest_events(
    request: Request,
    payload: Any = Body(...),
    conn: Connection = Depends(get_conn),
    principal: dict = Depends(ingest_principal),
):
    _throttle(_event_limit, request, principal)
    items = payload.get("events") if isinstance(payload, dict) and "events" in payload else payload
    items = items if isinstance(items, list) else [items]
    try:
        result = ing.ingest_events(conn, items)
    except ValueError as e:
        raise ApiError(413, "too_many_events", str(e))
    audit(
        conn,
        request,
        principal,
        "events.ingest",
        "operational_event",
        None,
        {k: result[k] for k in ("created", "duplicates", "rejected")},
    )
    conn.commit()
    if result["created"] == 0 and result["rejected"] == len(items) and items:
        raise ApiError(422, "validation_error", "No events were accepted.", result["results"])
    return result


@router.get("/events", tags=["events"], summary="Search and filter operational events")
def list_events(
    lst: Listing = Depends(event_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(conn, EVENT_COLS, "operational_events", lst)


@router.get("/events/{event_id}", tags=["events"], summary="Event detail")
def get_event(event_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    row = (
        conn.execute(text(f"SELECT {EVENT_COLS} FROM operational_events WHERE id = :id"), {"id": event_id})
        .mappings()
        .first()
    )
    if not row:
        raise ApiError(404, "not_found", "Event not found.")
    return dict(row)
