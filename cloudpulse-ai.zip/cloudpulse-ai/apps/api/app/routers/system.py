from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.engine import Connection

from ..adapters import get_adapters
from ..core import metrics
from ..core.errors import ApiError
from ..db import get_conn, get_settings
from ..deps import audit, current_user, require_admin
from ..services import ingest as ing

router = APIRouter()


@router.get("/health", tags=["health"], summary="Liveness: the process is up")
def health():
    return {"status": "ok"}


@router.get("/ready", tags=["health"], summary="Readiness: database reachable and migrated")
def ready(conn: Connection = Depends(get_conn)):
    try:
        conn.execute(text("SELECT 1")).scalar_one()
        migrated = conn.execute(text("SELECT to_regclass('public.cost_records') IS NOT NULL")).scalar_one()
    except Exception:
        metrics.DB_UP.set(0)
        raise ApiError(503, "not_ready", "Database is not reachable.")
    metrics.DB_UP.set(1)
    if not migrated:
        raise ApiError(503, "not_ready", "Database schema is not migrated. Run `make migrate`.")
    return {"status": "ready", "database": "ok"}


@router.get("/metrics", tags=["health"], include_in_schema=False)
def prometheus_metrics():
    if not get_settings().metrics_enabled:
        raise ApiError(404, "not_found", "Not found.")
    return Response(metrics.render(), media_type="text/plain; version=0.0.4")


# ---- integrations -------------------------------------------------------------------------------------------
class IntegrationUpdate(BaseModel):
    enabled: bool


class SyncRequest(BaseModel):
    date_from: str | None = None  # YYYY-MM-DD, inclusive; default: 30 days before date_to
    date_to: str | None = None  # YYYY-MM-DD, inclusive; default: yesterday (UTC)


def _row(conn: Connection, provider: str):
    return (
        conn.execute(text("SELECT * FROM cloud_integrations WHERE provider = :p"), {"p": provider}).mappings().first()
    )


@router.get("/integrations", tags=["integrations"], summary="Providers, status and missing configuration")
def list_integrations(conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    adapters = get_adapters(get_settings())
    out = []
    for provider, adapter in adapters.items():
        st, row = adapter.status(), _row(conn, provider)
        out.append(
            {
                **asdict(st),
                "enabled": row["enabled"],
                "status": row["status"],
                "last_tested_at": row["last_tested_at"],
                "last_sync_at": row["last_sync_at"],
                "last_sync_status": row["last_sync_status"],
            }
        )
    return {"items": out, "default_mode": get_settings().default_data_mode}


@router.put("/integrations/{provider}", tags=["integrations"], summary="Enable or disable a provider")
def update_integration(
    provider: str,
    body: IntegrationUpdate,
    request: Request,
    conn: Connection = Depends(get_conn),
    admin: dict = Depends(require_admin),
):
    adapters = get_adapters(get_settings())
    if provider not in adapters:
        raise ApiError(404, "not_found", "Unknown provider.")
    if provider == "demo" and not body.enabled:
        raise ApiError(409, "conflict", "Demo mode cannot be disabled.")
    st = adapters[provider].status()
    if body.enabled and not st.configured:
        raise ApiError(
            409,
            "not_configured",
            "Provider is missing server-side configuration.",
            {"missing_config": st.missing_config},
        )
    conn.execute(
        text(
            "UPDATE cloud_integrations SET enabled = :e, status = CASE WHEN :e THEN 'configured' "
            "ELSE 'not_configured' END, updated_at = now(), updated_by = :u WHERE provider = :p"
        ),
        {"e": body.enabled, "u": admin["id"], "p": provider},
    )
    audit(conn, request, admin, "integration.update", "integration", provider, {"enabled": body.enabled})
    conn.commit()
    return {"provider": provider, "enabled": body.enabled}


@router.post("/integrations/{provider}/test", tags=["integrations"], summary="Run a read-only connection test")
def test_integration(
    provider: str, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    adapters = get_adapters(get_settings())
    if provider not in adapters:
        raise ApiError(404, "not_found", "Unknown provider.")
    result = adapters[provider].test_connection()
    status = "connected" if result.ok else ("not_configured" if result.details.get("missing") else "error")
    conn.execute(
        text("UPDATE cloud_integrations SET status = :s, last_tested_at = now() WHERE provider = :p"),
        {"s": status, "p": provider},
    )
    audit(conn, request, admin, "integration.test", "integration", provider, {"ok": result.ok})
    conn.commit()
    return {"provider": provider, "ok": result.ok, "message": result.message, "details": result.details}


@router.post(
    "/integrations/demo/load",
    tags=["integrations"],
    status_code=201,
    summary="Load the bundled SYNTHETIC demo dataset (idempotent)",
)
def load_demo(request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)):
    try:
        out = ing.load_demo_data(conn, get_settings().demo_data_dir, admin["id"])
    except FileNotFoundError:
        raise ApiError(404, "demo_data_missing", "Bundled demo data files were not found on the server.")
    audit(conn, request, admin, "demo.load", "integration", "demo", out["costs"])
    conn.commit()
    metrics.INGESTION_RUNS.labels("demo_load", out["costs"]["status"]).inc()
    return out


@router.post(
    "/integrations/{provider}/sync",
    tags=["integrations"],
    summary="Pull cost data from an ENABLED provider (read-only; idempotent)",
)
def sync_integration(
    provider: str,
    body: SyncRequest,
    request: Request,
    conn: Connection = Depends(get_conn),
    admin: dict = Depends(require_admin),
):
    from datetime import UTC, datetime, timedelta

    from ..core import queryutil as qu

    adapters = get_adapters(get_settings())
    if provider not in adapters or provider == "demo":
        raise ApiError(404, "not_found", "Unknown provider (use /integrations/demo/load for demo data).")
    row = _row(conn, provider)
    if not row["enabled"]:
        raise ApiError(409, "not_enabled", "Enable the provider before syncing.")
    end_incl = qu.parse_date("date_to", body.date_to) or (datetime.now(UTC).date() - timedelta(days=1))
    start = qu.parse_date("date_from", body.date_from) or (end_incl - timedelta(days=29))
    qu.check_range(start, end_incl)
    if (end_incl - start).days > 366:
        raise ApiError(422, "validation_error", "Sync range may not exceed 366 days.")
    try:
        out = ing.sync_from_adapter(
            conn,
            adapters[provider],
            provider,
            start.isoformat(),
            (end_incl + timedelta(days=1)).isoformat(),
            admin["id"],
        )
    except ing.SyncError as e:
        raise ApiError(502, "provider_error", str(e)) from None
    audit(
        conn,
        request,
        admin,
        "integration.sync",
        "integration",
        provider,
        {k: out.get(k) for k in ("status", "rows_inserted")},
    )
    conn.commit()
    metrics.INGESTION_RUNS.labels(f"{provider}_sync", out["status"]).inc()
    return out
