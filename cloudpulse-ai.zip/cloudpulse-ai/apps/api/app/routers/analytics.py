from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Connection

from ..core import metrics
from ..core.errors import ApiError
from ..db import get_conn, get_settings
from ..deps import audit, current_user, require_admin
from ..listing import Listing, anomaly_listing, fetch_page, recommendation_listing
from ..services import detect as det
from ..services.llm import build_llm_client

log = logging.getLogger("cloudpulse.analytics")
router = APIRouter()


class DetectRequest(BaseModel):
    config: dict[str, Any] | None = Field(default=None, description="Overrides for DetectionConfig fields")
    date_from: str | None = None
    date_to: str | None = None


class ForecastRequest(BaseModel):
    horizon_days: int = Field(default=14, ge=1, le=90)


# ---- anomalies ----------------------------------------------------------------------------------------------
@router.post("/anomalies/run", tags=["anomalies"], summary="Run detection (deterministic; duplicates suppressed)")
def run_anomalies(
    body: DetectRequest, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    start = time.perf_counter()
    try:
        result = det.run_detection(
            conn,
            body.config,
            body.date_from,
            body.date_to,
            llm_client=build_llm_client(get_settings()),
            on_llm_error=lambda e: (
                metrics.LLM_FALLBACKS.inc(),
                log.warning("llm fallback", extra={"error": type(e).__name__}),
            ),
        )
    except ValueError as e:
        metrics.DETECTION_RUNS.labels("rejected").inc()
        raise ApiError(422, "validation_error", str(e))
    metrics.DETECTION_RUNS.labels(result["status"]).inc()
    metrics.DETECTION_SECONDS.observe(time.perf_counter() - start)
    for sev, count in result.get("by_severity", {}).items():
        metrics.ANOMALIES_DETECTED.labels(sev).inc(count)
    audit(
        conn,
        request,
        admin,
        "anomalies.run",
        "anomaly",
        None,
        {k: result.get(k) for k in ("detected", "new", "suppressed_duplicates")},
    )
    conn.commit()
    return result


@router.get("/anomalies", tags=["anomalies"], summary="List and filter anomalies")
def list_anomalies(
    lst: Listing = Depends(anomaly_listing), conn: Connection = Depends(get_conn), _: dict = Depends(current_user)
):
    return fetch_page(conn, "*", "anomalies", lst)


@router.get("/anomalies/{anomaly_id}", tags=["anomalies"], summary="Anomaly detail with its recommendation")
def get_anomaly(anomaly_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    row = conn.execute(text("SELECT * FROM anomalies WHERE id = :id"), {"id": anomaly_id}).mappings().first()
    if not row:
        raise ApiError(404, "not_found", "Anomaly not found.")
    out = dict(row)
    rec = (
        conn.execute(text("SELECT * FROM recommendations WHERE anomaly_id = :id"), {"id": anomaly_id})
        .mappings()
        .first()
    )
    alert = (
        conn.execute(text("SELECT id, status FROM alerts WHERE anomaly_id = :id"), {"id": anomaly_id})
        .mappings()
        .first()
    )
    out["recommendation"], out["alert"] = (dict(rec) if rec else None), (dict(alert) if alert else None)
    return out


# ---- forecasts ----------------------------------------------------------------------------------------------
@router.post(
    "/forecasts/run",
    tags=["forecasts"],
    status_code=201,
    summary="Generate a baseline forecast with backtest evaluation",
)
def run_forecasts(
    body: ForecastRequest, request: Request, conn: Connection = Depends(get_conn), admin: dict = Depends(require_admin)
):
    result = det.run_forecast_job(conn, body.horizon_days, admin["id"])
    audit(
        conn,
        request,
        admin,
        "forecast.run",
        "forecast_run",
        result["id"],
        {"status": result["status"], "horizon_days": body.horizon_days},
    )
    conn.commit()
    return result


@router.get("/forecasts/latest", tags=["forecasts"], summary="Most recent forecast run")
def latest_forecast(conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    row = conn.execute(text("SELECT * FROM forecast_runs ORDER BY created_at DESC, id DESC LIMIT 1")).mappings().first()
    if not row:
        return {"status": "none", "message": "No forecast has been generated yet."}
    out = dict(row)
    out.update(out.pop("results_json") or {})
    return out


@router.get("/forecasts", tags=["forecasts"], summary="Forecast run history")
def list_forecasts(conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    rows = (
        conn.execute(
            text(
                "SELECT id, horizon_days, method, status, data_points, mae, is_synthetic, created_at "
                "FROM forecast_runs ORDER BY created_at DESC, id DESC LIMIT 50"
            )
        )
        .mappings()
        .all()
    )
    return {"items": [dict(r) for r in rows]}


# ---- recommendations ----------------------------------------------------------------------------------------
_REC_FROM = "recommendations r JOIN anomalies a ON a.id = r.anomaly_id"
_REC_COLS = (
    "r.id, r.anomaly_id, r.provider, r.service_name, r.summary, r.evidence_json, r.potential_impact, "
    "r.confidence_note, r.next_steps_json, r.requires_human_review, r.source, r.ai_explanation_json, "
    "r.generated_at, a.severity, a.usage_date"
)


@router.get("/recommendations", tags=["recommendations"], summary="Recommendations (measured facts vs AI text)")
def list_recommendations(
    lst: Listing = Depends(recommendation_listing),
    conn: Connection = Depends(get_conn),
    _: dict = Depends(current_user),
):
    return fetch_page(conn, _REC_COLS, _REC_FROM, lst)


@router.get("/recommendations/{rec_id}", tags=["recommendations"], summary="Recommendation detail")
def get_recommendation(rec_id: int, conn: Connection = Depends(get_conn), _: dict = Depends(current_user)):
    row = conn.execute(text(f"SELECT {_REC_COLS} FROM {_REC_FROM} WHERE r.id = :id"), {"id": rec_id}).mappings().first()
    if not row:
        raise ApiError(404, "not_found", "Recommendation not found.")
    return dict(row)
