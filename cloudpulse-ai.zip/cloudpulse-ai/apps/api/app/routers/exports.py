from __future__ import annotations

import csv
import io
import json
from datetime import UTC, datetime

from cloudpulse_ingestion import csv_safe
from fastapi import APIRouter, Depends, Query, Request, Response
from sqlalchemy import text
from sqlalchemy.engine import Connection

from ..core import queryutil as qu
from ..core.errors import ApiError
from ..db import get_conn
from ..deps import audit, current_user
from ..listing import PROVIDERS, Listing, alert_listing, anomaly_listing, cost_listing, event_listing, fetch_all
from ..services import dashboard as dash

router = APIRouter(prefix="/exports", tags=["exports"])


def _csv_response(name: str, header: list[str], rows: list[list]) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    for r in rows:
        w.writerow([csv_safe(v) for v in r])  # neutralise spreadsheet formula injection
    stamp = datetime.now(UTC).strftime("%Y%m%d")
    return Response(
        buf.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{name}-{stamp}.csv"',
            "X-Content-Type-Options": "nosniff",
        },
    )


def _dump(rows: list[dict], cols: list[str]) -> list[list]:
    out = []
    for r in rows:
        out.append([json.dumps(r[c], default=str) if isinstance(r[c], (dict, list)) else r[c] for c in cols])
    return out


@router.get("/costs.csv", summary="Cost records (respects the same filters as GET /costs)")
def export_costs(
    request: Request,
    lst: Listing = Depends(cost_listing),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    cols = [
        "usage_date",
        "provider",
        "account_identifier",
        "service_name",
        "region",
        "usage_quantity",
        "usage_unit",
        "cost_amount",
        "currency",
        "source_type",
        "is_synthetic",
    ]
    rows = fetch_all(conn, ", ".join(cols) + ", id", "cost_records", lst)
    audit(conn, request, user, "export.costs", None, None, {"rows": len(rows)})
    conn.commit()
    return _csv_response("cloudpulse-costs", cols, _dump(rows, cols))


@router.get("/cost-summary.csv", summary="Cost totals by provider, service and region for a period")
def export_summary(
    request: Request,
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    s = dash.cost_summary(
        conn,
        qu.parse_date("date_from", date_from),
        qu.parse_date("date_to", date_to),
        qu.pick("provider", provider, PROVIDERS),
    )
    if not s.get("has_data"):
        return _csv_response("cloudpulse-cost-summary", ["dimension", "name", "cost", "currency", "data_origin"], [])
    rows = [
        ["total", "all", s["total_cost"], s["currency"], s["data_origin"]],
        ["previous_period_total", "all", s["previous_period_total"], s["currency"], s["data_origin"]],
    ]
    for dim, key in (("provider", "by_provider"), ("service", "by_service"), ("region", "by_region")):
        rows += [[dim, x["name"], x["cost"], s["currency"], s["data_origin"]] for x in s[key]]
    audit(conn, request, user, "export.cost_summary", None, None)
    conn.commit()
    return _csv_response("cloudpulse-cost-summary", ["dimension", "name", "cost", "currency", "data_origin"], rows)


@router.get("/anomalies.csv", summary="Anomalies (respects GET /anomalies filters)")
def export_anomalies(
    request: Request,
    lst: Listing = Depends(anomaly_listing),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    cols = [
        "usage_date",
        "provider",
        "service_name",
        "severity",
        "direction",
        "observed_value",
        "expected_value",
        "deviation",
        "pct_change",
        "score",
        "method",
        "is_synthetic",
        "explanation",
    ]
    rows = fetch_all(conn, ", ".join(cols) + ", id", "anomalies", lst)
    audit(conn, request, user, "export.anomalies", None, None, {"rows": len(rows)})
    conn.commit()
    return _csv_response("cloudpulse-anomalies", cols, _dump(rows, cols))


@router.get("/events.csv", summary="Operational events (respects GET /events filters)")
def export_events(
    request: Request,
    lst: Listing = Depends(event_listing),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    cols = [
        "event_timestamp",
        "external_event_id",
        "provider",
        "service",
        "environment",
        "severity",
        "event_type",
        "message",
        "correlation_id",
        "is_synthetic",
    ]
    rows = fetch_all(conn, ", ".join(cols) + ", id", "operational_events", lst)
    audit(conn, request, user, "export.events", None, None, {"rows": len(rows)})
    conn.commit()
    return _csv_response("cloudpulse-events", cols, _dump(rows, cols))


@router.get("/alerts.csv", summary="Alerts (respects GET /alerts filters)")
def export_alerts(
    request: Request,
    lst: Listing = Depends(alert_listing),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    cols = ["created_at", "title", "severity", "status", "provider", "service_name", "acknowledged_at", "resolved_at"]
    rows = fetch_all(conn, ", ".join(cols) + ", id", "alerts", lst)
    audit(conn, request, user, "export.alerts", None, None, {"rows": len(rows)})
    conn.commit()
    return _csv_response("cloudpulse-alerts", cols, _dump(rows, cols))


@router.get("/forecasts.csv", summary="History and forecast values of a forecast run (default: latest)")
def export_forecast(
    request: Request,
    run_id: int | None = Query(None),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    sql = "SELECT id, results_json, is_synthetic FROM forecast_runs " + (
        "WHERE id = :id" if run_id else "ORDER BY created_at DESC, id DESC LIMIT 1"
    )
    row = conn.execute(text(sql), {"id": run_id} if run_id else {}).mappings().first()
    if not row:
        raise ApiError(404, "not_found", "No forecast run found.")
    res = row["results_json"] if isinstance(row["results_json"], dict) else json.loads(row["results_json"])
    origin = "synthetic" if row["is_synthetic"] else "stored"
    rows = [["history", h["date"], h["value"], "", "", origin] for h in res.get("history", [])]
    rows += [
        ["forecast", f["date"], f["value"], f.get("lower"), f.get("upper"), origin] for f in res.get("forecast", [])
    ]
    audit(conn, request, user, "export.forecast", "forecast_run", row["id"])
    conn.commit()
    return _csv_response("cloudpulse-forecast", ["series", "date", "value", "lower", "upper", "data_origin"], rows)


_ORIGIN_TEXT = {
    "synthetic": "SYNTHETIC. Every figure in this report comes from fabricated demo data and does NOT represent a real cloud bill.",
    "provider": "PROVIDER-SOURCED. Figures were retrieved from the cloud provider's cost API by a configured integration.",
    "uploaded": "UPLOADED. Figures come from a user-supplied CSV that CloudPulse has not verified against a provider.",
    "mixed": "MIXED. This period combines more than one source type (see 'Source types' below); do not treat the total as a provider bill.",
    "none": "NO DATA.",
}


@router.get("/report.md", summary="Generated period report stating whether data is synthetic or provider-sourced")
def export_report(
    request: Request,
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    provider: str | None = Query(None),
    conn: Connection = Depends(get_conn),
    user: dict = Depends(current_user),
):
    d = dash.dashboard(
        conn,
        qu.parse_date("date_from", date_from),
        qu.parse_date("date_to", date_to),
        qu.pick("provider", provider, PROVIDERS),
    )
    s = d["summary"]
    lines = ["# CloudPulse AI cost report", "", f"Generated: {datetime.now(UTC).isoformat(timespec='seconds')}", ""]
    if not s.get("has_data"):
        lines.append("No cost data is loaded.")
    else:
        lines += [
            f"**Data origin: {_ORIGIN_TEXT[s['data_origin']]}**",
            "",
            f"- Period: {s['period']['from']} to {s['period']['to']} ({s['period']['days']} days)",
            f"- Source types: {', '.join(s['source_types'])}",
            f"- Total cost: {s['total_cost']:,.2f} {s['currency']}",
            f"- Previous equivalent period ({s['previous_period']['from']} to {s['previous_period']['to']}): "
            f"{s['previous_period_total']:,.2f} {s['currency']}",
        ]
        if s["change_percent"] is not None:
            lines.append(f"- Change: {s['change_amount']:+,.2f} ({s['change_percent']:+.1f}%)")
        lines += ["", "## Top services", ""] + [f"- {x['name']}: {x['cost']:,.2f}" for x in s["by_service"][:10]]
        lines += ["", "## Anomalies in period", f"- Total: {d['anomalies']['total']}"] + [
            f"- {k}: {v}" for k, v in sorted(d["anomalies"]["by_severity"].items())
        ]
        lines += ["", "## Alerts", f"- Unresolved: {d['unresolved_alerts']['total']}"]
        lines += ["", "_Anomaly detection and forecasts are statistical aids, not findings of fact._"]
    audit(conn, request, user, "export.report", None, None)
    conn.commit()
    return Response(
        "\n".join(lines) + "\n",
        media_type="text/markdown; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="cloudpulse-report.md"'},
    )
