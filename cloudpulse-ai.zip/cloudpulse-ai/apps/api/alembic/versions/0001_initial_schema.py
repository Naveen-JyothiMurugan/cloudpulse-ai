"""initial schema

Applies db/schema.sql, the single source of truth for the data model. The integration tests apply the very
same file to a real PostgreSQL, so the migration and the tests cannot drift apart.

Revision ID: 0001
Revises:
"""
from pathlib import Path

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

SCHEMA_SQL = Path(__file__).resolve().parents[2] / "db" / "schema.sql"

TABLES = [
    "audit_events", "investigation_notes", "incident_events", "incident_alerts", "incidents", "alert_events",
    "alerts", "recommendations", "forecast_runs", "anomalies", "operational_events", "cost_records",
    "ingestion_runs", "cloud_integrations", "users", "roles",
]


def upgrade() -> None:
    # exec_driver_sql: send the script as-is (multiple statements, no bind-parameter parsing)
    op.get_bind().exec_driver_sql(SCHEMA_SQL.read_text())


def downgrade() -> None:
    bind = op.get_bind()
    for table in TABLES:
        bind.exec_driver_sql(f"DROP TABLE IF EXISTS {table} CASCADE")
    bind.exec_driver_sql("DROP FUNCTION IF EXISTS audit_events_immutable() CASCADE")
    bind.exec_driver_sql("DROP FUNCTION IF EXISTS purge_old_events(integer)")
