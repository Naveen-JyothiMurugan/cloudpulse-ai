-- CloudPulse AI schema (PostgreSQL 14+). Single source of truth for migration 0001.
-- No secrets are stored here: cloud_integrations.config_json holds NON-secret settings only.

CREATE TABLE roles (
    id          SMALLSERIAL PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE CHECK (name IN ('admin', 'readonly'))
);
INSERT INTO roles (name) VALUES ('admin'), ('readonly');

CREATE TABLE users (
    id                  BIGSERIAL PRIMARY KEY,
    email               TEXT NOT NULL CHECK (position('@' IN email) > 1),
    password_hash       TEXT NOT NULL,                     -- argon2id hash only
    role_id             SMALLINT NOT NULL REFERENCES roles(id),
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    failed_login_count  INTEGER NOT NULL DEFAULT 0,
    locked_until        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at       TIMESTAMPTZ
);
CREATE UNIQUE INDEX uq_users_email_lower ON users (lower(email));

CREATE TABLE cloud_integrations (
    id               BIGSERIAL PRIMARY KEY,
    provider         TEXT NOT NULL UNIQUE CHECK (provider IN ('aws', 'azure', 'demo')),
    enabled          BOOLEAN NOT NULL DEFAULT FALSE,
    config_json      JSONB NOT NULL DEFAULT '{}'::jsonb,    -- non-secret only (region, role ARN, tenant id)
    status           TEXT NOT NULL DEFAULT 'not_configured'
                     CHECK (status IN ('not_configured', 'configured', 'connected', 'error')),
    last_tested_at   TIMESTAMPTZ,
    last_sync_at     TIMESTAMPTZ,
    last_sync_status TEXT,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by       BIGINT REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO cloud_integrations (provider, enabled, status) VALUES
    ('demo', TRUE, 'connected'), ('aws', FALSE, 'not_configured'), ('azure', FALSE, 'not_configured');

CREATE TABLE ingestion_runs (
    id              BIGSERIAL PRIMARY KEY,
    source_type     TEXT NOT NULL,
    filename        TEXT,
    file_sha256     CHAR(64),
    status          TEXT NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running', 'succeeded', 'partial', 'failed')),
    rows_total      INTEGER NOT NULL DEFAULT 0 CHECK (rows_total >= 0),
    rows_inserted   INTEGER NOT NULL DEFAULT 0 CHECK (rows_inserted >= 0),
    rows_duplicate  INTEGER NOT NULL DEFAULT 0 CHECK (rows_duplicate >= 0),
    rows_rejected   INTEGER NOT NULL DEFAULT 0 CHECK (rows_rejected >= 0),
    error_summary   TEXT,
    errors_json     JSONB NOT NULL DEFAULT '[]'::jsonb,
    user_id         BIGINT REFERENCES users(id) ON DELETE SET NULL,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ
);
CREATE INDEX ix_ingestion_runs_started ON ingestion_runs (started_at DESC);
CREATE INDEX ix_ingestion_runs_status ON ingestion_runs (status);

CREATE TABLE cost_records (
    id                BIGSERIAL PRIMARY KEY,
    usage_date        DATE NOT NULL,
    provider          TEXT NOT NULL CHECK (provider IN ('aws', 'azure', 'other')),
    account_identifier TEXT NOT NULL,
    service_name      TEXT NOT NULL,
    region            TEXT NOT NULL,
    usage_quantity    NUMERIC(20, 6) NOT NULL CHECK (usage_quantity >= 0),
    usage_unit        TEXT NOT NULL,
    cost_amount       NUMERIC(18, 4) NOT NULL,              -- negative values allowed (credits/refunds)
    currency          CHAR(3) NOT NULL CHECK (currency = upper(currency)),
    source_type       TEXT NOT NULL
                      CHECK (source_type IN ('synthetic', 'aws_cost_explorer', 'azure_cost_management', 'manual_csv')),
    is_synthetic      BOOLEAN NOT NULL,
    row_hash          CHAR(64) NOT NULL UNIQUE,              -- natural-key hash => idempotent re-upload
    ingestion_run_id  BIGINT REFERENCES ingestion_runs(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (is_synthetic = (source_type = 'synthetic'))
);
CREATE INDEX ix_cost_date ON cost_records (usage_date);
CREATE INDEX ix_cost_provider_service_date ON cost_records (provider, service_name, usage_date);
CREATE INDEX ix_cost_region_date ON cost_records (region, usage_date);
CREATE INDEX ix_cost_run ON cost_records (ingestion_run_id);

CREATE TABLE operational_events (
    id                BIGSERIAL PRIMARY KEY,
    external_event_id TEXT NOT NULL,
    provider          TEXT NOT NULL CHECK (provider IN ('aws', 'azure', 'other')),
    service           TEXT NOT NULL,
    environment       TEXT NOT NULL,
    severity          TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'error', 'critical')),
    event_type        TEXT NOT NULL,
    event_timestamp   TIMESTAMPTZ NOT NULL,
    message           TEXT NOT NULL,
    correlation_id    TEXT,
    metadata_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_synthetic      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    search_vector     TSVECTOR GENERATED ALWAYS AS (
                        to_tsvector('simple', coalesce(message, '') || ' ' || coalesce(service, '') || ' ' ||
                                              coalesce(event_type, ''))) STORED,
    CONSTRAINT uq_event_provider_extid UNIQUE (provider, external_event_id)
);
CREATE INDEX ix_events_ts ON operational_events (event_timestamp DESC);
CREATE INDEX ix_events_sev_ts ON operational_events (severity, event_timestamp DESC);
CREATE INDEX ix_events_corr ON operational_events (correlation_id) WHERE correlation_id IS NOT NULL;
CREATE INDEX ix_events_search ON operational_events USING GIN (search_vector);

CREATE TABLE anomalies (
    id              BIGSERIAL PRIMARY KEY,
    provider        TEXT NOT NULL,
    service_name    TEXT NOT NULL,
    region          TEXT,
    usage_date      DATE NOT NULL,
    observed_value  NUMERIC(18, 4) NOT NULL,
    expected_value  NUMERIC(18, 4) NOT NULL,
    deviation       NUMERIC(18, 4) NOT NULL,
    pct_change      NUMERIC(12, 4),
    score           DOUBLE PRECISION NOT NULL,
    severity        TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    method          TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('increase', 'decrease')),
    signals_json    JSONB NOT NULL DEFAULT '{}'::jsonb,
    explanation     TEXT NOT NULL,
    config_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_synthetic    BOOLEAN NOT NULL DEFAULT FALSE,
    fingerprint     CHAR(32) NOT NULL UNIQUE,               -- suppresses duplicates across re-runs
    detected_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_anom_date ON anomalies (usage_date DESC);
CREATE INDEX ix_anom_sev ON anomalies (severity, detected_at DESC);
CREATE INDEX ix_anom_provider_service ON anomalies (provider, service_name);

CREATE TABLE forecast_runs (
    id              BIGSERIAL PRIMARY KEY,
    horizon_days    INTEGER NOT NULL CHECK (horizon_days BETWEEN 1 AND 90),
    method          TEXT NOT NULL,
    status          TEXT NOT NULL CHECK (status IN ('ok', 'insufficient_data')),
    data_points     INTEGER NOT NULL DEFAULT 0,
    mae             NUMERIC(18, 4),
    params_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    results_json    JSONB NOT NULL DEFAULT '{}'::jsonb,
    warnings_json   JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_synthetic    BOOLEAN NOT NULL DEFAULT FALSE,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_forecast_created ON forecast_runs (created_at DESC);

CREATE TABLE recommendations (
    id                   BIGSERIAL PRIMARY KEY,
    anomaly_id           BIGINT NOT NULL UNIQUE REFERENCES anomalies(id) ON DELETE CASCADE,
    provider             TEXT NOT NULL,
    service_name         TEXT NOT NULL,
    summary              TEXT NOT NULL,
    evidence_json        JSONB NOT NULL,
    potential_impact     TEXT NOT NULL,
    confidence_note      TEXT NOT NULL,
    next_steps_json      JSONB NOT NULL,
    requires_human_review BOOLEAN NOT NULL DEFAULT TRUE,
    source               TEXT NOT NULL CHECK (source IN ('rules', 'rules+llm')),
    ai_explanation_json  JSONB,
    generated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_reco_provider_service ON recommendations (provider, service_name);

CREATE TABLE alerts (
    id              BIGSERIAL PRIMARY KEY,
    anomaly_id      BIGINT UNIQUE REFERENCES anomalies(id) ON DELETE SET NULL,
    fingerprint     CHAR(32) NOT NULL UNIQUE,                -- same fingerprint => same alert, never duplicated
    title           TEXT NOT NULL,
    severity        TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'acknowledged', 'resolved')),
    provider        TEXT NOT NULL,
    service_name    TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    resolved_at     TIMESTAMPTZ,
    resolved_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    CHECK ((status = 'resolved') = (resolved_at IS NOT NULL))
);
CREATE INDEX ix_alerts_status_sev ON alerts (status, severity);
CREATE INDEX ix_alerts_created ON alerts (created_at DESC);

CREATE TABLE alert_events (
    alert_id BIGINT NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    event_id BIGINT NOT NULL REFERENCES operational_events(id) ON DELETE CASCADE,
    PRIMARY KEY (alert_id, event_id)
);

CREATE TABLE incidents (
    id          BIGSERIAL PRIMARY KEY,
    title       TEXT NOT NULL,
    summary     TEXT,
    status      TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'closed')),
    severity    TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    owner_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_by  BIGINT REFERENCES users(id) ON DELETE SET NULL,
    opened_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at   TIMESTAMPTZ,
    CHECK ((status IN ('resolved', 'closed')) = (closed_at IS NOT NULL))
);
CREATE INDEX ix_incidents_status ON incidents (status, opened_at DESC);

CREATE TABLE incident_alerts (
    incident_id BIGINT NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    alert_id    BIGINT NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    PRIMARY KEY (incident_id, alert_id)
);
CREATE TABLE incident_events (
    incident_id BIGINT NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    event_id    BIGINT NOT NULL REFERENCES operational_events(id) ON DELETE CASCADE,
    PRIMARY KEY (incident_id, event_id)
);

CREATE TABLE investigation_notes (
    id          BIGSERIAL PRIMARY KEY,
    alert_id    BIGINT REFERENCES alerts(id) ON DELETE CASCADE,
    incident_id BIGINT REFERENCES incidents(id) ON DELETE CASCADE,
    author_id   BIGINT REFERENCES users(id) ON DELETE SET NULL,
    body        TEXT NOT NULL CHECK (length(body) BETWEEN 1 AND 4000),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (alert_id IS NOT NULL OR incident_id IS NOT NULL)
);
CREATE INDEX ix_notes_alert ON investigation_notes (alert_id, created_at);
CREATE INDEX ix_notes_incident ON investigation_notes (incident_id, created_at);

CREATE TABLE audit_events (
    id          BIGSERIAL PRIMARY KEY,
    actor_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    actor_email TEXT,
    action      TEXT NOT NULL,
    entity_type TEXT,
    entity_id   TEXT,
    ip_address  TEXT,
    request_id  TEXT,
    details_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_audit_created ON audit_events (created_at DESC);
CREATE INDEX ix_audit_actor ON audit_events (actor_id, created_at DESC);

-- Audit rows are append-only: block UPDATE and DELETE at the database level.
CREATE FUNCTION audit_events_immutable() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'audit_events is append-only';
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE OR DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION audit_events_immutable();

-- Retention helper: operational events older than N days (default policy 90) can be purged on a schedule.
CREATE FUNCTION purge_old_events(retain_days INTEGER) RETURNS BIGINT AS $$
DECLARE n BIGINT;
BEGIN
    IF retain_days < 1 THEN RAISE EXCEPTION 'retain_days must be >= 1'; END IF;
    DELETE FROM operational_events WHERE event_timestamp < now() - make_interval(days => retain_days);
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql;
