"""Deterministic, explainable cost anomaly detection.

Two detectors are provided:

* ``robust_zscore`` (default): compares each day with the median and MAD of the
  trailing window. Fully deterministic and easy to explain.
* ``isolation_forest`` (optional): scikit-learn IsolationForest over a few
  engineered features, always with a fixed ``random_state``.

Detection never uses unseeded randomness: the same input data and the same
configuration always yield the same anomalies and the same fingerprints.
"""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np
import pandas as pd

MAD_TO_SIGMA = 1.4826  # makes MAD comparable to a standard deviation for normal data
SEVERITIES = ("low", "medium", "high", "critical")


@dataclass(frozen=True)
class DetectionConfig:
    method: str = "robust_zscore"  # or "isolation_forest"
    window_days: int = 14  # trailing window used as the baseline
    min_history_days: int = 7  # fewer prior points than this -> no verdict
    z_threshold: float = 3.5  # |robust z| needed to flag a point
    min_abs_change: float = 5.0  # ignore deviations smaller than this (currency units)
    min_pct_change: float = 20.0  # ignore deviations smaller than this percent of baseline
    flat_series_floor_pct: float = 5.0  # scale floor as % of median for flat series
    contamination: float = 0.03  # isolation forest only
    random_state: int = 42  # isolation forest only
    flag_decreases: bool = False  # cost drops are only flagged when True

    def validate(self) -> None:
        if self.method not in ("robust_zscore", "isolation_forest"):
            raise ValueError(f"unknown method: {self.method}")
        if self.window_days < 3:
            raise ValueError("window_days must be >= 3")
        if self.min_history_days < 3 or self.min_history_days > self.window_days:
            raise ValueError("min_history_days must be between 3 and window_days")
        if self.z_threshold <= 0:
            raise ValueError("z_threshold must be positive")
        if not 0 < self.contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")


@dataclass
class Anomaly:
    provider: str
    service_name: str
    region: str | None
    usage_date: str  # ISO date
    observed_value: float
    expected_value: float
    deviation: float  # observed - expected
    pct_change: float | None
    score: float
    severity: str
    method: str
    direction: str  # "increase" or "decrease"
    signals: dict[str, Any] = field(default_factory=dict)
    explanation: str = ""
    fingerprint: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def make_fingerprint(provider: str, service: str, region: str | None, usage_date: str, method: str) -> str:
    """Stable identity of an anomaly; used to suppress duplicate alerts on re-runs."""
    raw = "|".join([provider, service, region or "*", usage_date, method])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def classify_severity(score: float, deviation: float, pct_change: float | None, cfg: DetectionConfig) -> str:
    """Severity combines statistical distance and the size of the money involved."""
    impact = abs(deviation)
    pct = abs(pct_change) if pct_change is not None else 0.0
    if score >= cfg.z_threshold * 3 and (impact >= 500 or pct >= 300):
        return "critical"
    if score >= cfg.z_threshold * 2 and (impact >= 100 or pct >= 100):
        return "high"
    if score >= cfg.z_threshold * 1.25 or impact >= 100:
        return "medium"
    return "low"


def _daily_series(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    work = df.copy()
    work["usage_date"] = pd.to_datetime(work["usage_date"]).dt.normalize()
    work["cost_amount"] = pd.to_numeric(work["cost_amount"], errors="raise")
    daily = work.groupby(group_cols + ["usage_date"], as_index=False, sort=True)["cost_amount"].sum()
    return daily.sort_values(group_cols + ["usage_date"]).reset_index(drop=True)


def _explain(a: Anomaly, cfg: DetectionConfig) -> str:
    pct = f"{a.pct_change:+.1f}%" if a.pct_change is not None else "n/a"
    return (
        f"{a.provider.upper()} {a.service_name} cost on {a.usage_date} was {a.observed_value:,.2f} "
        f"versus an expected {a.expected_value:,.2f} ({pct}). Method {a.method}: "
        f"score {a.score:.2f} against threshold {cfg.z_threshold:g}, "
        f"baseline window {cfg.window_days} days."
    )


def _detect_robust(series: pd.DataFrame, provider: str, service: str, cfg: DetectionConfig) -> list[Anomaly]:
    values = series["cost_amount"].to_numpy(dtype=float)
    dates = series["usage_date"].dt.strftime("%Y-%m-%d").tolist()
    found: list[Anomaly] = []
    for i in range(len(values)):
        start = max(0, i - cfg.window_days)
        hist = values[start:i]
        if len(hist) < cfg.min_history_days:
            continue
        med = float(np.median(hist))
        mad = float(np.median(np.abs(hist - med)))
        scale = max(MAD_TO_SIGMA * mad, abs(med) * cfg.flat_series_floor_pct / 100.0, 1e-9)
        deviation = float(values[i] - med)
        z = deviation / scale
        pct = (deviation / med * 100.0) if med else None
        direction = "increase" if deviation > 0 else "decrease"
        if direction == "decrease" and not cfg.flag_decreases:
            continue
        if abs(z) < cfg.z_threshold:
            continue
        if abs(deviation) < cfg.min_abs_change:
            continue
        if pct is not None and abs(pct) < cfg.min_pct_change:
            continue
        a = Anomaly(
            provider=provider,
            service_name=service,
            region=None,
            usage_date=dates[i],
            observed_value=round(float(values[i]), 2),
            expected_value=round(med, 2),
            deviation=round(deviation, 2),
            pct_change=round(pct, 2) if pct is not None else None,
            score=round(abs(z), 3),
            severity="low",
            method="robust_zscore",
            direction=direction,
            signals={
                "baseline_median": round(med, 4),
                "baseline_mad": round(mad, 4),
                "scale_used": round(scale, 4),
                "robust_z": round(z, 3),
                "window_points": int(len(hist)),
                "z_threshold": cfg.z_threshold,
            },
        )
        a.severity = classify_severity(a.score, a.deviation, a.pct_change, cfg)
        a.fingerprint = make_fingerprint(provider, service, None, a.usage_date, a.method)
        a.explanation = _explain(a, cfg)
        found.append(a)
    return found


def _detect_iforest(series: pd.DataFrame, provider: str, service: str, cfg: DetectionConfig) -> list[Anomaly]:
    from sklearn.ensemble import IsolationForest

    v = series["cost_amount"].astype(float)
    if len(v) < max(cfg.min_history_days * 2, 14):
        return []
    roll_med = v.shift(1).rolling(cfg.window_days, min_periods=cfg.min_history_days).median()
    feats = pd.DataFrame(
        {
            "log_cost": np.log1p(v.clip(lower=0)),
            "rel_dev": ((v - roll_med) / roll_med.replace(0, np.nan)).fillna(0.0),
            "dow": pd.to_datetime(series["usage_date"]).dt.dayofweek.astype(float),
        }
    )
    model = IsolationForest(n_estimators=200, contamination=cfg.contamination, random_state=cfg.random_state)
    model.fit(feats)
    raw = -model.score_samples(feats)  # higher = more anomalous
    flags = model.predict(feats) == -1
    dates = series["usage_date"].dt.strftime("%Y-%m-%d").tolist()
    found: list[Anomaly] = []
    for i in np.where(flags)[0]:
        med = roll_med.iloc[i]
        if pd.isna(med):
            continue
        deviation = float(v.iloc[i] - med)
        pct = deviation / med * 100.0 if med else None
        direction = "increase" if deviation > 0 else "decrease"
        if direction == "decrease" and not cfg.flag_decreases:
            continue
        if abs(deviation) < cfg.min_abs_change or (pct is not None and abs(pct) < cfg.min_pct_change):
            continue
        # map the iforest score (~0.5 normal, ->1 anomalous) onto the same scale as z thresholds
        score = float(raw[i]) * cfg.z_threshold * 2
        a = Anomaly(
            provider=provider,
            service_name=service,
            region=None,
            usage_date=dates[i],
            observed_value=round(float(v.iloc[i]), 2),
            expected_value=round(float(med), 2),
            deviation=round(deviation, 2),
            pct_change=round(pct, 2) if pct is not None else None,
            score=round(score, 3),
            severity="low",
            method="isolation_forest",
            direction=direction,
            signals={
                "isolation_score": round(float(raw[i]), 4),
                "contamination": cfg.contamination,
                "random_state": cfg.random_state,
                "features": ["log_cost", "rel_dev", "dow"],
            },
        )
        a.severity = classify_severity(a.score, a.deviation, a.pct_change, cfg)
        a.fingerprint = make_fingerprint(provider, service, None, a.usage_date, a.method)
        a.explanation = _explain(a, cfg)
        found.append(a)
    return found


def detect_anomalies(cost_df: pd.DataFrame, cfg: DetectionConfig | None = None) -> list[Anomaly]:
    """Detect anomalies per (provider, service) daily cost series.

    ``cost_df`` needs columns: usage_date, provider, service_name, cost_amount.
    Results are sorted by (usage_date, provider, service_name) so output is stable.
    """
    cfg = cfg or DetectionConfig()
    cfg.validate()
    required = {"usage_date", "provider", "service_name", "cost_amount"}
    missing = required - set(cost_df.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    if cost_df.empty:
        return []
    daily = _daily_series(cost_df, ["provider", "service_name"])
    results: list[Anomaly] = []
    for (provider, service), grp in daily.groupby(["provider", "service_name"], sort=True):
        grp = grp.reset_index(drop=True)
        fn = _detect_robust if cfg.method == "robust_zscore" else _detect_iforest
        results.extend(fn(grp, provider, service, cfg))
    results.sort(key=lambda a: (a.usage_date, a.provider, a.service_name))
    return results
