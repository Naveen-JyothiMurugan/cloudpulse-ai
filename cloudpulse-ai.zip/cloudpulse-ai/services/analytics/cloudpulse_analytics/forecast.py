"""Baseline cost forecasting with honest, reproducible backtesting.

Method: **seasonal naive with a level adjustment**.
For each future day the forecast is the mean of the same weekday over the last
``seasons`` weeks, falling back to a trailing moving average when weekly
seasonality cannot be estimated. A simple 80% prediction band is derived from
the empirical absolute errors of the backtest (no distributional assumptions).

No accuracy is promised: MAE and the naive-benchmark comparison come from a
rolling-origin backtest on the data actually supplied.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd

MIN_POINTS = 28  # four full weeks of daily history
MIN_BACKTEST_POINTS = 42  # enough history to backtest at least one 14-day origin


@dataclass(frozen=True)
class ForecastConfig:
    horizon_days: int = 14
    seasons: int = 4  # number of weeks averaged per weekday
    backtest_origins: int = 3  # rolling origins used for evaluation
    method: str = "seasonal_naive_mean"

    def validate(self) -> None:
        if not 1 <= self.horizon_days <= 90:
            raise ValueError("horizon_days must be between 1 and 90")
        if self.seasons < 1:
            raise ValueError("seasons must be >= 1")
        if self.backtest_origins < 1:
            raise ValueError("backtest_origins must be >= 1")


def _complete_daily(df: pd.DataFrame) -> pd.Series:
    work = df.copy()
    work["usage_date"] = pd.to_datetime(work["usage_date"]).dt.normalize()
    s = work.groupby("usage_date")["cost_amount"].sum().astype(float).sort_index()
    full = pd.date_range(s.index.min(), s.index.max(), freq="D")
    return s.reindex(full).fillna(0.0)


def _predict(history: pd.Series, horizon: int, seasons: int) -> pd.Series:
    last = history.index.max()
    idx = pd.date_range(last + pd.Timedelta(days=1), periods=horizon, freq="D")
    values = []
    for d in idx:
        same = [history.get(d - pd.Timedelta(weeks=k)) for k in range(1, seasons + 1)]
        same = [x for x in same if x is not None and not np.isnan(x)]
        if same:
            values.append(float(np.mean(same)))
        else:
            values.append(float(history.tail(7).mean()))
    return pd.Series(values, index=idx)


def _mae(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.mean(np.abs(a - b)))


def run_forecast(cost_df: pd.DataFrame, cfg: ForecastConfig | None = None) -> dict[str, Any]:
    """Return a JSON-serialisable forecast result with warnings and evaluation."""
    cfg = cfg or ForecastConfig()
    cfg.validate()
    warnings: list[str] = []
    if cost_df.empty:
        return {
            "status": "insufficient_data",
            "warnings": ["No cost records available."],
            "history": [],
            "forecast": [],
            "evaluation": None,
            "config": asdict(cfg),
        }

    series = _complete_daily(cost_df)
    n = len(series)
    history = [{"date": d.strftime("%Y-%m-%d"), "value": round(float(v), 2)} for d, v in series.items()]

    if n < MIN_POINTS:
        warnings.append(f"Only {n} days of history; at least {MIN_POINTS} are required. No forecast was produced.")
        return {
            "status": "insufficient_data",
            "warnings": warnings,
            "history": history,
            "forecast": [],
            "evaluation": None,
            "config": asdict(cfg),
            "data_points": n,
        }

    evaluation = None
    band = 0.0
    if n >= MIN_BACKTEST_POINTS:
        errors_model: list[float] = []
        errors_naive: list[float] = []
        abs_errs: list[float] = []
        h = cfg.horizon_days
        origins = [n - h - k * h for k in range(cfg.backtest_origins)]
        used = 0
        for cut in origins:
            if cut < MIN_POINTS:
                continue
            train, test = series.iloc[:cut], series.iloc[cut : cut + h]
            if len(test) < h:
                continue
            pred = _predict(train, h, cfg.seasons)
            errors_model.append(_mae(test.to_numpy(), pred.to_numpy()))
            naive = np.repeat(train.iloc[-1], h)  # carry the last value forward
            errors_naive.append(_mae(test.to_numpy(), naive))
            abs_errs.extend(np.abs(test.to_numpy() - pred.to_numpy()).tolist())
            used += 1
        if used:
            mae = float(np.mean(errors_model))
            mae_naive = float(np.mean(errors_naive))
            mean_level = float(series.tail(28).mean())
            evaluation = {
                "metric": "MAE",
                "mae": round(mae, 2),
                "naive_last_value_mae": round(mae_naive, 2),
                "relative_to_mean_level_pct": round(mae / mean_level * 100, 2) if mean_level else None,
                "beats_naive_benchmark": bool(mae < mae_naive),
                "origins_used": used,
                "horizon_days": h,
                "note": "Computed on the supplied dataset only; not a guarantee of future accuracy.",
            }
            band = float(np.quantile(abs_errs, 0.8))
            if mae >= mae_naive:
                warnings.append("Seasonal baseline did not beat the naive last-value benchmark on this data.")
        else:
            warnings.append("Backtest could not run: not enough history for the requested horizon.")
    else:
        warnings.append(f"{n} days of history is below {MIN_BACKTEST_POINTS}; forecast produced but not backtested.")

    pred = _predict(series, cfg.horizon_days, cfg.seasons)
    cv = float(series.tail(28).std() / series.tail(28).mean()) if series.tail(28).mean() else 0.0
    if cv > 0.5:
        warnings.append(
            f"Recent spend is volatile (coefficient of variation {cv:.2f}); treat the forecast with caution."
        )

    forecast = [
        {
            "date": d.strftime("%Y-%m-%d"),
            "value": round(float(v), 2),
            "lower": round(max(0.0, float(v) - band), 2) if band else None,
            "upper": round(float(v) + band, 2) if band else None,
        }
        for d, v in pred.items()
    ]
    return {
        "status": "ok",
        "warnings": warnings,
        "history": history,
        "forecast": forecast,
        "evaluation": evaluation,
        "config": asdict(cfg),
        "data_points": n,
        "forecast_total": round(float(pred.sum()), 2),
    }
