"""AWS Lambda: S3 ObjectCreated (cost CSV) and EventBridge (operational events) -> CloudPulse API.

Least-privilege IAM for this function: s3:GetObject on the raw-data bucket prefix, logs:*, and (if used)
secretsmanager:GetSecretValue on ONE secret. See infra/terraform/modules/ingestion. UNTESTED against real AWS.
"""

from __future__ import annotations

import logging
import os
import urllib.parse

import forwarder  # packaged alongside this file by scripts/package_serverless.sh

log = logging.getLogger()
log.setLevel(os.environ.get("LOG_LEVEL", "INFO"))


def _s3():
    import boto3  # provided by the Lambda runtime

    return boto3.client("s3")


def _load_token_from_secret() -> None:
    """Keep the ingest token out of Lambda environment variables: fetch it once from Secrets Manager."""
    arn = os.environ.get("INGEST_TOKEN_SECRET_ARN")
    if arn and not os.environ.get("INGEST_API_TOKEN"):
        import boto3  # provided by the Lambda runtime

        os.environ["INGEST_API_TOKEN"] = (
            boto3.client("secretsmanager").get_secret_value(SecretId=arn)["SecretString"].strip()
        )


def handler(event, context=None, s3=None, sender=None):
    _load_token_from_secret()
    if isinstance(event, dict) and "Records" in event:
        client = s3 or _s3()
        results = []
        for rec in event["Records"]:
            if rec.get("eventSource") != "aws:s3":
                continue
            bucket = rec["s3"]["bucket"]["name"]
            key = urllib.parse.unquote_plus(rec["s3"]["object"]["key"])
            size = rec["s3"]["object"].get("size")
            if size is not None and size > forwarder.MAX_CSV_BYTES:
                raise forwarder.ForwardError(f"s3://{bucket}/{key} exceeds size limit")
            body = client.get_object(Bucket=bucket, Key=key)["Body"].read(forwarder.MAX_CSV_BYTES + 1)
            out = forwarder.forward_csv(key, body, sender)
            log.info(
                "ingested s3 object",
                extra={"key": key, "status": out.get("status"), "inserted": out.get("rows_inserted")},
            )
            results.append({"key": key, "status": out.get("status"), "run_id": out.get("run_id")})
        return {"processed": results}
    if isinstance(event, dict) and "detail-type" in event:
        out = forwarder.forward_events([forwarder.eventbridge_to_event(event)], sender)
        return {"created": out.get("created"), "duplicates": out.get("duplicates")}
    raise forwarder.ForwardError("unsupported event shape")
