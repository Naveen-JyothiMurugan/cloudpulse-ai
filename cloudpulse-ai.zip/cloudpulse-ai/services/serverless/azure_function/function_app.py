"""Azure Functions (Python v2 model): Blob trigger (cost CSV) -> CloudPulse API.

Uses the Function App's managed identity to read the blob (no storage keys). Configure CLOUDPULSE_API_URL and
INGEST_API_TOKEN (Key Vault reference) as app settings. UNTESTED against real Azure.
"""

import logging

import azure.functions as func  # type: ignore[import-not-found]
import forwarder  # packaged alongside this file by scripts/package_serverless.sh

app = func.FunctionApp()


@app.blob_trigger(arg_name="blob", path="cost-exports/{name}", connection="RAW_DATA_STORAGE")
def ingest_cost_csv(blob: func.InputStream) -> None:
    name = blob.name.split("/", 1)[-1]
    data = blob.read(forwarder.MAX_CSV_BYTES + 1)
    out = forwarder.forward_csv(name, data)  # raises on failure -> Functions retries, then poison queue
    logging.info("ingested blob %s: %s", name, out.get("status"))
