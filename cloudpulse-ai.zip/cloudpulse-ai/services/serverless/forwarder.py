"""Shared, stdlib-only forwarding logic for the AWS Lambda and Azure Function ingestion adapters.

Both adapters do the same thing: take a CSV that landed in object storage (S3 / Blob) or an operational event, and
POST it to the CloudPulse API with a *server-side* bearer token (INGEST_API_TOKEN). The API remains the single
place where validation, normalisation and de-duplication happen, so re-delivery of the same trigger is harmless.

Configuration (environment variables only; no credentials in code):
  CLOUDPULSE_API_URL   e.g. https://cloudpulse.example.com/api/v1
  INGEST_API_TOKEN     bearer token (prefer injecting from Secrets Manager / Key Vault references)
  FORWARD_TIMEOUT_S    per-request timeout, default 20
  FORWARD_RETRIES      attempts on 5xx/network errors, default 3
  MAX_CSV_BYTES        default 5 MiB (matches the API limit)
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
import uuid
from collections.abc import Callable

MAX_CSV_BYTES = int(os.environ.get("MAX_CSV_BYTES", 5 * 1024 * 1024))


class ForwardError(Exception):
    """Permanent (4xx) or exhausted-retry failure. Raised so the platform retries / dead-letters the trigger."""


def _cfg() -> tuple[str, str, float, int]:
    url = os.environ.get("CLOUDPULSE_API_URL", "").rstrip("/")
    token = os.environ.get("INGEST_API_TOKEN", "")
    if not url or not token:
        raise ForwardError("CLOUDPULSE_API_URL and INGEST_API_TOKEN must be set")
    if not url.startswith(("https://", "http://localhost", "http://127.0.0.1")):
        raise ForwardError("CLOUDPULSE_API_URL must use https (plain http is only allowed for localhost)")
    return url, token, float(os.environ.get("FORWARD_TIMEOUT_S", "20")), int(os.environ.get("FORWARD_RETRIES", "3"))


def build_multipart(filename: str, data: bytes, field: str = "file") -> tuple[bytes, str]:
    boundary = uuid.uuid4().hex
    safe = filename.replace('"', "").replace("\r", "").replace("\n", "")
    head = (
        f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{safe}"\r\n'
        "Content-Type: text/csv\r\n\r\n"
    ).encode()
    return head + data + f"\r\n--{boundary}--\r\n".encode(), f"multipart/form-data; boundary={boundary}"


Sender = Callable[[urllib.request.Request, float], tuple[int, bytes]]


def _default_sender(req: urllib.request.Request, timeout: float) -> tuple[int, bytes]:
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # TLS verification stays on (default context)
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def _post(path: str, body: bytes, content_type: str, sender: Sender | None = None, sleep=time.sleep) -> dict:
    url, token, timeout, retries = _cfg()
    send = sender or _default_sender
    last = "no attempt made"
    for attempt in range(1, retries + 1):
        req = urllib.request.Request(
            url + path,
            data=body,
            method="POST",
            headers={"Authorization": f"Bearer {token}", "Content-Type": content_type, "Accept": "application/json"},
        )
        try:
            status, payload = send(req, timeout)
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            last = f"network error: {type(e).__name__}"
        else:
            if 200 <= status < 300:
                return json.loads(payload or b"{}")
            if status == 429 or status >= 500:
                last = f"HTTP {status}"
            else:  # 4xx other than 429 will not succeed on retry
                try:
                    msg = json.loads(payload)["error"]["message"]
                except Exception:
                    msg = "request rejected"
                raise ForwardError(f"HTTP {status}: {msg}")
        if attempt < retries:
            sleep(min(2**attempt, 8))
    raise ForwardError(f"giving up after {retries} attempts ({last})")


def forward_csv(filename: str, data: bytes, sender: Sender | None = None, sleep=time.sleep) -> dict:
    name = os.path.basename(filename)
    if not name.lower().endswith(".csv"):
        raise ForwardError("only .csv objects are ingested")
    if len(data) > MAX_CSV_BYTES:
        raise ForwardError(f"object is larger than {MAX_CSV_BYTES} bytes")
    body, ctype = build_multipart(name, data)
    return _post("/ingestion/costs", body, ctype, sender, sleep)


def forward_events(events: list[dict], sender: Sender | None = None, sleep=time.sleep) -> dict:
    return _post("/events", json.dumps({"events": events}).encode(), "application/json", sender, sleep)


def eventbridge_to_event(evt: dict) -> dict:
    """Map an AWS EventBridge envelope to the CloudPulse event schema (message text is untrusted, stored as text)."""
    detail = evt.get("detail") if isinstance(evt.get("detail"), dict) else {}
    state = str(detail.get("state", {}).get("value", "")) if isinstance(detail.get("state"), dict) else ""
    severity = "error" if state == "ALARM" else "info"
    return {
        "event_id": str(evt.get("id", "")),
        "provider": "aws",
        "service": str(evt.get("source", "aws.unknown")).replace("aws.", "", 1) or "unknown",
        "environment": os.environ.get("CLOUDPULSE_ENVIRONMENT", "production"),
        "severity": severity,
        "event_type": str(evt.get("detail-type", "event"))[:100],
        "timestamp": evt.get("time"),
        "message": str(detail.get("alarmName") or evt.get("detail-type") or "event")[:1000],
        "correlation_id": str(evt.get("id", ""))[:100],
        "metadata": {"region": evt.get("region"), "account": evt.get("account")},
    }
