"""Operational event validation and deduplication keys."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from typing import Any

ALLOWED_PROVIDERS = {"aws", "azure", "other"}
ALLOWED_SEVERITIES = ("info", "warning", "error", "critical")
ALLOWED_ENVIRONMENTS = {"dev", "staging", "prod", "test", "demo"}
MAX_MESSAGE = 2000
MAX_METADATA_BYTES = 8192
_ID_RE = re.compile(r"^[A-Za-z0-9._:\-]{1,128}$")
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class EventValidationError(ValueError):
    def __init__(self, problems: list[dict[str, str]]):
        super().__init__("; ".join(f"{p['field']}: {p['reason']}" for p in problems))
        self.problems = problems


def _parse_ts(raw: Any) -> datetime:
    if isinstance(raw, datetime):
        dt = raw
    elif isinstance(raw, str):
        try:
            dt = datetime.fromisoformat(raw.strip().replace("Z", "+00:00"))
        except ValueError:
            raise ValueError("must be an ISO 8601 timestamp")
    else:
        raise ValueError("must be an ISO 8601 timestamp")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def validate_event(payload: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalise one event payload. Raises EventValidationError."""
    problems: list[dict[str, str]] = []

    def bad(f: str, r: str) -> None:
        problems.append({"field": f, "reason": r})

    out: dict[str, Any] = {}
    eid = str(payload.get("event_id", "")).strip()
    if not _ID_RE.match(eid):
        bad("event_id", "required; letters, digits and . _ : - only (max 128)")
    out["external_event_id"] = eid

    provider = str(payload.get("provider", "")).strip().lower()
    if provider not in ALLOWED_PROVIDERS:
        bad("provider", f"must be one of {sorted(ALLOWED_PROVIDERS)}")
    out["provider"] = provider

    service = str(payload.get("service", "")).strip()
    if not service or len(service) > 100:
        bad("service", "required, max 100 characters")
    out["service"] = service

    env = str(payload.get("environment", "")).strip().lower()
    if env not in ALLOWED_ENVIRONMENTS:
        bad("environment", f"must be one of {sorted(ALLOWED_ENVIRONMENTS)}")
    out["environment"] = env

    sev = str(payload.get("severity", "")).strip().lower()
    if sev not in ALLOWED_SEVERITIES:
        bad("severity", f"must be one of {list(ALLOWED_SEVERITIES)}")
    out["severity"] = sev

    etype = str(payload.get("event_type", "")).strip()
    if not etype or len(etype) > 64:
        bad("event_type", "required, max 64 characters")
    out["event_type"] = etype

    try:
        out["event_timestamp"] = _parse_ts(payload.get("timestamp"))
    except ValueError as e:
        bad("timestamp", str(e))

    msg = str(payload.get("message", ""))
    msg = _CTRL_RE.sub("", msg).strip()
    if not msg:
        bad("message", "required")
    out["message"] = msg[:MAX_MESSAGE]

    corr = payload.get("correlation_id")
    if corr is not None and corr != "":
        corr = str(corr).strip()
        if not _ID_RE.match(corr):
            bad("correlation_id", "invalid characters or too long")
    out["correlation_id"] = corr or None

    meta = payload.get("metadata") or {}
    if not isinstance(meta, dict):
        bad("metadata", "must be an object")
        meta = {}
    elif len(json.dumps(meta, default=str)) > MAX_METADATA_BYTES:
        bad("metadata", f"exceeds {MAX_METADATA_BYTES} bytes")
        meta = {}
    out["metadata"] = meta
    out["is_synthetic"] = bool(payload.get("is_synthetic", False))

    if problems:
        raise EventValidationError(problems)
    return out
