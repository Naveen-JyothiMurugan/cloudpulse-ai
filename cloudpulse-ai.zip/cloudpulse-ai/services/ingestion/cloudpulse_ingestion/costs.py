"""Cost CSV parsing, validation, normalisation and deduplication hashing.

Framework independent (stdlib only) so it is unit-testable anywhere and reused by
the API, scripts and cloud-function handlers.
"""

from __future__ import annotations

import csv
import hashlib
import io
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

REQUIRED_COLUMNS = [
    "usage_date",
    "provider",
    "account_identifier",
    "service_name",
    "region",
    "usage_quantity",
    "usage_unit",
    "cost_amount",
    "currency",
    "source_type",
]
ALLOWED_PROVIDERS = {"aws", "azure", "other"}
ALLOWED_SOURCES = {"synthetic", "aws_cost_explorer", "azure_cost_management", "manual_csv"}
MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_ROWS = 100_000
MAX_ERRORS_REPORTED = 200

SERVICE_ALIASES = {
    "amazon ec2": "EC2",
    "ec2": "EC2",
    "amazon elastic compute cloud": "EC2",
    "amazon s3": "S3",
    "s3": "S3",
    "amazon simple storage service": "S3",
    "aws lambda": "Lambda",
    "lambda": "Lambda",
    "amazon rds": "RDS",
    "rds": "RDS",
    "amazon dynamodb": "DynamoDB",
    "dynamodb": "DynamoDB",
    "amazon cloudwatch": "CloudWatch",
    "cloudwatch": "CloudWatch",
    "virtual machines": "Virtual Machines",
    "azure virtual machines": "Virtual Machines",
    "storage": "Blob Storage",
    "azure storage": "Blob Storage",
    "blob storage": "Blob Storage",
    "azure functions": "Functions",
    "functions": "Functions",
    "azure cosmos db": "Cosmos DB",
    "cosmos db": "Cosmos DB",
    "azure monitor": "Monitor",
    "monitor": "Monitor",
}
_ID_RE = re.compile(r"^[A-Za-z0-9._:/\- ]{1,128}$")
_REGION_RE = re.compile(r"^[a-z0-9\-_ ]{2,64}$")
_UNIT_RE = re.compile(r"^[A-Za-z0-9/\-_. ]{1,32}$")
_CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


@dataclass
class RowError:
    row: int
    field: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {"row": self.row, "field": self.field, "reason": self.reason}


@dataclass
class ParseResult:
    valid_rows: list[dict[str, Any]] = field(default_factory=list)
    errors: list[RowError] = field(default_factory=list)
    rows_total: int = 0
    rows_rejected: int = 0
    file_error: str | None = None
    errors_truncated: bool = False

    @property
    def ok(self) -> bool:
        return self.file_error is None


def normalize_service(name: str) -> str:
    key = " ".join(name.strip().split())
    return SERVICE_ALIASES.get(key.lower(), key)


def normalize_region(region: str) -> str:
    return " ".join(region.strip().lower().replace("_", "-").split())


def row_hash(row: dict[str, Any]) -> str:
    """Deterministic natural-key hash. Same business row => same hash => no duplicate on re-upload."""
    parts = [
        row["usage_date"].isoformat(),
        row["provider"],
        row["account_identifier"],
        row["service_name"],
        row["region"],
        row["usage_unit"],
        row["currency"],
        row["source_type"],
    ]
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


def _parse_date(raw: str) -> date:
    raw = raw.strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            pass
    try:  # ISO timestamp, normalised to its calendar date (UTC assumed)
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).date()
    except ValueError:
        raise ValueError("must be an ISO date such as 2025-03-01")


def _decimal(raw: str, name: str, non_negative: bool) -> Decimal:
    try:
        d = Decimal(raw.strip())
    except (InvalidOperation, AttributeError):
        raise ValueError("must be a number")
    if not d.is_finite():
        raise ValueError("must be a finite number")
    if non_negative and d < 0:
        raise ValueError("must not be negative")
    if abs(d) >= Decimal("1e12"):
        raise ValueError("value out of range")
    return d


def validate_row(raw: dict[str, str], row_no: int) -> tuple[dict[str, Any] | None, list[RowError]]:
    errs: list[RowError] = []

    def get(col: str) -> str:
        v = raw.get(col)
        return "" if v is None else v.strip()

    out: dict[str, Any] = {}
    for col in REQUIRED_COLUMNS:
        if get(col) == "":
            errs.append(RowError(row_no, col, "is required"))
    if errs:
        return None, errs

    try:
        out["usage_date"] = _parse_date(get("usage_date"))
    except ValueError as e:
        errs.append(RowError(row_no, "usage_date", str(e)))

    provider = get("provider").lower()
    if provider not in ALLOWED_PROVIDERS:
        errs.append(RowError(row_no, "provider", f"must be one of {sorted(ALLOWED_PROVIDERS)}"))
    out["provider"] = provider

    acct = get("account_identifier")
    if not _ID_RE.match(acct):
        errs.append(RowError(row_no, "account_identifier", "contains invalid characters or is too long"))
    out["account_identifier"] = acct

    out["service_name"] = normalize_service(get("service_name"))
    if len(out["service_name"]) > 100:
        errs.append(RowError(row_no, "service_name", "too long (max 100)"))

    out["region"] = normalize_region(get("region"))
    if not _REGION_RE.match(out["region"]):
        errs.append(RowError(row_no, "region", "invalid region value"))

    for col, nn in (("usage_quantity", True), ("cost_amount", False)):
        try:
            out[col] = _decimal(get(col), col, nn)
        except ValueError as e:
            errs.append(RowError(row_no, col, str(e)))

    unit = get("usage_unit")
    if not _UNIT_RE.match(unit):
        errs.append(RowError(row_no, "usage_unit", "invalid unit"))
    out["usage_unit"] = unit

    cur = get("currency").upper()
    if not _CURRENCY_RE.match(cur):
        errs.append(RowError(row_no, "currency", "must be a 3-letter ISO 4217 code"))
    out["currency"] = cur

    src = get("source_type").lower()
    if src not in ALLOWED_SOURCES:
        errs.append(RowError(row_no, "source_type", f"must be one of {sorted(ALLOWED_SOURCES)}"))
    out["source_type"] = src

    if errs:
        return None, errs
    out["is_synthetic"] = src == "synthetic"
    out["row_hash"] = row_hash(out)
    return out, []


def parse_cost_csv(data: bytes) -> ParseResult:
    """Parse and validate an uploaded cost CSV. Never raises for bad content."""
    res = ParseResult()
    if len(data) == 0:
        res.file_error = "File is empty."
        return res
    if len(data) > MAX_FILE_BYTES:
        res.file_error = f"File exceeds the {MAX_FILE_BYTES // (1024 * 1024)} MB limit."
        return res
    if b"\x00" in data:
        res.file_error = "File appears to be binary, not CSV text."
        return res
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        res.file_error = "File must be UTF-8 encoded text."
        return res

    reader = csv.DictReader(io.StringIO(text, newline=""))
    if reader.fieldnames is None:
        res.file_error = "File has no header row."
        return res
    headers = [h.strip() for h in reader.fieldnames]
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        res.file_error = f"Missing required column(s): {', '.join(missing)}."
        return res
    reader.fieldnames = headers

    seen: set[str] = set()
    for i, raw in enumerate(reader, start=2):  # header is line 1
        res.rows_total += 1
        if res.rows_total > MAX_ROWS:
            res.file_error = f"File exceeds the {MAX_ROWS} row limit."
            res.valid_rows.clear()
            return res
        row, errs = validate_row(raw, i)
        if errs:
            res.rows_rejected += 1
            for e in errs:
                if len(res.errors) < MAX_ERRORS_REPORTED:
                    res.errors.append(e)
                else:
                    res.errors_truncated = True
            continue
        if row is None:  # defensive; unreachable when no error was recorded
            continue
        if row["row_hash"] in seen:  # duplicate inside the same file
            continue
        seen.add(row["row_hash"])
        res.valid_rows.append(row)
    return res


def csv_safe(value: Any) -> str:
    """Neutralise spreadsheet formula injection for exported cells."""
    s = "" if value is None else str(value)
    if s and s[0] in ("=", "+", "-", "@", "\t", "\r"):
        # leave plain negative numbers alone
        try:
            float(s)
            return s
        except ValueError:
            return "'" + s
    return s
