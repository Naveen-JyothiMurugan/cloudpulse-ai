terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.70"
    }
  }
  # Remote state is intentionally NOT configured here. Add an S3/DynamoDB (or Terraform Cloud) backend
  # in your own fork before sharing state between people. See docs/DEPLOYMENT_GUIDE.md.
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = local.tags
  }
}
