variable "name" { type = string }
variable "bucket_id" { type = string }
variable "bucket_arn" { type = string }
variable "api_url" { type = string }
variable "token_secret_arn" { type = string }
variable "lambda_zip_path" { type = string }
variable "log_retention_days" { type = number }

data "aws_iam_policy_document" "assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "lambda" {
  name               = "${var.name}-ingest-lambda"
  assume_role_policy = data.aws_iam_policy_document.assume.json
}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${var.name}-ingest"
  retention_in_days = var.log_retention_days
}

resource "aws_sqs_queue" "dlq" {
  name                      = "${var.name}-ingest-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true
}

# Least privilege: read only the cost-exports prefix, read one secret, write own logs, send to own DLQ.
data "aws_iam_policy_document" "lambda" {
  statement {
    actions   = ["s3:GetObject"]
    resources = ["${var.bucket_arn}/cost-exports/*"]
  }
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.token_secret_arn]
  }
  statement {
    actions   = ["logs:CreateLogStream", "logs:PutLogEvents"]
    resources = ["${aws_cloudwatch_log_group.lambda.arn}:*"]
  }
  statement {
    actions   = ["sqs:SendMessage"]
    resources = [aws_sqs_queue.dlq.arn]
  }
}

resource "aws_iam_role_policy" "lambda" {
  name   = "ingest"
  role   = aws_iam_role.lambda.id
  policy = data.aws_iam_policy_document.lambda.json
}

resource "aws_lambda_function" "ingest" {
  function_name    = "${var.name}-ingest"
  role             = aws_iam_role.lambda.arn
  runtime          = "python3.12"
  handler          = "handler.handler"
  filename         = var.lambda_zip_path
  source_code_hash = try(filebase64sha256(var.lambda_zip_path), null)
  timeout          = 60
  memory_size      = 256
  architectures    = ["arm64"]

  environment {
    variables = {
      CLOUDPULSE_API_URL      = var.api_url
      INGEST_TOKEN_SECRET_ARN = var.token_secret_arn
    }
  }

  dead_letter_config {
    target_arn = aws_sqs_queue.dlq.arn
  }

  depends_on = [aws_cloudwatch_log_group.lambda, aws_iam_role_policy.lambda]
}

resource "aws_lambda_permission" "s3" {
  statement_id  = "AllowS3Invoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ingest.function_name
  principal     = "s3.amazonaws.com"
  source_arn    = var.bucket_arn
}

resource "aws_s3_bucket_notification" "csv" {
  bucket = var.bucket_id
  lambda_function {
    lambda_function_arn = aws_lambda_function.ingest.arn
    events              = ["s3:ObjectCreated:*"]
    filter_prefix       = "cost-exports/"
    filter_suffix       = ".csv"
  }
  depends_on = [aws_lambda_permission.s3]
}

output "function_name" { value = aws_lambda_function.ingest.function_name }
output "dlq_name" { value = aws_sqs_queue.dlq.name }
