variable "name" { type = string }

# Containers only. Values are set out-of-band so they never enter Terraform state:
#   aws secretsmanager put-secret-value --secret-id <arn> --secret-string "$(openssl rand -base64 36)"
resource "aws_secretsmanager_secret" "ingest_token" {
  name                    = "${var.name}/ingest-api-token"
  description             = "Bearer token the ingestion Lambda uses to call the CloudPulse API"
  recovery_window_in_days = 7
}

resource "aws_secretsmanager_secret" "app" {
  name                    = "${var.name}/app"
  description             = "SECRET_KEY, database password and optional LLM key for the API"
  recovery_window_in_days = 7
}

output "ingest_token_secret_arn" { value = aws_secretsmanager_secret.ingest_token.arn }
output "app_secret_arn" { value = aws_secretsmanager_secret.app.arn }
