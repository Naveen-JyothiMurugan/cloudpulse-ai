variable "name" { type = string }
variable "instance_type" { type = string }
variable "secret_arns" { type = list(string) }
variable "raw_bucket_arn" { type = string }
variable "events_table_arn" { type = string }

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-arm64"
}

data "aws_iam_policy_document" "assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "host" {
  name               = "${var.name}-app-host"
  assume_role_policy = data.aws_iam_policy_document.assume.json
}

# Session Manager access instead of SSH keys.
resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.host.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

data "aws_iam_policy_document" "app" {
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = var.secret_arns
  }
  statement {
    actions   = ["s3:GetObject", "s3:ListBucket"]
    resources = [var.raw_bucket_arn, "${var.raw_bucket_arn}/*"]
  }
  statement {
    actions   = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:Query"]
    resources = [var.events_table_arn]
  }
  statement {
    actions   = ["ce:GetCostAndUsage"]
    resources = ["*"] # Cost Explorer does not support resource-level permissions
  }
  statement {
    actions   = ["cloudwatch:GetMetricData", "cloudwatch:ListMetrics"]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "app" {
  name   = "app"
  role   = aws_iam_role.host.id
  policy = data.aws_iam_policy_document.app.json
}

resource "aws_iam_instance_profile" "host" {
  name = "${var.name}-app-host"
  role = aws_iam_role.host.name
}

# Only the reverse proxy port you choose to open; default: none (use SSM port forwarding).
resource "aws_security_group" "host" {
  name_prefix = "${var.name}-host-"
  vpc_id      = data.aws_vpc.default.id
  description = "CloudPulse app host (no inbound by default)"
  egress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "host" {
  ami                    = data.aws_ssm_parameter.al2023.value
  instance_type          = var.instance_type
  subnet_id              = data.aws_subnets.default.ids[0]
  iam_instance_profile   = aws_iam_instance_profile.host.name
  vpc_security_group_ids = [aws_security_group.host.id]

  metadata_options {
    http_tokens   = "required" # IMDSv2 only
    http_endpoint = "enabled"
  }
  root_block_device {
    volume_size = 30
    volume_type = "gp3"
    encrypted   = true
  }
  tags = { Name = "${var.name}-app-host" }
}

output "instance_id" { value = aws_instance.host.id }
