variable "name" { type = string }

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

resource "aws_db_subnet_group" "this" {
  name       = "${var.name}-db"
  subnet_ids = data.aws_subnets.default.ids
}

# No ingress rules: add one from your application's security group after you create it.
resource "aws_security_group" "db" {
  name_prefix = "${var.name}-db-"
  vpc_id      = data.aws_vpc.default.id
  description = "CloudPulse PostgreSQL (no default ingress)"
}

resource "aws_db_instance" "this" {
  identifier                  = "${var.name}-pg"
  engine                      = "postgres"
  engine_version              = "16"
  instance_class              = "db.t4g.micro"
  allocated_storage           = 20
  max_allocated_storage       = 50
  storage_encrypted           = true
  db_name                     = "cloudpulse"
  username                    = "cloudpulse"
  manage_master_user_password = true # password lives in Secrets Manager, never in Terraform state
  db_subnet_group_name        = aws_db_subnet_group.this.name
  vpc_security_group_ids      = [aws_security_group.db.id]
  publicly_accessible         = false
  backup_retention_period     = 7
  deletion_protection         = true
  skip_final_snapshot         = false
  final_snapshot_identifier   = "${var.name}-pg-final"
  auto_minor_version_upgrade  = true
}

output "endpoint" { value = aws_db_instance.this.endpoint }
output "security_group_id" { value = aws_security_group.db.id }
