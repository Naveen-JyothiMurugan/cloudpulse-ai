# CloudPulse AI – Terraform (AWS)

**Nothing in this directory has been applied or even `terraform validate`d by the author** (no Terraform binary was
available in the build sandbox); CI runs `fmt`, `init -backend=false` and `validate` (see `.github/workflows/ci.yml`).
Never run `terraform apply` against an account you have not reviewed the plan for.

```bash
cp envs/dev.tfvars.example envs/dev.tfvars
terraform init
terraform plan -var-file=envs/dev.tfvars -out=tfplan   # review!
# terraform apply tfplan                               # only with explicit authorisation
terraform destroy -var-file=envs/dev.tfvars            # teardown
```

Defaults create only S3 + DynamoDB (on-demand) + Secrets Manager containers + SNS. The EC2 host and RDS are opt-in.
