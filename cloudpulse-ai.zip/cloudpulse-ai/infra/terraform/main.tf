locals {
  name = "${var.project}-${var.environment}"
  tags = {
    Project     = "CloudPulse-AI"
    Environment = var.environment
    ManagedBy   = "terraform"
    CostCentre  = "portfolio"
  }
}

module "storage" {
  source                  = "./modules/storage"
  name                    = local.name
  raw_data_retention_days = var.raw_data_retention_days
}

module "secrets" {
  source = "./modules/secrets"
  name   = local.name
}

module "ingestion" {
  count  = var.api_url == "" ? 0 : 1
  source = "./modules/ingestion"

  name               = local.name
  bucket_id          = module.storage.raw_bucket_id
  bucket_arn         = module.storage.raw_bucket_arn
  api_url            = var.api_url
  token_secret_arn   = module.secrets.ingest_token_secret_arn
  lambda_zip_path    = var.lambda_zip_path
  log_retention_days = var.log_retention_days
}

module "monitoring" {
  source             = "./modules/monitoring"
  name               = local.name
  alarm_email        = var.alarm_email
  lambda_name        = try(module.ingestion[0].function_name, "")
  dlq_name           = try(module.ingestion[0].dlq_name, "")
  log_retention_days = var.log_retention_days
}

module "database" {
  count  = var.enable_rds ? 1 : 0
  source = "./modules/database"
  name   = local.name
}

module "app_host" {
  count            = var.enable_app_host ? 1 : 0
  source           = "./modules/app_host"
  name             = local.name
  instance_type    = var.app_instance_type
  secret_arns      = [module.secrets.ingest_token_secret_arn, module.secrets.app_secret_arn]
  raw_bucket_arn   = module.storage.raw_bucket_arn
  events_table_arn = module.storage.events_table_arn
}
