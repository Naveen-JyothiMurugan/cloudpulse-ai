variable "aws_region" {
  description = "AWS region for all resources."
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name (dev, staging, prod). Used in resource names and tags."
  type        = string
  default     = "dev"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be dev, staging or prod."
  }
}

variable "project" {
  type    = string
  default = "cloudpulse"
}

variable "api_url" {
  description = "Public HTTPS base URL of the CloudPulse API (e.g. https://cloudpulse.example.com/api/v1). Empty disables the ingestion Lambda."
  type        = string
  default     = ""
  validation {
    condition     = var.api_url == "" || startswith(var.api_url, "https://")
    error_message = "api_url must be empty or start with https://"
  }
}

variable "lambda_zip_path" {
  description = "Path to dist/aws_lambda.zip produced by scripts/package_serverless.sh."
  type        = string
  default     = "../../dist/aws_lambda.zip"
}

variable "alarm_email" {
  description = "Optional e-mail address subscribed to the alarm topic (requires confirming the subscription)."
  type        = string
  default     = ""
}

variable "log_retention_days" {
  type    = number
  default = 30
}

variable "raw_data_retention_days" {
  description = "S3 lifecycle expiry for raw cost exports."
  type        = number
  default     = 90
}

# ---- optional, cost-bearing components: all OFF by default ----
variable "enable_app_host" {
  description = "Create a single small EC2 instance (SSM-managed, no SSH) to run docker compose. Costs money while running."
  type        = bool
  default     = false
}

variable "app_instance_type" {
  type    = string
  default = "t4g.small"
}

variable "enable_rds" {
  description = "Create a managed PostgreSQL instance (db.t4g.micro). Costs money while running."
  type        = bool
  default     = false
}
