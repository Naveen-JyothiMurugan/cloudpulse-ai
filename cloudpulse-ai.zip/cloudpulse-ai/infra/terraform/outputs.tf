output "raw_data_bucket" {
  value = module.storage.raw_bucket_id
}

output "events_table" {
  value = module.storage.events_table_name
}

output "ingest_token_secret_arn" {
  description = "Set the secret VALUE out-of-band (aws secretsmanager put-secret-value); Terraform never holds it."
  value       = module.secrets.ingest_token_secret_arn
}

output "alarm_topic_arn" {
  value = module.monitoring.topic_arn
}

output "app_host_instance_id" {
  value = try(module.app_host[0].instance_id, null)
}

output "database_endpoint" {
  value = try(module.database[0].endpoint, null)
}
