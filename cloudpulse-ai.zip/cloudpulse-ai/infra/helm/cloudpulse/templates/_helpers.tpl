{{- define "cloudpulse.labels" -}}
app.kubernetes.io/name: cloudpulse
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
{{- define "cloudpulse.podSecurity" -}}
securityContext:
  runAsNonRoot: true
  runAsUser: 10001
  runAsGroup: 10001
  seccompProfile: { type: RuntimeDefault }
{{- end -}}
{{- define "cloudpulse.containerSecurity" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities: { drop: ["ALL"] }
{{- end -}}
{{- define "cloudpulse.apiEnv" -}}
- { name: APP_ENV, value: {{ .Values.config.appEnv | quote }} }
- { name: LOG_LEVEL, value: {{ .Values.config.logLevel | quote }} }
- { name: CORS_ORIGINS, value: {{ .Values.config.corsOrigins | quote }} }
- { name: COOKIE_SECURE, value: {{ .Values.config.cookieSecure | quote }} }
- { name: DEFAULT_DATA_MODE, value: {{ .Values.config.defaultDataMode | quote }} }
- name: DATABASE_URL
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: DATABASE_URL } }
- name: SECRET_KEY
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: SECRET_KEY } }
- name: INGEST_API_TOKEN
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: INGEST_API_TOKEN, optional: true } }
- name: LLM_API_KEY
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: LLM_API_KEY, optional: true } }
{{- end -}}
