#!/bin/sh
# Optionally apply migrations before starting (RUN_MIGRATIONS=1, convenient for local Compose).
# In Kubernetes, run migrations as a separate Job/hook instead (see infra/helm) so replicas do not race.
set -eu

if [ "${RUN_MIGRATIONS:-0}" = "1" ]; then
  echo "applying database migrations..."
  alembic upgrade head
fi
exec "$@"
