# CloudPulse AI — Intelligent Cloud Operations and Cost Optimization Platform

CloudPulse AI ingests cloud cost data and operational events, shows cost and reliability dashboards, detects cost
anomalies with a transparent statistical baseline, forecasts near-term spend, turns findings into recommendations,
and tracks alerts and incidents. Everything works **locally with synthetic data and without any cloud account or AI
key**; AWS/Azure integrations and an LLM explainer are optional and off by default.

> **Honest status (read this first).** This repository was built in a sandbox with **no PyPI/npm access and no Docker
> daemon**. The analytics, ingestion, security helpers, serverless forwarders and the whole SQL layer were
> executed and tested (123 tests pass, see [docs/TEST_RESULTS.md](docs/TEST_RESULTS.md)). The FastAPI HTTP layer,
> Next.js frontend, Docker images, Compose stack, Helm/Argo CD/Terraform and the AWS/Azure adapters were **written but
> never executed**. Expect to fix small integration issues on first run. Each document says what is verified and what is not.
> All demo numbers are **synthetic**; they are not cloud bills and the detection results on them are not evidence of real-world accuracy.

## Features

| Area | Implemented | Verified here |
|---|---|---|
| Cost CSV ingestion (validate, normalise, dedupe, run history) | yes | unit + real PostgreSQL |
| Operational event ingestion (dedupe, full-text search) | yes | unit + real PostgreSQL |
| Dashboard metrics, trends, breakdowns, freshness | yes | SQL checked against raw queries |
| Anomaly detection (robust z-score default, IsolationForest option) | yes | unit + DB; deterministic |
| Baseline forecast with backtest (MAE vs naive) | yes | unit + DB |
| Rule-based recommendations; optional LLM with strict schema + fallback | yes | rules tested; LLM client untested |
| Alerts, incidents, notes, audit log | yes | DB lifecycle tests |
| REST API `/api/v1`, OpenAPI at `/api/v1/docs` | yes | **not run** |
| Auth: scrypt, signed cookie sessions, CSRF, RBAC, lockout, rate limits | yes | helpers unit-tested; HTTP flow **not run** |
| Next.js dashboard (12 routes) | yes | syntax-parsed only; **not built or run** |
| Lambda / Azure Function ingestion forwarders | yes | unit-tested with fakes |
| AWS / Azure provider adapters | yes (disabled by default) | **never run against a real cloud** |
| Docker, Compose, Helm, Argo CD, Terraform, GitHub Actions | yes | YAML/syntax checked only |
| Prometheus metrics + Grafana dashboard | yes | **not run** |

## Architecture

```mermaid
flowchart LR
  subgraph Browser
    UI[Next.js UI]
  end
  UI -- "/api/v1 (same-origin proxy)" --> API[FastAPI]
  API --> DB[(PostgreSQL)]
  API --> AN[Analytics package<br/>pandas / scikit-learn]
  API -. optional .-> LLM[LLM provider]
  S3[(S3 / Blob raw exports)] -- trigger --> FN[Lambda / Azure Function]
  FN -- "Bearer token" --> API
  API -. optional, disabled by default .-> CLOUD[AWS Cost Explorer / Azure Cost Mgmt]
  API -- /metrics --> PROM[Prometheus] --> GRAF[Grafana]
```

More diagrams: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Full report: [docs/PROJECT_DOCUMENTATION.md](docs/PROJECT_DOCUMENTATION.md).

## Technology stack

Python 3.13, FastAPI, Pydantic, SQLAlchemy Core (`text()` with bind parameters), Alembic, PostgreSQL 16, pandas, NumPy,
scikit-learn · Next.js 14, React 18, TypeScript, Tailwind CSS, Recharts, Vitest, Playwright · Docker, Docker Compose,
Kubernetes (Helm), Argo CD, Terraform (AWS), GitHub Actions, Prometheus, Grafana. Redis is intentionally **not** used (see [docs/DECISIONS.md](docs/DECISIONS.md)).

## Prerequisites

Docker + Docker Compose v2 for the main path. For running tests without Docker: Python 3.12+ and a local PostgreSQL 16 install (`postgres`/`initdb`/`psql`). For the frontend: Node 22.

## Quick start (Docker Compose)

```bash
make setup      # creates .env with random secrets (never committed)
make up         # builds and starts db, api (runs migrations), web
make seed       # creates the admin user from .env and loads the SYNTHETIC demo dataset
# open http://localhost:3000 — sign in as CLOUDPULSE_ADMIN_EMAIL with CLOUDPULSE_ADMIN_PASSWORD from .env
make down       # stop (data kept)    |    make reset  # stop and DELETE the data volume
```

* API docs: <http://localhost:8000/api/v1/docs> · Health: `/api/v1/health` · Readiness: `/api/v1/ready` · Metrics: `/api/v1/metrics`
* **Create the first admin** manually: `docker compose exec -e CLOUDPULSE_ADMIN_PASSWORD='<strong password>' api python -m app.cli create-admin --email you@example.com`. There is no public registration endpoint.
* Read-only users: `python -m app.cli create-user --email viewer@example.com --role readonly`.
* Migrations: `make migrate` (also run automatically on API start in Compose via `RUN_MIGRATIONS=1`).
* Seed data only: `docker compose exec api python -m app.cli load-demo` (idempotent; safe to repeat). Regenerate the CSV deterministically with `make sample`.

## Running without Docker (what the author could actually run)

```bash
make test-unit   # 80 tests, no database
make test-db     # 43 tests against a throw-away local PostgreSQL started by scripts/with_test_db.sh
make lint        # ruff (+ eslint for the web app when node_modules is installed)
```

To run the API directly: `pip install -r apps/api/requirements.txt`, export `DATABASE_URL`, `SECRET_KEY`, then
`cd apps/api && alembic upgrade head && uvicorn app.main:app --reload` with `PYTHONPATH=apps/api:services/analytics:services/ingestion`. **(Untested here.)**
Frontend: `cd apps/web && npm install && npm run dev` (proxies `/api/v1` to `API_INTERNAL_URL`, default `http://localhost:8000`). **(Untested here.)**

## Configuration

All settings come from environment variables; see [.env.example](.env.example) for every variable with comments.
In `APP_ENV=production` the API refuses to start with the dev secret, a secret shorter than 32 chars, `COOKIE_SECURE=false`, or `CORS_ORIGINS=*`.

## Optional cloud integrations

Disabled by default. The Integrations page shows configured/missing settings and offers a read-only connection test.
No cloud credentials are ever entered in the browser: use IAM roles / managed identity. Permissions and steps: [docs/DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md#optional-cloud-integrations).

## Tests, CI, deployment

* Test plan and **actual** results: [docs/TEST_PLAN.md](docs/TEST_PLAN.md), [docs/TEST_RESULTS.md](docs/TEST_RESULTS.md).
* CI (`.github/workflows`): lint, backend tests with a Postgres service, API e2e, web lint/typecheck/test/build, dependency audit, secret scan, image build + Trivy, Terraform fmt/validate, Helm lint. **Never executed on GitHub by the author.**
* Local Kubernetes: `scripts/kind_local.sh up` (kind + Helm). GitOps with Argo CD: [docs/GITOPS_GUIDE.md](docs/GITOPS_GUIDE.md). Terraform (AWS): [infra/terraform/README.md](infra/terraform/README.md) — plan only, never apply without review.
* Costs: [docs/COST_ESTIMATION.md](docs/COST_ESTIMATION.md). Demo walkthrough: [docs/DEMO_SCRIPT.md](docs/DEMO_SCRIPT.md).

## Repository layout

```
apps/api            FastAPI app, Alembic, schema.sql, Dockerfile
apps/web            Next.js UI, Vitest tests, Playwright spec, Dockerfile
services/analytics  anomaly detection, forecasting, recommendations (framework-free, importable)
services/ingestion  CSV and event validation (framework-free)
services/serverless Lambda + Azure Function forwarders (stdlib only)
data/sample         deterministic SYNTHETIC cost CSV, events JSON, ground truth
infra/              docker entrypoint, Helm chart, K8s dev manifests, Terraform (AWS)
gitops/             Argo CD project/applications, per-environment Helm values
monitoring/         Prometheus config + alert rules, Grafana provisioning + dashboard
scripts/            setup_env, sample-data generator, test DB runner, chaos/backup/kind helpers, packaging, secret scan
tests/              unit, integration (real PostgreSQL), e2e workflow, shared test support
docs/               full documentation set
```

## Troubleshooting

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md). Most common: missing `.env` (run `make setup`), API exits at start because production settings are unsafe, or port 3000/8000/5432 already in use.

## Limitations

Single-replica rate limiting (in-process), dominant-currency analytics (no FX conversion), baseline-only forecasting, statistical anomalies can be false positives on seasonal spend, cloud adapters unproven against real accounts. More in [docs/PROJECT_DOCUMENTATION.md](docs/PROJECT_DOCUMENTATION.md#26-known-limitations).

## License

No license has been chosen; add one before publishing.
