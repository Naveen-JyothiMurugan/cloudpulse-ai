#!/usr/bin/env python3
"""End-to-end API workflow against a RUNNING stack (stdlib only). Mirrors the 12-step scenario in the spec.

  CLOUDPULSE_API=http://localhost:8000/api/v1 CLOUDPULSE_ADMIN_EMAIL=... CLOUDPULSE_ADMIN_PASSWORD=... \
  python tests/e2e/api_workflow.py [--restart-cmd "docker compose restart api"]

Prints PASS/FAIL per step and exits non-zero on the first failure. Requires an empty or demo-only database
(it uploads the synthetic CSV; re-running is safe because ingestion is idempotent).
"""

from __future__ import annotations

import argparse
import http.cookiejar
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
API = os.environ.get("CLOUDPULSE_API", "http://localhost:8000/api/v1")


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self.csrf = None

    def call(self, method, path, body=None, raw=None, headers=None, expect=(200, 201, 204)):
        h = dict(headers or {})
        data = raw
        if body is not None:
            data, h["Content-Type"] = json.dumps(body).encode(), "application/json"
        if self.csrf and method not in ("GET", "HEAD"):
            h["X-CSRF-Token"] = self.csrf
        req = urllib.request.Request(API + path, data, h, method=method)
        try:
            r = self.op.open(req, timeout=60)
            status, payload = r.status, r.read()
        except urllib.error.HTTPError as e:
            status, payload = e.code, e.read()
        ctype_json = payload[:1] in (b"{", b"[")
        parsed = json.loads(payload) if ctype_json else payload.decode("utf-8", "replace")
        if expect and status not in expect:
            raise AssertionError(f"{method} {path} -> {status}: {str(parsed)[:300]}")
        return status, parsed


def multipart(field, filename, content):
    boundary = uuid.uuid4().hex
    body = (
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'
            f"Content-Type: text/csv\r\n\r\n"
        ).encode()
        + content
        + f"\r\n--{boundary}--\r\n".encode()
    )
    return body, {"Content-Type": f"multipart/form-data; boundary={boundary}"}


def step(n, title, fn):
    try:
        out = fn()
        print(f"PASS {n:>2}. {title}")
        return out
    except Exception as e:  # noqa: BLE001
        print(f"FAIL {n:>2}. {title}: {e}")
        sys.exit(1)


def wait_ready(timeout=90):
    end = time.time() + timeout
    while time.time() < end:
        try:
            urllib.request.urlopen(API + "/ready", timeout=3)
            return
        except Exception:
            time.sleep(2)
    raise TimeoutError("API did not become ready")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--restart-cmd", help="shell command that restarts the application services")
    a = ap.parse_args()
    c = Client()
    email, pw = os.environ.get("CLOUDPULSE_ADMIN_EMAIL"), os.environ.get("CLOUDPULSE_ADMIN_PASSWORD")
    if not (email and pw):
        sys.exit("Set CLOUDPULSE_ADMIN_EMAIL and CLOUDPULSE_ADMIN_PASSWORD")
    csv_bytes = (ROOT / "data" / "sample" / "synthetic_costs.csv").read_bytes()
    state = {}

    step(1, "application is ready", wait_ready)

    def login():
        _, me = c.call("POST", "/auth/login", {"email": email, "password": pw})
        c.csrf = me["csrf_token"]
        assert me["role"] == "admin"
        c.call("POST", "/auth/login", {"email": email, "password": "wrong-password-1A"}, expect=(401,))

    step(2, "authenticate (and reject a wrong password)", login)

    def upload():
        body, h = multipart("file", "synthetic_costs.csv", csv_bytes)
        _, r = c.call("POST", "/ingestion/costs", raw=body, headers=h)
        assert r["status"] == "succeeded" and r["rows_rejected"] == 0, r
        assert r["rows_inserted"] + r["rows_duplicate"] == 1320, r
        body, h = multipart("file", "synthetic_costs.csv", csv_bytes)
        _, again = c.call("POST", "/ingestion/costs", raw=body, headers=h)
        assert again["rows_inserted"] == 0 and again["rows_duplicate"] == 1320, again

    step(3, "upload synthetic CSV; second upload inserts nothing", upload)

    def runs():
        _, r = c.call("GET", "/ingestion/runs?page_size=5")
        assert r["total"] >= 2 and r["items"][0]["status"] == "succeeded"

    step(4, "ingestion run history shows results", runs)

    def summary():
        _, s = c.call("GET", "/costs/summary?date_from=2025-03-01&date_to=2025-03-31")
        assert s["has_data"] and s["data_origin"] == "synthetic" and s["total_cost"] > 0
        state["total"] = s["total_cost"]
        _, ts = c.call("GET", "/costs/timeseries?granularity=month&group_by=provider")
        assert ts["points"]
        _, d = c.call("GET", "/dashboard")
        assert d["summary"]["has_data"]

    step(5, "cost summary, time series and dashboard", summary)

    def detect():
        _, r = c.call("POST", "/anomalies/run", {})
        assert r["detected"] == 4, r
        _, r2 = c.call("POST", "/anomalies/run", {})
        assert r2["new"] == 0 and r2["suppressed_duplicates"] == 4, r2

    step(6, "run anomaly detection; re-run is suppressed", detect)

    def forecast():
        _, f = c.call("POST", "/forecasts/run", {"horizon_days": 14})
        assert f["status"] == "ok" and f["evaluation"]["mae"] >= 0 and len(f["forecast"]) == 14

    step(7, "generate forecast with backtest evaluation", forecast)

    def reco():
        _, r = c.call("GET", "/recommendations?severity=critical&sort_by=severity")
        assert r["total"] >= 1, r
        item = r["items"][0]
        assert item["evidence_json"] and item["next_steps_json"] and "requires_human_review" in item

    step(8, "review a recommendation", reco)

    def event():
        eid = "e2e-" + uuid.uuid4().hex[:10]
        ev = {
            "event_id": eid,
            "provider": "aws",
            "service": "EC2",
            "environment": "demo",
            "severity": "error",
            "event_type": "scaling",
            "timestamp": "2025-02-14T12:00:00Z",
            "message": "e2e test event",
        }
        _, r = c.call("POST", "/events", ev)
        assert r["created"] == 1
        _, r2 = c.call("POST", "/events", ev)
        assert r2["duplicates"] == 1
        _, found = c.call("GET", "/events?q=e2e%20test")
        assert found["total"] >= 1

    step(9, "ingest an operational event; duplicate detected", event)

    def lifecycle():
        _, al = c.call("GET", "/alerts?status=open&sort_by=severity")
        aid = al["items"][0]["id"]
        _, a1 = c.call("POST", f"/alerts/{aid}/acknowledge")
        assert a1["status"] == "acknowledged"
        c.call("POST", f"/alerts/{aid}/notes", {"body": "e2e investigation note"})
        _, a2 = c.call("POST", f"/alerts/{aid}/resolve")
        assert a2["status"] == "resolved" and len(a2["notes"]) >= 1
        state["alert"] = aid

    step(10, "acknowledge, annotate and resolve an alert", lifecycle)

    def export():
        _, rep = c.call("GET", "/exports/report.md?date_from=2025-03-01&date_to=2025-03-31")
        assert "SYNTHETIC" in rep
        _, csvtxt = c.call("GET", "/exports/costs.csv?provider=aws&date_from=2025-03-01&date_to=2025-03-02")
        assert csvtxt.startswith("usage_date,provider") and csvtxt.count("\n") > 5

    step(11, "export report and filtered CSV", export)

    def persistence():
        if a.restart_cmd:
            subprocess.run(a.restart_cmd, shell=True, check=True)
            wait_ready()
        c2 = Client()
        _, me = c2.call("POST", "/auth/login", {"email": email, "password": pw})
        _, al = c2.call("GET", f"/alerts/{state['alert']}")
        assert al["status"] == "resolved"
        _, s = c2.call("GET", "/costs/summary?date_from=2025-03-01&date_to=2025-03-31")
        assert abs(s["total_cost"] - state["total"]) < 0.01

    step(
        12,
        "data persists" + (" after restarting services" if a.restart_cmd else " (no restart command given)"),
        persistence,
    )
    print("ALL STEPS PASSED")


if __name__ == "__main__":
    main()
