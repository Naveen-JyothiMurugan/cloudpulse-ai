"""Service-layer integration tests: real PostgreSQL, real application SQL.

Covers ingestion idempotency, event deduplication, detection + alert suppression, forecasting persistence,
alert/incident lifecycle, dashboard aggregation and the shared list/filter/sort builders.

Requires CLOUDPULSE_TEST_DSN (skipped otherwise). Runs against real SQLAlchemy when installed, otherwise
the psql-based shim (see tests/support/pgshim.py); the active backend is printed in the test output.
"""

import json
import sys
import types
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests" / "support"))
import conn as support  # noqa: E402  (installs the shim when SQLAlchemy is unavailable)

try:  # FastAPI is only needed for Query() defaults in listing.py; stub it when absent
    import fastapi  # noqa: F401
except ImportError:
    stub = types.ModuleType("fastapi")
    stub.Query = lambda default=None, **kw: default
    sys.modules["fastapi"] = stub

from app import listing as L  # noqa: E402
from app.core import queryutil as qu  # noqa: E402
from app.services import alerts as A  # noqa: E402
from app.services import dashboard as D  # noqa: E402
from app.services import detect as DET  # noqa: E402
from app.services import ingest as ING  # noqa: E402
from sqlalchemy import text  # noqa: E402

SAMPLE = ROOT / "data" / "sample"


def n(conn, sql, **p):
    return conn.execute(text(sql), p).scalar_one()


@unittest.skipUnless(support.DSN, "needs CLOUDPULSE_TEST_DSN")
class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        print(f"\n[service tests backend: {support.BACKEND}]")

    def setUp(self):
        self.conn = support.make_conn()
        support.reset_database(self.conn)
        self.uid = self.conn.execute(
            text("INSERT INTO users (email, password_hash, role_id) VALUES ('admin@example.com', 'x', 1) RETURNING id")
        ).scalar_one()
        self.conn.commit()

    def tearDown(self):
        self.conn.close()

    def load_demo(self):
        return ING.load_demo_data(self.conn, str(SAMPLE), self.uid)

    # ---- ingestion ----------------------------------------------------------------------------------------
    def test_csv_ingest_then_reupload_inserts_nothing(self):
        data = (SAMPLE / "synthetic_costs.csv").read_bytes()
        first = ING.ingest_cost_csv(self.conn, data, "synthetic_costs.csv", self.uid)
        self.assertEqual((first["status"], first["rows_inserted"], first["rows_duplicate"]), ("succeeded", 1320, 0))
        second = ING.ingest_cost_csv(self.conn, data, "synthetic_costs.csv", self.uid)
        self.assertEqual((second["status"], second["rows_inserted"], second["rows_duplicate"]), ("succeeded", 0, 1320))
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records"), 1320)
        self.assertEqual(n(self.conn, "SELECT count(*) FROM ingestion_runs"), 2)
        self.assertEqual(n(self.conn, "SELECT rows_duplicate FROM ingestion_runs ORDER BY id DESC LIMIT 1"), 1320)

    def test_partial_and_failed_runs_recorded_with_errors(self):
        good = (SAMPLE / "synthetic_costs.csv").read_text().splitlines()
        bad = good[:3] + ["2025-01-01,aws,111122223333,EC2,us-east-1,1,Hrs,notanumber,USD,synthetic"]
        res = ING.ingest_cost_csv(self.conn, ("\n".join(bad) + "\n").encode(), "bad.csv", self.uid)
        self.assertEqual((res["status"], res["rows_inserted"], res["rows_rejected"]), ("partial", 2, 1))
        self.assertEqual(res["errors"][0]["field"], "cost_amount")
        stored = (
            self.conn.execute(
                text("SELECT status, errors_json FROM ingestion_runs WHERE id = :i"), {"i": res["run_id"]}
            )
            .mappings()
            .first()
        )
        self.assertEqual(stored["status"], "partial")
        failed = ING.ingest_cost_csv(self.conn, b"wrong,header\n1,2\n", "x.csv", self.uid)
        self.assertEqual(failed["status"], "failed")
        self.assertIn("Missing required column", failed["error"])
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records"), 2)

    def test_provider_sync_ingests_idempotently_and_records_status(self):
        class FakeAws:
            def fetch_costs(self, start, end):
                return [
                    {"usage_date": "2025-06-01", "provider": "aws", "account_identifier": "111122223333",
                     "service_name": "Amazon Elastic Compute Cloud - Compute", "region": "us-east-1",
                     "usage_quantity": "10.5", "usage_unit": "Hrs", "cost_amount": "42.10", "currency": "USD",
                     "source_type": "aws_cost_explorer"},
                    {"usage_date": "2025-06-01", "provider": "aws", "account_identifier": "111122223333",
                     "service_name": "Amazon Simple Storage Service", "region": "us-east-1",
                     "usage_quantity": "5", "usage_unit": "GB-Mo", "cost_amount": "3.25", "currency": "USD",
                     "source_type": "aws_cost_explorer"},
                ]  # fmt: skip

        first = ING.sync_from_adapter(self.conn, FakeAws(), "aws", "2025-06-01", "2025-06-02", self.uid)
        self.assertEqual((first["status"], first["rows_inserted"]), ("succeeded", 2))
        again = ING.sync_from_adapter(self.conn, FakeAws(), "aws", "2025-06-01", "2025-06-02", self.uid)
        self.assertEqual((again["rows_inserted"], again["rows_duplicate"]), (0, 2))
        row = (
            self.conn.execute(text("SELECT status, last_sync_status FROM cloud_integrations WHERE provider = 'aws'"))
            .mappings()
            .first()
        )
        self.assertEqual((row["status"], row["last_sync_status"]), ("connected", "succeeded"))
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records WHERE is_synthetic"), 0)
        self.assertEqual(D.cost_summary(self.conn, None, None)["data_origin"], "provider")

    def test_provider_sync_failure_is_sanitised_and_recorded(self):
        class Boom:
            def fetch_costs(self, start, end):
                raise RuntimeError("secret-token-abc123 AccessDenied")

        with self.assertRaises(ING.SyncError) as cm:
            ING.sync_from_adapter(self.conn, Boom(), "aws", "2025-06-01", "2025-06-02", self.uid)
        self.assertNotIn("abc123", str(cm.exception))
        self.assertIn("RuntimeError", str(cm.exception))
        self.assertEqual(
            n(self.conn, "SELECT last_sync_status FROM cloud_integrations WHERE provider = 'aws'"), "failed"
        )
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records"), 0)

    def test_event_ingest_dedup_and_validation(self):
        ev = {
            "event_id": "e-1",
            "provider": "aws",
            "service": "Lambda",
            "environment": "prod",
            "severity": "error",
            "event_type": "throttle",
            "timestamp": "2025-03-05T10:00:00Z",
            "message": "limit reached",
            "correlation_id": "c-1",
            "metadata": {"region": "us-east-1"},
        }
        out = ING.ingest_events(self.conn, [ev, dict(ev), {**ev, "event_id": "e-2", "severity": "bogus"}])
        self.assertEqual((out["created"], out["duplicates"], out["rejected"]), (1, 1, 1))
        self.assertEqual([r["status"] for r in out["results"]], ["created", "duplicate", "rejected"])
        again = ING.ingest_events(self.conn, [ev])
        self.assertEqual((again["created"], again["duplicates"]), (0, 1))
        self.assertEqual(n(self.conn, "SELECT count(*) FROM operational_events"), 1)
        with self.assertRaises(ValueError):
            ING.ingest_events(self.conn, [ev] * 501)

    def test_demo_load_is_idempotent_and_flags_synthetic(self):
        self.load_demo()
        again = self.load_demo()
        self.assertEqual(again["costs"]["rows_inserted"], 0)
        self.assertEqual(again["events"]["created"], 0)
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records WHERE NOT is_synthetic"), 0)
        self.assertEqual(n(self.conn, "SELECT status FROM cloud_integrations WHERE provider = 'demo'"), "connected")

    # ---- detection, alerts, recommendations ---------------------------------------------------------------
    def test_detection_finds_injected_spikes_and_rerun_creates_no_duplicates(self):
        self.load_demo()
        r1 = DET.run_detection(self.conn)
        self.assertEqual(
            (r1["status"], r1["detected"], r1["new"], r1["alerts_created"], r1["recommendations_created"]),
            ("ok", 4, 4, 4, 4),
        )
        truth = json.loads((SAMPLE / "GROUND_TRUTH.json").read_text())["injected_anomalies"]
        found = {
            (r["provider"], r["service_name"], r["usage_date"].isoformat())
            for r in self.conn.execute(text("SELECT provider, service_name, usage_date FROM anomalies"))
            .mappings()
            .all()
        }
        self.assertEqual(found, {(t["provider"], t["service"], t["date"]) for t in truth})
        r2 = DET.run_detection(self.conn)  # re-run: everything suppressed
        self.assertEqual((r2["detected"], r2["new"], r2["suppressed_duplicates"], r2["alerts_created"]), (4, 0, 4, 0))
        for table in ("anomalies", "alerts", "recommendations"):
            self.assertEqual(n(self.conn, f"SELECT count(*) FROM {table}"), 4)

    def test_events_are_linked_to_alerts_and_late_events_picked_up(self):
        self.load_demo()
        DET.run_detection(self.conn)
        linked = n(self.conn, "SELECT count(*) FROM alert_events")
        self.assertGreaterEqual(linked, 8)  # 2 injected events per spike
        ING.ingest_events(
            self.conn,
            [
                {
                    "event_id": "late-1",
                    "provider": "aws",
                    "service": "EC2",
                    "environment": "prod",
                    "severity": "error",
                    "event_type": "scaling",
                    "timestamp": "2025-02-14T23:00:00Z",
                    "message": "late event",
                }
            ],
        )
        DET.run_detection(self.conn)
        self.assertEqual(n(self.conn, "SELECT count(*) FROM alert_events"), linked + 1)

    def test_detection_config_overrides_and_validation(self):
        self.load_demo()
        with self.assertRaises(ValueError):
            DET.run_detection(self.conn, {"nonsense": 1})
        with self.assertRaises(ValueError):
            DET.run_detection(self.conn, {"window_days": 1})
        res = DET.run_detection(self.conn, {"method": "isolation_forest"})
        self.assertEqual(res["config"]["method"], "isolation_forest")
        self.assertEqual(res["new"], 4)  # distinct fingerprint per method

    def test_detection_with_no_data(self):
        res = DET.run_detection(self.conn)
        self.assertEqual(res["status"], "no_data")

    def test_recommendation_traceable_to_anomaly(self):
        self.load_demo()
        DET.run_detection(self.conn)
        row = (
            self.conn.execute(
                text(
                    "SELECT r.summary, r.requires_human_review, r.source, r.evidence_json, a.observed_value "
                    "FROM recommendations r JOIN anomalies a ON a.id = r.anomaly_id WHERE a.service_name = 'Lambda'"
                )
            )
            .mappings()
            .first()
        )
        facts = {
            e["fact"]: e["value"]
            for e in (
                row["evidence_json"] if isinstance(row["evidence_json"], list) else json.loads(row["evidence_json"])
            )
        }
        self.assertAlmostEqual(facts["observed_cost"], float(row["observed_value"]), places=2)
        self.assertEqual(row["source"], "rules")
        self.assertTrue(row["requires_human_review"])  # critical => human review

    def test_forecast_persisted_with_evaluation_and_warnings(self):
        self.load_demo()
        res = DET.run_forecast_job(self.conn, 14, self.uid)
        self.assertEqual(res["status"], "ok")
        stored = (
            self.conn.execute(
                text("SELECT status, mae, horizon_days, is_synthetic FROM forecast_runs WHERE id = :i"),
                {"i": res["id"]},
            )
            .mappings()
            .first()
        )
        self.assertEqual((stored["status"], stored["horizon_days"], bool(stored["is_synthetic"])), ("ok", 14, True))
        self.assertGreater(float(stored["mae"]), 0)

    def test_forecast_with_too_little_data(self):
        csv_head = (SAMPLE / "synthetic_costs.csv").read_text().splitlines()[:12]
        ING.ingest_cost_csv(self.conn, ("\n".join(csv_head) + "\n").encode(), "small.csv", self.uid)
        res = DET.run_forecast_job(self.conn, 7, self.uid)
        self.assertEqual(res["status"], "insufficient_data")
        self.assertTrue(res["warnings"])

    # ---- alert / incident lifecycle -----------------------------------------------------------------------
    def first_alert(self):
        self.load_demo()
        DET.run_detection(self.conn)
        return n(self.conn, "SELECT id FROM alerts ORDER BY id LIMIT 1")

    def test_alert_lifecycle_and_persistence(self):
        aid = self.first_alert()
        a = A.acknowledge(self.conn, aid, self.uid)
        self.assertEqual(a["status"], "acknowledged")
        self.assertEqual(a["acknowledged_by"], self.uid)
        again = A.acknowledge(self.conn, aid, self.uid)  # idempotent
        self.assertEqual(again["acknowledged_at"], a["acknowledged_at"])
        note = A.add_note(self.conn, self.uid, "Checked autoscaling group; rolled back.", alert_id=aid)
        self.assertTrue(note["id"])
        r = A.resolve(self.conn, aid, self.uid)
        self.assertEqual((r["status"], len(r["notes"])), ("resolved", 1))
        self.assertIsNotNone(r["resolved_at"])
        self.assertEqual(A.resolve(self.conn, aid, self.uid)["status"], "resolved")  # idempotent
        with self.assertRaises(A.Conflict):
            A.acknowledge(self.conn, aid, self.uid)
        with self.assertRaises(A.NotFound):
            A.resolve(self.conn, 999999, self.uid)
        fresh = support.make_conn()  # a second connection sees the persisted state
        self.assertEqual(
            fresh.execute(text("SELECT status FROM alerts WHERE id = :i"), {"i": aid}).scalar_one(), "resolved"
        )
        fresh.close()

    def test_alert_detail_contains_anomaly_recommendation_events(self):
        aid = self.first_alert()
        d = A.get_alert(self.conn, aid)
        self.assertIsNotNone(d["anomaly"])
        self.assertIsNotNone(d["recommendation"])
        self.assertGreaterEqual(len(d["events"]), 1)

    def test_note_validation(self):
        aid = self.first_alert()
        for bad in ("", "   ", "x" * 4001):
            with self.assertRaises(ValueError):
                A.add_note(self.conn, self.uid, bad, alert_id=aid)
        with self.assertRaises(A.NotFound):
            A.add_note(self.conn, self.uid, "ok", alert_id=424242)

    def test_incident_lifecycle(self):
        self.first_alert()
        ids = [r[0] for r in self.conn.execute(text("SELECT id FROM alerts ORDER BY id")).all()][:2]
        inc = A.create_incident(self.conn, self.uid, "Cost spike investigation", "high", "Two spikes", ids)
        self.assertEqual((inc["status"], len(inc["alerts"])), ("open", 2))
        self.assertGreaterEqual(len(inc["events"]), 1)
        A.add_note(self.conn, self.uid, "Owner assigned.", incident_id=inc["id"])
        self.assertEqual(A.update_incident_status(self.conn, inc["id"], "investigating")["status"], "investigating")
        done = A.update_incident_status(self.conn, inc["id"], "resolved")
        self.assertIsNotNone(done["closed_at"])
        self.assertEqual(A.update_incident_status(self.conn, inc["id"], "closed")["status"], "closed")
        with self.assertRaises(A.Conflict):
            A.update_incident_status(self.conn, inc["id"], "open")
        with self.assertRaises(A.NotFound):
            A.create_incident(self.conn, self.uid, "Bad incident", "low", None, [999999])
        with self.assertRaises(ValueError):
            A.create_incident(self.conn, self.uid, "x", "low", None, [])

    # ---- dashboard ----------------------------------------------------------------------------------------
    def test_dashboard_numbers_match_raw_sql(self):
        self.load_demo()
        DET.run_detection(self.conn)
        s = D.cost_summary(self.conn, date(2025, 3, 1), date(2025, 3, 31))
        raw = float(
            n(
                self.conn,
                "SELECT sum(cost_amount) FROM cost_records WHERE usage_date BETWEEN '2025-03-01' AND '2025-03-31'",
            )
        )
        prev = float(
            n(
                self.conn,
                "SELECT sum(cost_amount) FROM cost_records WHERE usage_date BETWEEN '2025-01-29' AND '2025-02-28'",
            )
        )
        self.assertAlmostEqual(s["total_cost"], raw, places=1)
        self.assertEqual(s["previous_period"], {"from": "2025-01-29", "to": "2025-02-28"})
        self.assertAlmostEqual(s["previous_period_total"], prev, places=1)
        self.assertAlmostEqual(s["change_percent"], (raw - prev) / prev * 100, places=1)
        self.assertEqual(s["data_origin"], "synthetic")
        self.assertAlmostEqual(sum(x["cost"] for x in s["by_provider"]), raw, delta=1.0)
        self.assertEqual({x["name"] for x in s["by_provider"]}, {"aws", "azure"})

    def test_default_period_anchors_to_latest_data_not_today(self):
        self.load_demo()
        s = D.cost_summary(self.conn, None, None)
        self.assertEqual(s["period"]["to"], "2025-04-30")
        self.assertEqual(s["period"]["days"], 30)

    def test_empty_database_dashboard_is_safe(self):
        d = D.dashboard(self.conn, None, None)
        self.assertFalse(d["summary"]["has_data"])
        self.assertEqual(d["summary"]["data_origin"], "none")
        self.assertEqual(d["unresolved_alerts"]["total"], 0)
        self.assertEqual(D.timeseries(self.conn, None, None)["points"], [])

    def test_timeseries_grouping_and_granularity(self):
        self.load_demo()
        daily = D.timeseries(self.conn, date(2025, 1, 1), date(2025, 1, 31), "day", "provider")
        self.assertEqual(len(daily["points"]), 31 * 2)
        monthly = D.timeseries(self.conn, date(2025, 1, 1), date(2025, 4, 30), "month", "none")
        self.assertEqual(
            [p["period"] for p in monthly["points"]], ["2025-01-01", "2025-02-01", "2025-03-01", "2025-04-01"]
        )
        with self.assertRaises(ValueError):
            D.timeseries(self.conn, None, None, "week")
        with self.assertRaises(ValueError):
            D.timeseries(self.conn, None, None, "day", "user; DROP TABLE users")

    def test_dashboard_reports_ingestion_health_and_alert_counts(self):
        self.load_demo()
        DET.run_detection(self.conn)
        d = D.dashboard(self.conn, None, None)
        self.assertEqual(d["unresolved_alerts"]["total"], 4)
        self.assertEqual(d["anomalies"]["total"], 1)  # default window = last 30 days of data; only the Apr-10 S3 spike
        self.assertEqual(d["ingestion_health"]["last_run"]["status"], "succeeded")
        self.assertTrue(d["recent_events"])

    # ---- operator CLI / migration wiring --------------------------------------------------------------------
    def test_create_user_hashes_password_and_rejects_bad_input(self):
        from app.cli import create_user
        from app.core.security import verify_password

        uid = create_user(self.conn, "Ops@Example.com", "Str0ng-Enough-Pass", "readonly")
        row = (
            self.conn.execute(
                text(
                    "SELECT email, password_hash, r.name AS role FROM users u JOIN roles r "
                    "ON r.id = u.role_id WHERE u.id = :i"
                ),
                {"i": uid},
            )
            .mappings()
            .first()
        )
        self.assertEqual((row["email"], row["role"]), ("ops@example.com", "readonly"))
        self.assertNotIn("Str0ng", row["password_hash"])
        self.assertTrue(verify_password("Str0ng-Enough-Pass", row["password_hash"]))
        self.assertEqual(n(self.conn, "SELECT count(*) FROM audit_events WHERE action = 'user.create'"), 1)
        for args in (
            ("ops@example.com", "Str0ng-Enough-Pass", "admin"),  # duplicate (case-insensitive)
            ("new@example.com", "weak", "admin"),
            ("not-an-email", "Str0ng-Enough-Pass", "admin"),
            ("new@example.com", "Str0ng-Enough-Pass", "superuser"),
        ):
            with self.assertRaises(ValueError):
                create_user(self.conn, *args)

    def test_migration_points_at_the_tested_schema_file(self):
        mig = (ROOT / "apps" / "api" / "alembic" / "versions" / "0001_initial_schema.py").read_text()
        self.assertIn('parents[2] / "db" / "schema.sql"', mig)
        self.assertTrue((ROOT / "apps" / "api" / "db" / "schema.sql").exists())

    # ---- list / filter / sort builders --------------------------------------------------------------------
    def page(self, cols, frm, lst):
        return L.fetch_page(self.conn, cols, frm, lst)

    def test_cost_listing_filters_sort_pagination(self):
        self.load_demo()
        lst = L.cost_listing(
            date_from="2025-02-01",
            date_to="2025-02-28",
            provider="aws",
            service="EC2",
            region=None,
            source_type=None,
            synthetic=True,
            q=None,
            sort_by="cost",
            sort_dir="desc",
            page=2,
            page_size=10,
        )
        out = self.page("*", "cost_records", lst)
        self.assertEqual((out["total"], len(out["items"]), out["page"]), (56, 10, 2))  # 28 days x 2 regions
        costs = [float(i["cost_amount"]) for i in out["items"]]
        self.assertEqual(costs, sorted(costs, reverse=True))
        top = self.page(
            "*",
            "cost_records",
            L.cost_listing("2025-02-01", "2025-02-28", "aws", "EC2", None, None, None, None, "cost", "desc", 1, 1),
        )["items"][0]
        self.assertEqual(top["usage_date"], date(2025, 2, 14))  # the injected spike is the costliest EC2 row

    def test_listing_rejects_bad_input(self):
        base = dict(
            date_from=None,
            date_to=None,
            provider=None,
            service=None,
            region=None,
            source_type=None,
            synthetic=None,
            q=None,
            sort_by=None,
            sort_dir=None,
            page=1,
            page_size=25,
        )
        for patch in (
            {"provider": "gcp"},
            {"sort_by": "password_hash"},
            {"page_size": 1000},
            {"page": 0},
            {"date_from": "yesterday"},
            {"date_from": "2025-02-02", "date_to": "2025-02-01"},
            {"sort_dir": "up"},
        ):
            with self.assertRaises(qu.QueryError, msg=str(patch)):
                L.cost_listing(**{**base, **patch})

    def test_sql_injection_attempts_are_inert(self):
        self.load_demo()
        for evil in ("'; DROP TABLE cost_records; --", "x' OR '1'='1", "%", "\\"):
            lst = L.cost_listing(None, None, None, evil, None, None, None, evil, None, None, 1, 25)
            self.page("*", "cost_records", lst)
        self.assertEqual(n(self.conn, "SELECT count(*) FROM cost_records"), 1320)

    def test_like_wildcards_are_escaped(self):
        self.load_demo()
        lst = L.cost_listing(None, None, None, None, None, None, None, "%", None, None, 1, 25)
        self.assertEqual(self.page("*", "cost_records", lst)["total"], 0)  # '%' must not match everything

    def test_event_search_fulltext_and_filters(self):
        self.load_demo()
        lst = L.event_listing(
            date_from=None,
            date_to=None,
            severity=None,
            provider="aws",
            service=None,
            environment=None,
            event_type=None,
            correlation_id=None,
            q="throttle",
            sort_by=None,
            sort_dir=None,
            page=1,
            page_size=50,
        )
        out = self.page("id, event_type, service", "operational_events", lst)
        self.assertGreaterEqual(out["total"], 1)
        self.assertTrue(all(i["event_type"] == "throttle" or "throttle" in i["service"].lower() for i in out["items"]))
        by_sev = L.event_listing(None, None, "error", None, None, None, None, None, None, "severity", "desc", 1, 50)
        sevs = {i["severity"] for i in self.page("severity", "operational_events", by_sev)["items"]}
        self.assertEqual(sevs, {"error"})

    def test_alert_listing_status_and_severity_sort(self):
        aid = self.first_alert()
        A.resolve(self.conn, aid, self.uid)
        unresolved = L.alert_listing(None, None, None, "unresolved", None, None, None, "severity", "desc", 1, 25)
        out = self.page("id, severity, status", "alerts", unresolved)
        self.assertEqual(out["total"], 3)
        ranks = {"low": 1, "medium": 2, "high": 3, "critical": 4}
        self.assertEqual(
            [ranks[i["severity"]] for i in out["items"]],
            sorted((ranks[i["severity"]] for i in out["items"]), reverse=True),
        )

    def test_recommendation_and_anomaly_listings(self):
        self.load_demo()
        DET.run_detection(self.conn)
        rl = L.recommendation_listing(None, None, "aws", None, True, None, None, "severity", "desc", 1, 25)
        out = self.page(
            "r.id, r.service_name, a.severity", "recommendations r JOIN anomalies a ON a.id = r.anomaly_id", rl
        )
        self.assertEqual({i["service_name"] for i in out["items"]}, {"EC2", "Lambda", "S3"})
        al = L.anomaly_listing(None, None, "critical", None, None, None, None, None, "score", "desc", 1, 25)
        crit = self.page("*", "anomalies", al)
        self.assertEqual({i["service_name"] for i in crit["items"]}, {"EC2", "Lambda"})

    def test_fetch_all_respects_filters_for_export(self):
        self.load_demo()
        lst = L.cost_listing("2025-03-01", "2025-03-02", "azure", None, None, None, None, None, None, None, 1, 25)
        rows = L.fetch_all(self.conn, "*", "cost_records", lst)
        self.assertEqual(len(rows), 10)  # 5 azure series x 2 days
        self.assertTrue(all(r["provider"] == "azure" for r in rows))
        self.assertTrue(all(date(2025, 3, 1) <= r["usage_date"] <= date(2025, 3, 2) for r in rows))


if __name__ == "__main__":
    unittest.main()
