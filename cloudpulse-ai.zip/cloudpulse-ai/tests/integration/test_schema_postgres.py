"""Database integration tests: apply schema.sql to a real PostgreSQL and exercise constraints.

Requires a reachable PostgreSQL and the `psql` client. Set CLOUDPULSE_TEST_DSN, e.g.
  CLOUDPULSE_TEST_DSN="postgresql://postgres@127.0.0.1:5433/cloudpulse_test" python -m unittest ...
The test creates and drops its own scratch schema database objects inside a throwaway database.
Skipped (not failed) when the DSN or psql is unavailable.
"""

import csv
import os
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "services" / "ingestion"))
from cloudpulse_ingestion import parse_cost_csv  # noqa: E402

DSN = os.environ.get("CLOUDPULSE_TEST_DSN")
SCHEMA = ROOT / "apps" / "api" / "db" / "schema.sql"


def psql(sql=None, file=None, check=True):
    cmd = ["psql", DSN, "-v", "ON_ERROR_STOP=1", "-X", "-q", "-t", "-A"]
    cmd += ["-f", str(file)] if file else ["-c", sql]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise AssertionError(p.stderr.strip())
    return p


@unittest.skipUnless(DSN and shutil.which("psql"), "needs CLOUDPULSE_TEST_DSN and psql")
class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        psql("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
        psql(file=SCHEMA)

    def fails(self, sql, fragment):
        p = psql(sql, check=False)
        self.assertNotEqual(p.returncode, 0, f"expected failure: {sql}")
        self.assertIn(fragment, p.stderr)

    def test_seed_rows_present(self):
        self.assertEqual(psql("SELECT count(*) FROM roles").stdout.strip(), "2")
        out = psql("SELECT provider||':'||enabled FROM cloud_integrations ORDER BY provider").stdout.split()
        self.assertEqual(out, ["aws:false", "azure:false", "demo:true"])  # cloud integrations disabled by default

    def test_cost_load_is_idempotent_via_row_hash(self):
        res = parse_cost_csv((ROOT / "data" / "sample" / "synthetic_costs.csv").read_bytes())
        tmp = Path(os.environ.get("TMPDIR", "/tmp")) / "cp_cost_load.csv"
        with open(tmp, "w", newline="") as f:
            w = csv.writer(f)
            for r in res.valid_rows:
                w.writerow(
                    [
                        r["usage_date"],
                        r["provider"],
                        r["account_identifier"],
                        r["service_name"],
                        r["region"],
                        r["usage_quantity"],
                        r["usage_unit"],
                        r["cost_amount"],
                        r["currency"],
                        r["source_type"],
                        "t",
                        r["row_hash"],
                    ]
                )
        script = Path(tmp).with_suffix(".sql")
        script.write_text(
            "CREATE TEMP TABLE stg (usage_date date, provider text, account_identifier text, service_name text,"
            " region text, usage_quantity numeric, usage_unit text, cost_amount numeric, currency char(3),"
            " source_type text, is_synthetic boolean, row_hash char(64));\n"
            f"\\copy stg FROM '{tmp}' CSV\n"
            "INSERT INTO cost_records (usage_date,provider,account_identifier,service_name,region,"
            "usage_quantity,usage_unit,cost_amount,currency,source_type,is_synthetic,row_hash) "
            "SELECT usage_date,provider,account_identifier,service_name,region,usage_quantity,usage_unit,"
            "cost_amount,currency,source_type,is_synthetic,row_hash FROM stg "
            "ON CONFLICT (row_hash) DO NOTHING;\n"
        )
        psql("TRUNCATE cost_records RESTART IDENTITY CASCADE;")
        psql(file=script)
        first = int(psql("SELECT count(*) FROM cost_records").stdout)
        psql(file=script)  # second upload of the same file
        second = int(psql("SELECT count(*) FROM cost_records").stdout)
        self.assertEqual((first, second), (1320, 1320))

    def test_synthetic_flag_must_match_source(self):
        self.fails(
            "INSERT INTO cost_records (usage_date,provider,account_identifier,service_name,region,"
            "usage_quantity,usage_unit,cost_amount,currency,source_type,is_synthetic,row_hash) VALUES "
            "('2025-01-01','aws','a','EC2','us-east-1',1,'Hrs',1,'USD','synthetic',false,repeat('x',64))",
            "violates check constraint",
        )

    def test_lowercase_currency_rejected(self):
        self.fails(
            "INSERT INTO cost_records (usage_date,provider,account_identifier,service_name,region,"
            "usage_quantity,usage_unit,cost_amount,currency,source_type,is_synthetic,row_hash) VALUES "
            "('2025-01-01','aws','a','EC2','us-east-1',1,'Hrs',1,'usd','manual_csv',false,repeat('y',64))",
            "violates check constraint",
        )

    def test_event_dedup_unique_and_fulltext_search(self):
        ins = (
            "INSERT INTO operational_events (external_event_id,provider,service,environment,severity,event_type,"
            "event_timestamp,message) VALUES ('e1','aws','Lambda','prod','warning','throttle',now(),'Concurrent limit reached')"
        )
        psql("TRUNCATE operational_events RESTART IDENTITY CASCADE;")
        psql(ins)
        self.fails(ins, "uq_event_provider_extid")
        n = psql("SELECT count(*) FROM operational_events WHERE search_vector @@ plainto_tsquery('simple','throttle')")
        self.assertEqual(n.stdout.strip(), "1")

    def test_alert_fingerprint_is_unique_and_status_consistent(self):
        fp = "a" * 32
        psql("TRUNCATE alerts RESTART IDENTITY CASCADE;")
        ins = f"INSERT INTO alerts (fingerprint,title,severity,provider,service_name) VALUES ('{fp}','t','high','aws','EC2')"
        psql(ins)
        self.fails(ins, "alerts_fingerprint_key")
        self.fails("UPDATE alerts SET status='resolved' WHERE fingerprint='%s'" % fp, "violates check constraint")
        psql("UPDATE alerts SET status='resolved', resolved_at=now() WHERE fingerprint='%s'" % fp)

    def test_notes_need_a_parent_and_bounded_body(self):
        self.fails("INSERT INTO investigation_notes (body) VALUES ('orphan')", "violates check constraint")
        self.fails(
            "INSERT INTO investigation_notes (alert_id, body) VALUES (1, repeat('x', 4001))",
            "violates check constraint",
        )

    def test_audit_events_are_append_only(self):
        psql("INSERT INTO audit_events (action) VALUES ('test.insert')")
        self.fails("UPDATE audit_events SET action='tampered'", "append-only")
        self.fails("DELETE FROM audit_events", "append-only")

    def test_foreign_key_and_cascade_behaviour(self):
        self.fails("INSERT INTO users (email,password_hash,role_id) VALUES ('x@y.z','h',99)", "foreign key")
        psql("DELETE FROM users;")  # not TRUNCATE ... CASCADE: that would also wipe seeded cloud_integrations
        psql("INSERT INTO users (email,password_hash,role_id) VALUES ('Admin@Example.com','h',1)")
        self.fails(
            "INSERT INTO users (email,password_hash,role_id) VALUES ('admin@example.com','h',1)", "uq_users_email_lower"
        )

    def test_retention_function_purges_only_old_events(self):
        psql("TRUNCATE operational_events RESTART IDENTITY CASCADE;")
        psql(
            "INSERT INTO operational_events (external_event_id,provider,service,environment,severity,event_type,"
            "event_timestamp,message) VALUES ('old','aws','S3','prod','info','x',now()-interval '200 days','m'),"
            "('new','aws','S3','prod','info','x',now(),'m')"
        )
        self.assertEqual(psql("SELECT purge_old_events(90)").stdout.strip(), "1")
        self.assertEqual(psql("SELECT external_event_id FROM operational_events").stdout.strip(), "new")
        self.fails("SELECT purge_old_events(0)", "retain_days")

    def test_migration_is_reapplicable_only_on_clean_schema(self):
        self.fails("SELECT 1/0", "division by zero")  # sanity: failures propagate through the helper
        p = psql(file=SCHEMA, check=False)
        self.assertNotEqual(p.returncode, 0)  # second apply on a populated schema must not silently succeed


if __name__ == "__main__":
    unittest.main()
