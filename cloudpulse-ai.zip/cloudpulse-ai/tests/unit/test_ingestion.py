"""Unit tests for CSV validation, normalisation, deduplication and event validation."""

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "services" / "ingestion"))

from cloudpulse_ingestion import EventValidationError, csv_safe, parse_cost_csv, validate_event  # noqa: E402
from cloudpulse_ingestion.costs import MAX_FILE_BYTES, REQUIRED_COLUMNS  # noqa: E402

HEADER = ",".join(REQUIRED_COLUMNS)
GOOD = "2025-03-01,AWS,111122223333,Amazon EC2,US_East-1,10.5,Hrs,123.45,usd,synthetic"


def csv_bytes(*rows, header=HEADER):
    return ("\n".join([header, *rows]) + "\n").encode()


class CostCsvTests(unittest.TestCase):
    def test_valid_row_is_normalised(self):
        res = parse_cost_csv(csv_bytes(GOOD))
        self.assertTrue(res.ok)
        row = res.valid_rows[0]
        self.assertEqual(
            (row["provider"], row["service_name"], row["region"], row["currency"]), ("aws", "EC2", "us-east-1", "USD")
        )
        self.assertTrue(row["is_synthetic"])
        self.assertEqual(row["usage_date"].isoformat(), "2025-03-01")

    def test_same_file_twice_gives_identical_hashes(self):
        a = parse_cost_csv(csv_bytes(GOOD)).valid_rows[0]["row_hash"]
        b = parse_cost_csv(csv_bytes(GOOD)).valid_rows[0]["row_hash"]
        self.assertEqual(a, b)

    def test_cost_value_change_keeps_natural_key_hash(self):
        """Hash is the natural key, so a re-export with a corrected amount is a duplicate key, not a new row."""
        other = GOOD.replace("123.45", "999.99")
        self.assertEqual(
            parse_cost_csv(csv_bytes(GOOD)).valid_rows[0]["row_hash"],
            parse_cost_csv(csv_bytes(other)).valid_rows[0]["row_hash"],
        )

    def test_duplicate_rows_within_file_collapsed(self):
        res = parse_cost_csv(csv_bytes(GOOD, GOOD))
        self.assertEqual((res.rows_total, len(res.valid_rows)), (2, 1))

    def test_alias_normalisation_makes_equal_rows_equal(self):
        alt = GOOD.replace("Amazon EC2", "ec2")
        self.assertEqual(len(parse_cost_csv(csv_bytes(GOOD, alt)).valid_rows), 1)

    def test_missing_column_is_file_error(self):
        res = parse_cost_csv(csv_bytes(GOOD, header=HEADER.replace(",currency", "")))
        self.assertFalse(res.ok)
        self.assertIn("currency", res.file_error)

    def test_bad_rows_rejected_with_row_numbers_and_fields(self):
        bad_cost = GOOD.replace("123.45", "abc")
        bad_date = GOOD.replace("2025-03-01", "03/01/2025")
        bad_cur = GOOD.replace("usd", "dollars")
        res = parse_cost_csv(csv_bytes(GOOD, bad_cost, bad_date, bad_cur))
        self.assertEqual(len(res.valid_rows), 1)
        self.assertEqual(res.rows_rejected, 3)
        by_row = {(e.row, e.field) for e in res.errors}
        self.assertIn((3, "cost_amount"), by_row)
        self.assertIn((4, "usage_date"), by_row)
        self.assertIn((5, "currency"), by_row)

    def test_negative_quantity_and_unknown_provider_rejected(self):
        res = parse_cost_csv(csv_bytes(GOOD.replace("10.5", "-1"), GOOD.replace("AWS", "gcp")))
        self.assertEqual(res.rows_rejected, 2)

    def test_nan_and_infinity_rejected(self):
        res = parse_cost_csv(csv_bytes(GOOD.replace("123.45", "NaN"), GOOD.replace("123.45", "Infinity")))
        self.assertEqual(res.rows_rejected, 2)

    def test_negative_cost_credit_is_allowed(self):
        res = parse_cost_csv(csv_bytes(GOOD.replace("123.45", "-20.00")))
        self.assertEqual(len(res.valid_rows), 1)

    def test_empty_binary_and_oversize_rejected(self):
        self.assertFalse(parse_cost_csv(b"").ok)
        self.assertFalse(parse_cost_csv(b"a,b\x00c").ok)
        self.assertFalse(parse_cost_csv(b"x" * (MAX_FILE_BYTES + 1)).ok)

    def test_non_utf8_rejected(self):
        self.assertFalse(parse_cost_csv(b"\xff\xfe\x00\x01garbage").ok)

    def test_bom_is_tolerated(self):
        data = b"\xef\xbb\xbf" + csv_bytes(GOOD)
        self.assertTrue(parse_cost_csv(data).valid_rows)

    def test_error_list_is_capped(self):
        rows = [GOOD.replace("123.45", "x")] * 500
        res = parse_cost_csv(
            csv_bytes(*[r.replace("2025-03-01", f"2025-03-{i % 28 + 1:02d}") for i, r in enumerate(rows)])
        )
        self.assertLessEqual(len(res.errors), 200)
        self.assertTrue(res.errors_truncated)

    def test_shipped_sample_file_is_fully_valid(self):
        data = (ROOT / "data" / "sample" / "synthetic_costs.csv").read_bytes()
        res = parse_cost_csv(data)
        self.assertEqual((res.rows_total, len(res.valid_rows), res.rows_rejected), (1320, 1320, 0))
        self.assertTrue(all(r["is_synthetic"] for r in res.valid_rows))

    def test_csv_injection_neutralised(self):
        self.assertEqual(csv_safe("=SUM(A1)"), "'=SUM(A1)")
        self.assertEqual(csv_safe("@cmd"), "'@cmd")
        self.assertEqual(csv_safe("-5.25"), "-5.25")
        self.assertEqual(csv_safe("normal"), "normal")
        self.assertEqual(csv_safe(None), "")


def good_event(**over):
    e = {
        "event_id": "evt-1",
        "provider": "AWS",
        "service": "Lambda",
        "environment": "Staging",
        "severity": "Warning",
        "event_type": "throttle",
        "timestamp": "2025-03-02T10:15:00Z",
        "message": "limit reached",
        "correlation_id": "req-77",
        "metadata": {"region": "us-east-1"},
    }
    e.update(over)
    return e


class EventTests(unittest.TestCase):
    def test_valid_event_normalised(self):
        out = validate_event(good_event())
        self.assertEqual((out["provider"], out["environment"], out["severity"]), ("aws", "staging", "warning"))
        self.assertEqual(out["event_timestamp"].utcoffset().total_seconds(), 0)

    def test_naive_timestamp_assumed_utc_and_offsets_converted(self):
        self.assertEqual(validate_event(good_event(timestamp="2025-03-02T10:15:00"))["event_timestamp"].hour, 10)
        self.assertEqual(validate_event(good_event(timestamp="2025-03-02T10:15:00+02:00"))["event_timestamp"].hour, 8)

    def test_multiple_problems_reported_together(self):
        with self.assertRaises(EventValidationError) as ctx:
            validate_event(good_event(provider="gcp", severity="loud", timestamp="yesterday", event_id="bad id!"))
        fields = {p["field"] for p in ctx.exception.problems}
        self.assertEqual(fields, {"provider", "severity", "timestamp", "event_id"})

    def test_control_characters_stripped_and_message_capped(self):
        out = validate_event(good_event(message="hi\x00\x07 there" + "a" * 5000))
        self.assertNotIn("\x00", out["message"])
        self.assertLessEqual(len(out["message"]), 2000)

    def test_missing_message_rejected(self):
        with self.assertRaises(EventValidationError):
            validate_event(good_event(message="  "))

    def test_metadata_must_be_object_and_bounded(self):
        with self.assertRaises(EventValidationError):
            validate_event(good_event(metadata=["x"]))
        with self.assertRaises(EventValidationError):
            validate_event(good_event(metadata={"k": "v" * 9000}))


if __name__ == "__main__":
    unittest.main()
