import json
import os
import sys
import unittest
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "services" / "serverless"))
sys.path.insert(0, str(ROOT / "services" / "serverless" / "aws_lambda"))

import forwarder  # noqa: E402
import handler  # noqa: E402


class FakeS3:
    def __init__(self, objects):
        self.objects = objects

    def get_object(self, Bucket, Key):
        data = self.objects[(Bucket, Key)]
        return {"Body": type("B", (), {"read": lambda self_, n=-1: data[:n] if n >= 0 else data})()}


def recorder(responses):
    calls = []

    def send(req, timeout):
        calls.append(req)
        r = responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r

    return send, calls


class ForwarderTests(unittest.TestCase):
    def setUp(self):
        self._old = dict(os.environ)
        os.environ.update(CLOUDPULSE_API_URL="https://api.example.test/api/v1", INGEST_API_TOKEN="t" * 32)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old)

    def test_multipart_and_auth_header(self):
        send, calls = recorder([(201, b'{"status":"succeeded","run_id":7}')])
        out = forwarder.forward_csv("exports/a b.csv", b"a,b\n1,2\n", send)
        self.assertEqual(out["run_id"], 7)
        req = calls[0]
        self.assertEqual(req.full_url, "https://api.example.test/api/v1/ingestion/costs")
        self.assertEqual(req.get_header("Authorization"), "Bearer " + "t" * 32)
        self.assertIn(b'filename="a b.csv"', req.data)
        self.assertIn(b"a,b\n1,2\n", req.data)

    def test_filename_cannot_inject_headers(self):
        body, _ = forwarder.build_multipart('x"\r\nEvil: 1.csv', b"d")
        self.assertNotIn(b"\r\nEvil", body)

    def test_retries_5xx_then_succeeds(self):
        send, calls = recorder([(503, b"{}"), (200, b'{"status":"succeeded"}')])
        out = forwarder.forward_csv("a.csv", b"x", send, sleep=lambda s: None)
        self.assertEqual(out["status"], "succeeded")
        self.assertEqual(len(calls), 2)

    def test_does_not_retry_4xx(self):
        send, calls = recorder([(422, json.dumps({"error": {"message": "bad csv"}}).encode())])
        with self.assertRaisesRegex(forwarder.ForwardError, "bad csv"):
            forwarder.forward_csv("a.csv", b"x", send, sleep=lambda s: None)
        self.assertEqual(len(calls), 1)

    def test_gives_up_after_retries_on_network_errors(self):
        send, calls = recorder([urllib.error.URLError("x")] * 3)
        with self.assertRaisesRegex(forwarder.ForwardError, "giving up"):
            forwarder.forward_csv("a.csv", b"x", send, sleep=lambda s: None)
        self.assertEqual(len(calls), 3)

    def test_rejects_non_csv_oversize_and_insecure_url(self):
        with self.assertRaises(forwarder.ForwardError):
            forwarder.forward_csv("a.exe", b"x")
        with self.assertRaises(forwarder.ForwardError):
            forwarder.forward_csv("a.csv", b"x" * (forwarder.MAX_CSV_BYTES + 1))
        os.environ["CLOUDPULSE_API_URL"] = "http://evil.example.test/api/v1"
        with self.assertRaisesRegex(forwarder.ForwardError, "https"):
            forwarder.forward_csv("a.csv", b"x")

    def test_missing_config(self):
        os.environ.pop("INGEST_API_TOKEN")
        with self.assertRaises(forwarder.ForwardError):
            forwarder.forward_csv("a.csv", b"x")


class LambdaHandlerTests(unittest.TestCase):
    def setUp(self):
        self._old = dict(os.environ)
        os.environ.update(CLOUDPULSE_API_URL="https://api.example.test/api/v1", INGEST_API_TOKEN="t" * 32)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old)

    def test_s3_event_downloads_and_forwards(self):
        s3 = FakeS3({("raw", "cost exports/day 1.csv"): b"h\n1\n"})
        evt = {
            "Records": [
                {
                    "eventSource": "aws:s3",
                    "s3": {"bucket": {"name": "raw"}, "object": {"key": "cost+exports/day+1.csv", "size": 4}},
                }
            ]
        }
        send, calls = recorder([(201, b'{"status":"succeeded","run_id":3}')])
        out = handler.handler(evt, None, s3=s3, sender=send)
        self.assertEqual(out["processed"][0]["run_id"], 3)
        self.assertIn(b'filename="day 1.csv"', calls[0].data)

    def test_eventbridge_event_maps_and_forwards(self):
        evt = {
            "id": "abc-1",
            "source": "aws.cloudwatch",
            "detail-type": "CloudWatch Alarm State Change",
            "time": "2025-03-01T00:00:00Z",
            "region": "us-east-1",
            "account": "111122223333",
            "detail": {"alarmName": "HighCPU", "state": {"value": "ALARM"}},
        }
        send, calls = recorder([(201, b'{"created":1,"duplicates":0}')])
        out = handler.handler(evt, None, sender=send)
        self.assertEqual(out["created"], 1)
        sent = json.loads(calls[0].data)["events"][0]
        self.assertEqual(
            (sent["provider"], sent["service"], sent["severity"], sent["message"]),
            ("aws", "cloudwatch", "error", "HighCPU"),
        )

    def test_unknown_shape_fails_loudly(self):
        with self.assertRaises(forwarder.ForwardError):
            handler.handler({"foo": 1})


if __name__ == "__main__":
    unittest.main()
