"""Tests for the framework-independent API core: config, security, rate limiting, query helpers."""

import base64
import json
import sys
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.core import queryutil as q  # noqa: E402
from app.core.config import ConfigError, load_settings  # noqa: E402
from app.core.ratelimit import SlidingWindowLimiter  # noqa: E402
from app.core.security import (  # noqa: E402
    SessionError,
    create_session_token,
    csrf_ok,
    hash_password,
    validate_password_strength,
    verify_password,
    verify_session_token,
)

SECRET = "x" * 40


class PasswordTests(unittest.TestCase):
    def test_hash_verify_roundtrip_and_salting(self):
        h1, h2 = hash_password("Correct-Horse-9"), hash_password("Correct-Horse-9")
        self.assertNotEqual(h1, h2)  # random salt
        self.assertTrue(verify_password("Correct-Horse-9", h1))
        self.assertFalse(verify_password("correct-horse-9", h1))
        self.assertNotIn("Correct-Horse-9", h1)

    def test_malformed_hashes_never_raise(self):
        for bad in ("", "plain", "scrypt$1$2", "bcrypt$a$b$c$d$e", "scrypt$x$y$z$!!$??"):
            self.assertFalse(verify_password("anything", bad))

    def test_strength_policy(self):
        self.assertTrue(validate_password_strength("short1A"))
        self.assertTrue(validate_password_strength("alllowercase1234"))
        self.assertEqual(validate_password_strength("Str0ng-Enough-Pass"), [])


class SessionTests(unittest.TestCase):
    def test_roundtrip(self):
        tok = create_session_token(SECRET, 7, "admin", 60, now=1000)
        s = verify_session_token(SECRET, tok, now=1010)
        self.assertEqual((s.user_id, s.role), (7, "admin"))

    def test_expired(self):
        tok = create_session_token(SECRET, 7, "admin", 60, now=1000)
        with self.assertRaises(SessionError) as ctx:
            verify_session_token(SECRET, tok, now=1061)
        self.assertEqual(ctx.exception.reason, "expired")

    def test_tampered_payload_rejected(self):
        tok = create_session_token(SECRET, 7, "readonly", 60, now=1000)
        body, sig = tok.split(".")
        data = json.loads(base64.urlsafe_b64decode(body + "=="))
        data["role"] = "admin"
        forged = base64.urlsafe_b64encode(json.dumps(data).encode()).rstrip(b"=").decode() + "." + sig
        with self.assertRaises(SessionError) as ctx:
            verify_session_token(SECRET, forged, now=1010)
        self.assertEqual(ctx.exception.reason, "invalid")

    def test_wrong_secret_and_garbage_rejected(self):
        tok = create_session_token(SECRET, 7, "admin", 60, now=1000)
        for bad_tok, secret in ((tok, "y" * 40), ("garbage", SECRET), ("a.b", SECRET), ("", SECRET)):
            with self.assertRaises(SessionError):
                verify_session_token(secret, bad_tok, now=1010)

    def test_csrf_check(self):
        s = verify_session_token(SECRET, create_session_token(SECRET, 1, "admin", 60, now=0), now=1)
        self.assertTrue(csrf_ok(s, s.csrf))
        self.assertFalse(csrf_ok(s, "nope"))
        self.assertFalse(csrf_ok(s, None))
        self.assertFalse(csrf_ok(s, ""))


class RateLimiterTests(unittest.TestCase):
    def test_blocks_after_limit_and_recovers(self):
        t = [0.0]
        lim = SlidingWindowLimiter(3, 10, clock=lambda: t[0])
        self.assertTrue(all(lim.check("ip")[0] for _ in range(3)))
        ok, retry = lim.check("ip")
        self.assertFalse(ok)
        self.assertGreaterEqual(retry, 1)
        self.assertTrue(lim.check("other")[0])  # independent keys
        t[0] = 10.5
        self.assertTrue(lim.check("ip")[0])

    def test_reset(self):
        lim = SlidingWindowLimiter(1, 60)
        lim.check("k")
        self.assertFalse(lim.check("k")[0])
        lim.reset("k")
        self.assertTrue(lim.check("k")[0])

    def test_invalid_params(self):
        with self.assertRaises(ValueError):
            SlidingWindowLimiter(0, 1)


class ConfigTests(unittest.TestCase):
    def test_development_defaults_load(self):
        s = load_settings({})
        self.assertEqual((s.app_env, s.default_data_mode, s.llm_provider), ("development", "demo", ""))
        self.assertEqual(s.aws_role_arn, "")  # cloud integrations unconfigured by default

    def test_production_refuses_insecure_settings(self):
        with self.assertRaises(ConfigError):
            load_settings({"APP_ENV": "production"})
        with self.assertRaises(ConfigError):
            load_settings({"APP_ENV": "production", "SECRET_KEY": "k" * 40})  # cookie not secure
        with self.assertRaises(ConfigError):
            load_settings(
                {"APP_ENV": "production", "SECRET_KEY": "k" * 40, "COOKIE_SECURE": "true", "CORS_ORIGINS": "*"}
            )
        ok = load_settings({"APP_ENV": "production", "SECRET_KEY": "k" * 40, "COOKIE_SECURE": "true"})
        self.assertTrue(ok.is_production)

    def test_bad_values_rejected(self):
        with self.assertRaises(ConfigError):
            load_settings({"APP_ENV": "staging"})
        with self.assertRaises(ConfigError):
            load_settings({"DEFAULT_DATA_MODE": "gcp"})


class QueryUtilTests(unittest.TestCase):
    ALLOWED = {"date": "usage_date", "cost": "cost_amount"}

    def test_pagination_bounds(self):
        self.assertEqual(q.parse_page(None, None), (1, 25))
        for p, s in ((0, 10), (1, 0), (1, 201), (-3, 10)):
            with self.assertRaises(q.QueryError):
                q.parse_page(p, s)

    def test_sort_is_allow_listed_and_stable(self):
        self.assertEqual(q.parse_sort("cost", "asc", self.ALLOWED, "date"), "cost_amount ASC, id ASC")
        self.assertEqual(q.parse_sort(None, None, self.ALLOWED, "date"), "usage_date DESC, id DESC")
        for bad in ("cost; DROP TABLE users", "password_hash"):
            with self.assertRaises(q.QueryError):
                q.parse_sort(bad, "asc", self.ALLOWED, "date")
        with self.assertRaises(q.QueryError):
            q.parse_sort("cost", "sideways", self.ALLOWED, "date")

    def test_dates_and_ranges(self):
        self.assertEqual(q.parse_date("d", "2025-03-01"), date(2025, 3, 1))
        self.assertIsNone(q.parse_date("d", ""))
        with self.assertRaises(q.QueryError):
            q.parse_date("d", "03/01/2025")
        with self.assertRaises(q.QueryError):
            q.check_range(date(2025, 3, 2), date(2025, 3, 1))

    def test_pick_and_where_builder(self):
        self.assertEqual(q.pick("severity", " HIGH ", {"low", "high"}), "high")
        with self.assertRaises(q.QueryError):
            q.pick("severity", "urgent", {"low", "high"})
        w = q.Where().add("provider = :p", p="aws").add("usage_date >= :d", d=date(2025, 1, 1))
        self.assertEqual(w.sql(), "WHERE provider = :p AND usage_date >= :d")
        self.assertEqual(q.Where().sql(), "")

    def test_like_escaping(self):
        self.assertEqual(q.escape_like("50%_off\\"), "50\\%\\_off\\\\")


if __name__ == "__main__":
    unittest.main()
