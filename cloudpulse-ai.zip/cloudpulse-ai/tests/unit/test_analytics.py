"""Unit tests for anomaly detection, forecasting and recommendations.

Written with unittest so they run with `python -m unittest` and also under pytest.
"""

import json
import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "services" / "analytics"))

from cloudpulse_analytics import (  # noqa: E402
    DetectionConfig,
    ForecastConfig,
    build_recommendation,
    detect_anomalies,
    enrich_with_llm,
    run_forecast,
    validate_ai_output,
)

SAMPLE = ROOT / "data" / "sample"


def synthetic_series(days=60, base=100.0, seed=7, spikes=None, provider="aws", service="EC2"):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2025-01-01", periods=days, freq="D")
    vals = base * rng.normal(1.0, 0.03, days)
    for idx, mult in (spikes or {}).items():
        vals[idx] *= mult
    return pd.DataFrame({"usage_date": dates, "provider": provider, "service_name": service, "cost_amount": vals})


class AnomalyTests(unittest.TestCase):
    def test_normal_data_has_no_anomalies(self):
        self.assertEqual(detect_anomalies(synthetic_series()), [])

    def test_spike_is_detected_on_correct_day(self):
        df = synthetic_series(spikes={40: 3.0})
        found = detect_anomalies(df)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].usage_date, "2025-02-10")
        self.assertEqual(found[0].direction, "increase")
        self.assertGreater(found[0].score, 3.5)
        self.assertIn("robust_z", found[0].signals)
        self.assertIn("expected", found[0].explanation)

    def test_reproducible_results_and_fingerprints(self):
        df = synthetic_series(spikes={40: 3.0, 50: 4.0})
        a = [x.to_dict() for x in detect_anomalies(df)]
        b = [x.to_dict() for x in detect_anomalies(df.sample(frac=1.0, random_state=1))]  # shuffled input
        self.assertEqual(a, b)
        self.assertEqual(len({x["fingerprint"] for x in a}), len(a))

    def test_rerun_produces_same_fingerprints_for_alert_suppression(self):
        df = synthetic_series(spikes={40: 3.0})
        fp1 = [x.fingerprint for x in detect_anomalies(df)]
        fp2 = [x.fingerprint for x in detect_anomalies(df)]
        self.assertEqual(fp1, fp2)

    def test_insufficient_history_is_not_flagged(self):
        df = synthetic_series(days=5, spikes={4: 10.0})
        self.assertEqual(detect_anomalies(df), [])

    def test_small_absolute_change_ignored(self):
        df = synthetic_series(base=1.0, spikes={40: 3.0})  # 3x but only ~2 currency units
        self.assertEqual(detect_anomalies(df), [])

    def test_flat_series_does_not_divide_by_zero(self):
        df = synthetic_series()
        df["cost_amount"] = 100.0
        df.loc[40, "cost_amount"] = 300.0
        found = detect_anomalies(df)
        self.assertEqual([f.usage_date for f in found], ["2025-02-10"])

    def test_decreases_only_flagged_when_enabled(self):
        df = synthetic_series(spikes={40: 0.1})
        self.assertEqual(detect_anomalies(df), [])
        found = detect_anomalies(df, DetectionConfig(flag_decreases=True))
        self.assertEqual(found[0].direction, "decrease")

    def test_threshold_is_configurable(self):
        df = synthetic_series(spikes={40: 1.4})
        strict = detect_anomalies(df, DetectionConfig(z_threshold=3.5))
        loose = detect_anomalies(df, DetectionConfig(z_threshold=3.0, min_pct_change=10))
        self.assertLessEqual(len(strict), len(loose))
        self.assertGreaterEqual(len(loose), 1)

    def test_invalid_config_rejected(self):
        with self.assertRaises(ValueError):
            detect_anomalies(synthetic_series(), DetectionConfig(window_days=1))
        with self.assertRaises(ValueError):
            detect_anomalies(synthetic_series(), DetectionConfig(method="magic"))

    def test_missing_columns_rejected(self):
        with self.assertRaises(ValueError):
            detect_anomalies(pd.DataFrame({"usage_date": ["2025-01-01"]}))

    def test_severity_orders_with_magnitude(self):
        rank = {"low": 0, "medium": 1, "high": 2, "critical": 3}
        small = detect_anomalies(synthetic_series(base=300, spikes={40: 1.6}))
        big = detect_anomalies(synthetic_series(base=300, spikes={40: 8.0}))
        self.assertTrue(small and big)
        self.assertGreaterEqual(rank[big[0].severity], rank[small[0].severity])
        self.assertEqual(big[0].severity, "critical")

    def test_isolation_forest_is_reproducible_and_finds_big_spike(self):
        df = synthetic_series(days=90, spikes={70: 6.0})
        cfg = DetectionConfig(method="isolation_forest")
        a = [x.to_dict() for x in detect_anomalies(df, cfg)]
        b = [x.to_dict() for x in detect_anomalies(df, cfg)]
        self.assertEqual(a, b)
        self.assertIn("2025-03-12", [x["usage_date"] for x in a])

    def test_sample_dataset_ground_truth(self):
        """Every injected spike in the documented sample dataset must be found."""
        df = pd.read_csv(SAMPLE / "synthetic_costs.csv")
        truth = json.loads((SAMPLE / "GROUND_TRUTH.json").read_text())["injected_anomalies"]
        found = detect_anomalies(df)
        got = {(f.provider, f.service_name, f.usage_date) for f in found}
        for t in truth:
            self.assertIn((t["provider"], t["service"], t["date"]), got, f"missed {t}")
        # Documented behaviour: report how many extra flags there are rather than hide them.
        extra = got - {(t["provider"], t["service"], t["date"]) for t in truth}
        self.assertLessEqual(len(extra), 3, f"too many unexpected flags: {sorted(extra)}")


class ForecastTests(unittest.TestCase):
    def _weekly(self, days):
        dates = pd.date_range("2025-01-01", periods=days, freq="D")
        pattern = np.array([110, 112, 111, 109, 105, 80, 78], dtype=float)
        vals = np.array([pattern[d.dayofweek] for d in dates])
        return pd.DataFrame({"usage_date": dates, "cost_amount": vals})

    def test_too_little_data_returns_warning_and_no_forecast(self):
        res = run_forecast(self._weekly(10))
        self.assertEqual(res["status"], "insufficient_data")
        self.assertEqual(res["forecast"], [])
        self.assertTrue(res["warnings"])

    def test_empty_input(self):
        res = run_forecast(pd.DataFrame({"usage_date": [], "cost_amount": []}))
        self.assertEqual(res["status"], "insufficient_data")

    def test_perfect_weekly_pattern_has_zero_mae(self):
        res = run_forecast(self._weekly(90), ForecastConfig(horizon_days=14))
        self.assertEqual(res["status"], "ok")
        self.assertEqual(len(res["forecast"]), 14)
        self.assertEqual(res["evaluation"]["mae"], 0.0)
        self.assertTrue(res["evaluation"]["beats_naive_benchmark"])
        self.assertEqual(res["forecast"][0]["date"], "2025-04-01")

    def test_between_min_and_backtest_size_warns_not_backtested(self):
        res = run_forecast(self._weekly(35))
        self.assertEqual(res["status"], "ok")
        self.assertIsNone(res["evaluation"])
        self.assertTrue(any("not backtested" in w for w in res["warnings"]))

    def test_deterministic(self):
        df = self._weekly(90)
        self.assertEqual(run_forecast(df), run_forecast(df))

    def test_noisy_data_reports_nonzero_mae_and_band(self):
        rng = np.random.default_rng(3)
        df = self._weekly(100)
        df["cost_amount"] = df["cost_amount"] * rng.normal(1, 0.05, len(df))
        res = run_forecast(df)
        self.assertGreater(res["evaluation"]["mae"], 0)
        self.assertIsNotNone(res["forecast"][0]["upper"])

    def test_invalid_horizon(self):
        with self.assertRaises(ValueError):
            run_forecast(self._weekly(60), ForecastConfig(horizon_days=0))

    def test_sample_dataset_forecast_reports_evaluation(self):
        df = pd.read_csv(SAMPLE / "synthetic_costs.csv")
        res = run_forecast(df)
        self.assertEqual(res["status"], "ok")
        self.assertIsNotNone(res["evaluation"])
        self.assertIn("not a guarantee", res["evaluation"]["note"])


class RecommendationTests(unittest.TestCase):
    def setUp(self):
        self.anom = detect_anomalies(synthetic_series(spikes={40: 3.0}))[0].to_dict()

    def test_rule_recommendation_has_required_fields(self):
        rec = build_recommendation(self.anom)
        for k in (
            "summary",
            "evidence",
            "potential_impact",
            "confidence_note",
            "next_steps",
            "provider",
            "service_name",
            "generated_at",
            "requires_human_review",
        ):
            self.assertIn(k, rec)
        self.assertEqual(rec["source"], "rules")
        self.assertEqual(rec["anomaly_fingerprint"], self.anom["fingerprint"])
        facts = {e["fact"]: e["value"] for e in rec["evidence"]}
        self.assertEqual(facts["observed_cost"], self.anom["observed_value"])

    def test_llm_absent_returns_rules_only(self):
        rec = build_recommendation(self.anom)
        self.assertIs(enrich_with_llm(rec, None), rec)

    def test_valid_llm_output_is_attached_separately(self):
        class Good:
            def complete(self, prompt):
                assert "FACTS" in prompt
                return json.dumps({"explanation": "Likely a burst workload.", "caveats": ["Unverified."]})

        out = enrich_with_llm(build_recommendation(self.anom), Good())
        self.assertEqual(out["source"], "rules+llm")
        self.assertEqual(out["ai_explanation"]["explanation"], "Likely a burst workload.")
        self.assertNotIn("Likely a burst", out["summary"])  # measured facts stay separate

    def test_invalid_llm_output_falls_back(self):
        errors = []

        class Bad:
            def complete(self, prompt):
                return json.dumps({"explanation": "x", "caveats": [], "run": "terraform destroy"})

        rec = build_recommendation(self.anom)
        out = enrich_with_llm(rec, Bad(), on_error=errors.append)
        self.assertEqual(out["source"], "rules")
        self.assertIsNone(out["ai_explanation"])
        self.assertEqual(len(errors), 1)

    def test_llm_exception_falls_back(self):
        class Down:
            def complete(self, prompt):
                raise TimeoutError("provider unavailable")

        self.assertEqual(enrich_with_llm(build_recommendation(self.anom), Down())["source"], "rules")

    def test_secrets_are_redacted_from_prompt(self):
        seen = {}

        class Spy:
            def complete(self, prompt):
                seen["p"] = prompt
                return json.dumps({"explanation": "ok", "caveats": []})

        rec = build_recommendation(self.anom)
        rec["summary"] += " password=hunter2 AKIAABCDEFGHIJKLMNOP"
        enrich_with_llm(rec, Spy())
        self.assertNotIn("hunter2", seen["p"])
        self.assertNotIn("AKIAABCDEFGHIJKLMNOP", seen["p"])
        self.assertIn("[REDACTED]", seen["p"])

    def test_schema_validation_rejects_bad_shapes(self):
        for bad in (
            "[]",
            '{"explanation": "", "caveats": []}',
            '{"explanation": "a", "caveats": "no"}',
            '{"explanation": "a"}',
            "not json",
        ):
            with self.assertRaises(Exception):
                validate_ai_output(bad)


if __name__ == "__main__":
    unittest.main()
