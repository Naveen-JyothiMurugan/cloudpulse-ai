"""Test-only stand-in for SQLAlchemy Core, executing SQL on a real PostgreSQL through the `psql` CLI.

Used ONLY when SQLAlchemy/psycopg are not installed (e.g. an offline sandbox). CI and the Docker image use
the real libraries (see tests/support/conn.py). It translates `:name` bind parameters into escaped literals,
so it validates SQL syntax, constraints and set-based logic, but it is NOT a substitute for exercising the
real driver. Every statement autocommits; commit()/rollback() are no-ops.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import types
from datetime import date, datetime
from decimal import Decimal

_PARAM = re.compile(r"(?<![:\w]):([A-Za-z_]\w*)")


class TextClause:
    def __init__(self, sql: str):
        self.sql = sql


def text(sql: str) -> TextClause:
    return TextClause(sql)


def _lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float, Decimal)):
        return str(v)
    if isinstance(v, (date, datetime)):
        return "'" + v.isoformat() + "'"
    if isinstance(v, (list, tuple)):
        if all(isinstance(x, int) for x in v):
            return "ARRAY[" + ",".join(str(x) for x in v) + "]::bigint[]" if v else "'{}'::bigint[]"
        raise TypeError("only int lists supported by the shim")
    s = str(v).replace("\\", "\\\\").replace("'", "''")
    return "E'" + s + "'"


_DATE_KEYS = {"usage_date", "max", "min"}
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _coerce(row: dict) -> dict:
    """row_to_json turns dates/timestamps into strings; restore the Python types psycopg would return.
    Done by column name (not value shape) so text columns that merely look like dates stay strings."""
    out = {}
    for k, v in row.items():
        if isinstance(v, str):
            if k in _DATE_KEYS and _DATE_RE.match(v):
                v = date.fromisoformat(v)
            elif k.endswith("_at") or k in ("event_timestamp", "locked_until"):
                try:
                    v = datetime.fromisoformat(v)
                except ValueError:
                    pass
        out[k] = v
    return out


class Result:
    def __init__(self, rows, rowcount):
        self._rows, self.rowcount = rows, rowcount

    def mappings(self):
        return self

    def all(self):
        return [Row(r) for r in self._rows]

    def first(self):
        return Row(self._rows[0]) if self._rows else None

    def scalar(self):
        return next(iter(self._rows[0].values())) if self._rows else None

    def scalar_one(self):
        if len(self._rows) != 1:
            raise RuntimeError(f"expected exactly one row, got {len(self._rows)}")
        return self.scalar()


class Row(dict):
    """dict that also supports positional access like a SQLAlchemy Row."""

    def __getitem__(self, k):
        if isinstance(k, int):
            return list(self.values())[k]
        return dict.__getitem__(self, k)

    def __iter__(self):
        return iter(self.values())  # tuple-style unpacking, like Row

    def keys(self):
        return dict.keys(self)


class PsqlConnection:
    def __init__(self, dsn: str):
        self.dsn = dsn

    def _run(self, sql: str) -> str:
        p = subprocess.run(
            ["psql", self.dsn, "-X", "-q", "-t", "-A", "-v", "ON_ERROR_STOP=1", "-f", "-"],
            input=sql,
            capture_output=True,
            text=True,
        )
        if p.returncode != 0:
            raise RuntimeError(p.stderr.strip())
        return p.stdout

    def execute(self, clause: TextClause, params: dict | None = None) -> Result:
        params = params or {}
        sql = _PARAM.sub(lambda m: _lit(params[m.group(1)]) if m.group(1) in params else m.group(0), clause.sql).strip()
        head = sql.lstrip("( \n").split(None, 1)[0].upper()
        if head in ("SELECT", "WITH"):
            wrapped = f"SELECT row_to_json(t)::text FROM ({sql}) t"
        elif head in ("INSERT", "UPDATE", "DELETE"):
            body = sql if re.search(r"\bRETURNING\b", sql, re.I) else sql + " RETURNING 1 AS _n"
            wrapped = f"WITH x AS ({body}) SELECT row_to_json(x)::text FROM x"
        else:
            self._run(sql)
            return Result([], 0)
        out = self._run(wrapped)
        rows = [_coerce(json.loads(line)) for line in out.splitlines() if line.strip()]
        return Result(rows, len(rows))

    def commit(self):
        pass

    def rollback(self):
        pass

    def close(self):
        pass


def install() -> None:
    """Register fake `sqlalchemy` + `sqlalchemy.engine` modules so app code imports unchanged."""
    if "sqlalchemy" in sys.modules:
        return
    sa = types.ModuleType("sqlalchemy")
    sa.text = text
    eng = types.ModuleType("sqlalchemy.engine")
    eng.Connection = PsqlConnection
    sa.engine = eng
    sys.modules["sqlalchemy"], sys.modules["sqlalchemy.engine"] = sa, eng
