"""Connection factory for DB-backed service tests.

Uses real SQLAlchemy + psycopg when installed (CI, Docker). Otherwise falls back to the psql-based shim
so the SQL can still be validated against a real PostgreSQL. `BACKEND` records which one is in use.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (
    ROOT / "services" / "analytics",
    ROOT / "services" / "ingestion",
    ROOT / "apps" / "api",
    ROOT / "tests" / "support",
):
    sys.path.insert(0, str(p))

DSN = os.environ.get("CLOUDPULSE_TEST_DSN")
SCHEMA = ROOT / "apps" / "api" / "db" / "schema.sql"

try:
    import psycopg  # noqa: F401
    import sqlalchemy  # noqa: F401

    BACKEND = "sqlalchemy"
except ImportError:
    import pgshim

    pgshim.install()
    BACKEND = "psql-shim"


def sqlalchemy_url(dsn: str) -> str:
    return dsn.replace("postgresql://", "postgresql+psycopg://", 1)


def make_conn():
    if BACKEND == "sqlalchemy":
        from sqlalchemy import create_engine

        return create_engine(sqlalchemy_url(DSN)).connect()
    import pgshim

    return pgshim.PsqlConnection(DSN)


def reset_database(conn) -> None:
    """Drop everything and re-apply schema.sql (the same file migration 0001 applies)."""
    import subprocess

    from sqlalchemy import text  # real or shim

    conn.execute(text("DROP SCHEMA public CASCADE"))
    conn.execute(text("CREATE SCHEMA public"))
    p = subprocess.run(
        ["psql", DSN, "-X", "-q", "-v", "ON_ERROR_STOP=1", "-f", str(SCHEMA)], capture_output=True, text=True
    )
    if p.returncode != 0:
        raise RuntimeError(p.stderr)
    conn.commit()
